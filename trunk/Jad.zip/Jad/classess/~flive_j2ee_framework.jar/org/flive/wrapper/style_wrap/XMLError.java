// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   XMLError.java

package org.flive.wrapper.style_wrap;


public class XMLError
{

	private String id;
	private String message;

	public XMLError(String id, String message)
	{
		this.id = id;
		this.message = message;
	}

	public String toXML()
	{
		return "<?xml version=\"1.0\" encoding=\"GBK\"?><error id=\"" + id + "\">" + message + "</error>";
	}

	public String getId()
	{
		return id;
	}

	public String getMessage()
	{
		return message;
	}
}
