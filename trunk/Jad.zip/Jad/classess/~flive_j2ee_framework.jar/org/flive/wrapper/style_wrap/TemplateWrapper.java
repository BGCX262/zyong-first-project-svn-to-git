// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TemplateWrapper.java

package org.flive.wrapper.style_wrap;

import freemarker.template.Configuration;
import freemarker.template.Template;
import java.io.*;
import java.util.*;
import org.flive.AutoLoadServlet;
import org.flive.configuration.*;
import org.flive.control_logic.namespace.ScopeAdapter;

// Referenced classes of package org.flive.wrapper.style_wrap:
//			WrapperAdapter, CanNotLoadTempletsException, XMLError

public class TemplateWrapper
	implements WrapperAdapter
{

	private static final String ATTR = "attr";
	private static final String CODE = "code";
	private static Configuration config;
	private OutputStream out;
	private XMLError error;
	private static String template_path = "/templates";

	public TemplateWrapper()
		throws CanNotLoadTempletsException
	{
		error = null;
		if (config == null)
		{
			config = new Configuration();
			config.setDefaultEncoding("GBK");
			config.setOutputEncoding("GBK");
			config.setLocale(Locale.CHINA);
			String temp_dir = null;
			try
			{
				temp_dir = AutoLoadServlet.getApplicationRootPath() + "/WEB-INF/" + template_path;
				config.setDirectoryForTemplateLoading(new File(temp_dir));
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw new CanNotLoadTempletsException(temp_dir);
			}
		}
	}

	public void setOutput(OutputStream out)
	{
		this.out = out;
	}

	public void wrap(Style style, ScopeAdapter scope)
	{
		try
		{
			error = (XMLError)scope.getValue("error");
			if (error != null)
				return;
			Set names = scope.getNames();
			Iterator it = names.iterator();
			Map root = new HashMap();
			String name;
			Object obj;
			for (; it.hasNext(); root.put(name, obj))
			{
				name = (String)it.next();
				obj = scope.getValue(name);
			}

			root.put("attr", ClassAttributeMapping.getMapping(null).getClasses());
			root.put("code", MessageCodeMapping.getMapping(null).getMessages());
			Template t = config.getTemplate(style.getTemplet());
			t.process(root, new OutputStreamWriter(out, "GBK"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			error = new XMLError(e.getClass().getName(), e.getMessage());
		}
	}

	public static void setTempleteDirectory(String path)
	{
		template_path = path;
	}

}
