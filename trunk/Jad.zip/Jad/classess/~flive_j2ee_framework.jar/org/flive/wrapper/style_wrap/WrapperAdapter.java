// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WrapperAdapter.java

package org.flive.wrapper.style_wrap;

import java.io.OutputStream;
import org.flive.configuration.Style;
import org.flive.control_logic.namespace.ScopeAdapter;

public interface WrapperAdapter
{

	public abstract void setOutput(OutputStream outputstream);

	public abstract void wrap(Style style, ScopeAdapter scopeadapter);
}
