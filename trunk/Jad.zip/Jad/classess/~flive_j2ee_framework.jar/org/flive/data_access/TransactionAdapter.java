// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransactionAdapter.java

package org.flive.data_access;


// Referenced classes of package org.flive.data_access:
//			ContextException

public interface TransactionAdapter
{

	public abstract void commit()
		throws ContextException;

	public abstract void rollback()
		throws ContextException;

	public abstract boolean wasCommited()
		throws ContextException;

	public abstract boolean wasRolledBack()
		throws ContextException;
}
