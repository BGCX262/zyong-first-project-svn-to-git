// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HibernateDataAccessFactoryImpl.java

package org.flive.data_access.hibernateImpl;

import java.util.*;
import org.flive.data_access.ContextAdapter;
import org.flive.data_access.DataAccessFactoryAdapter;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

// Referenced classes of package org.flive.data_access.hibernateImpl:
//			HibernateContextProvider

public class HibernateDataAccessFactoryImpl
	implements DataAccessFactoryAdapter
{

	protected static Map sessionFactoryMap = new HashMap();
	protected static ThreadLocal threadedSessions = new ThreadLocal();
	protected static Map contextMap = new HashMap();
	protected String configFile;

	public HibernateDataAccessFactoryImpl()
	{
	}

	public void initialize(String cfg_name)
	{
		configFile = cfg_name;
		try
		{
			if (cfg_name == null && sessionFactoryMap.size() > 0)
				return;
			if (sessionFactoryMap.get(cfg_name) != null)
				return;
			Configuration cfg = new Configuration();
			if (cfg_name == null)
				cfg.configure();
			else
				cfg.configure(cfg_name);
			setSessionFactory(cfg_name, cfg.buildSessionFactory());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	protected void setSessionFactory(SessionFactory sessionFactory)
	{
		setSessionFactory(null, sessionFactory);
	}

	protected void setSessionFactory(String configFileName, SessionFactory sessionFactory)
	{
		sessionFactoryMap.put(configFileName, sessionFactory);
	}

	public ContextAdapter createContext()
	{
		Session session = createSession();
		HibernateContextProvider hci = (HibernateContextProvider)contextMap.get(session);
		if (hci == null)
		{
			hci = new HibernateContextProvider(session);
			hci.setFactory(this);
			contextMap.put(session, hci);
		}
		return hci;
	}

	protected Session createSession()
	{
		try
		{
			Stack sessionStack = (Stack)threadedSessions.get();
			Session session = null;
			if (sessionStack == null)
			{
				sessionStack = new Stack();
				threadedSessions.set(sessionStack);
			}
			if (sessionStack.size() > 0)
			{
				Object arr[] = (Object[])sessionStack.peek();
				String cf = (String)arr[0];
				if (cf == null)
					session = (Session)arr[1];
				else
				if (cf != null && configFile != null && cf.equals(configFile))
					session = (Session)arr[1];
				if (session == null)
				{
					session = getSessionFactory(configFile).openSession();
					arr = new Object[2];
					arr[0] = configFile;
					arr[1] = session;
					sessionStack.push(((Object) (arr)));
				}
			} else
			{
				session = getSessionFactory(configFile).openSession();
				Object arr[] = new Object[2];
				arr = new Object[2];
				arr[0] = configFile;
				arr[1] = session;
				sessionStack.push(((Object) (arr)));
			}
			return session;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	private void closeSession()
		throws HibernateException
	{
		Stack sessionStack = (Stack)threadedSessions.get();
		if (sessionStack != null)
		{
			Object arr[] = (Object[])sessionStack.peek();
			String cf = (String)arr[0];
			if (cf == null)
			{
				Session session = (Session)arr[1];
				session.close();
				sessionStack.pop();
			} else
			if (configFile != null && configFile.equals(cf))
			{
				Session session = (Session)arr[1];
				session.close();
				sessionStack.pop();
			}
		}
	}

	protected SessionFactory getSessionFactory()
		throws HibernateException
	{
		return getSessionFactory(configFile);
	}

	private SessionFactory getSessionFactory(String configFile)
		throws HibernateException
	{
		if (sessionFactoryMap.size() == 1)
			return (SessionFactory)sessionFactoryMap.values().toArray()[0];
		SessionFactory sessionFactory = (SessionFactory)sessionFactoryMap.get(configFile);
		if (sessionFactory == null)
		{
			if (configFile == null)
				throw new RuntimeException("The session factory has not been initialized.");
			else
				throw new RuntimeException("The session factory for '" + configFile + "' has not been initialized.");
		} else
		{
			return sessionFactory;
		}
	}

	public void destoryContext(Object obj)
	{
		Session session = (Session)obj;
		try
		{
			contextMap.remove(session);
			closeSession();
			session = null;
		}
		catch (HibernateException e)
		{
			e.printStackTrace();
		}
	}

}
