// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NullContextProvider.java

package org.flive.data_access.nullImpl;

import java.io.Serializable;
import java.util.List;
import org.flive.data_access.*;

public class NullContextProvider
	implements ContextAdapter
{

	public NullContextProvider()
	{
	}

	public void createQuery(String s)
	{
	}

	public void setParameter(String s, Object obj)
	{
	}

	public List list()
	{
		return null;
	}

	public Object uniqueResult()
	{
		return null;
	}

	public void setFirstResult(int i)
	{
	}

	public void setMaxResults(int i)
	{
	}

	public TransactionAdapter beginTransaction()
		throws ContextException
	{
		return null;
	}

	public Object get(Class cls_name, Serializable sequence_id)
	{
		return null;
	}

	public void delete(Object obj1)
		throws ContextException
	{
	}

	public void save(Object obj1)
		throws ContextException
	{
	}

	public void update(Object obj1)
		throws ContextException
	{
	}

	public void initialize(Object obj1)
		throws ContextException
	{
	}

	public void saveOrUpdate(Object obj1)
		throws ContextException
	{
	}

	public void close()
	{
	}

	public Object getParameter(String name)
	{
		return null;
	}

	public Object call(Object params[])
	{
		return null;
	}

	public void load(Object obj1, Serializable serializable)
	{
	}
}
