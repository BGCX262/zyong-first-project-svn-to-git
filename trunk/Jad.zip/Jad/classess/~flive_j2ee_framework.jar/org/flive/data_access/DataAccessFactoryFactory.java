// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataAccessFactoryFactory.java

package org.flive.data_access;

import java.util.HashMap;
import java.util.Map;
import org.flive.util.ObjectThread;

// Referenced classes of package org.flive.data_access:
//			DataAccessFactoryAdapter, DataAccessorNotFoundException

public class DataAccessFactoryFactory
{

	private static DataAccessFactoryFactory dff;
	private Map dataFactoryContainer;

	public DataAccessFactoryFactory()
	{
		dataFactoryContainer = new HashMap();
	}

	public static DataAccessFactoryFactory getInstance()
	{
		if (dff == null)
			dff = new DataAccessFactoryFactory();
		return dff;
	}

	public void putDataAccessFactory(String df_provider_id, String clazz, String init_str)
	{
		try
		{
			DataAccessFactoryAdapter factory = (DataAccessFactoryAdapter)Class.forName(clazz).newInstance();
			factory.initialize(init_str);
			dff.dataFactoryContainer.put(df_provider_id, factory);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public DataAccessFactoryAdapter getDataAccessFactory(String df_provider_id)
		throws DataAccessorNotFoundException
	{
		Object obj = dff.dataFactoryContainer.get(df_provider_id);
		if (obj == null)
			throw new DataAccessorNotFoundException(df_provider_id);
		else
			return (DataAccessFactoryAdapter)obj;
	}

	public DataAccessFactoryAdapter getCurrentFactory()
	{
		return (DataAccessFactoryAdapter)ObjectThread.getInstance().get("data_access_factory");
	}
}
