// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NullTransactionProvider.java

package org.flive.data_access.nullImpl;

import org.flive.data_access.ContextException;
import org.flive.data_access.TransactionAdapter;

public class NullTransactionProvider
	implements TransactionAdapter
{

	public NullTransactionProvider()
	{
	}

	public void commit()
		throws ContextException
	{
	}

	public void rollback()
		throws ContextException
	{
	}

	public boolean wasCommited()
		throws ContextException
	{
		return false;
	}

	public boolean wasRolledBack()
		throws ContextException
	{
		return false;
	}
}
