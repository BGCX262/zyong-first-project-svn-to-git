// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NullDataAccessFactoryImpl.java

package org.flive.data_access.nullImpl;

import org.flive.data_access.ContextAdapter;
import org.flive.data_access.DataAccessFactoryAdapter;

public class NullDataAccessFactoryImpl
	implements DataAccessFactoryAdapter
{

	public NullDataAccessFactoryImpl()
	{
	}

	public void initialize(String s)
	{
	}

	public ContextAdapter createContext()
	{
		return null;
	}

	public void destoryContext(Object obj)
	{
	}
}
