// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HibernateContextProvider.java

package org.flive.data_access.hibernateImpl;

import java.io.Serializable;
import java.util.List;
import org.flive.data_access.*;
import org.hibernate.*;

// Referenced classes of package org.flive.data_access.hibernateImpl:
//			HibernateTransactionProvider, HibernateDataAccessFactoryImpl

public class HibernateContextProvider
	implements ContextAdapter
{

	private Session session;
	private Query query;
	private HibernateDataAccessFactoryImpl factory;
	private HibernateTransactionProvider trans;

	public HibernateContextProvider(Session s)
	{
		session = s;
	}

	public void setFactory(HibernateDataAccessFactoryImpl impl)
	{
		factory = impl;
	}

	public void createQuery(String query_str)
	{
		if (query_str.indexOf('.') >= 0)
			query = session.createQuery(query_str);
		else
			query = session.getNamedQuery(query_str);
	}

	public void setParameter(String name, Object value)
	{
		query.setParameter(name, value);
	}

	public List list()
	{
		return query.list();
	}

	public Object uniqueResult()
	{
		return query.uniqueResult();
	}

	public void setFirstResult(int first)
	{
		query.setFirstResult(first);
	}

	public void setMaxResults(int max)
	{
		query.setMaxResults(max);
	}

	public TransactionAdapter beginTransaction()
		throws ContextException
	{
		if (trans != null)
		{
			return trans;
		} else
		{
			org.hibernate.Transaction t = null;
			t = session.beginTransaction();
			trans = new HibernateTransactionProvider(t);
			return trans;
		}
	}

	public Object get(Class cls_name, Serializable sequence_id)
	{
		return session.get(cls_name, sequence_id);
	}

	public void delete(Object obj)
		throws ContextException
	{
		session.delete(obj);
	}

	public void save(Object obj)
		throws ContextException
	{
		session.save(obj);
	}

	public void update(Object obj)
		throws ContextException
	{
		session.update(obj);
	}

	public void close()
		throws ContextException
	{
		factory.destoryContext(session);
	}

	public void initialize(Object obj)
		throws ContextException
	{
		Hibernate.initialize(obj);
	}

	public void saveOrUpdate(Object obj)
		throws ContextException
	{
		session.saveOrUpdate(obj);
	}

	public Object getParameter(String name)
	{
		return null;
	}

	public Object call(Object params[])
	{
		Query q = session.getNamedQuery((String)params[0]);
		for (int i = 1; i < params.length; i++)
			if (params[i] != null)
				q.setParameter(i - 1, params[i]);

		return q.list();
	}

	public Session getSession()
	{
		return session;
	}

	public void load(Object obj, Serializable id)
	{
		Object re_obj = session.get(obj.getClass(), id);
		if (re_obj != null)
			session.evict(re_obj);
		session.load(obj, id);
	}
}
