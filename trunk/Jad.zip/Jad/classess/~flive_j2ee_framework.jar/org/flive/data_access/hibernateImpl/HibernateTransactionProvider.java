// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HibernateTransactionProvider.java

package org.flive.data_access.hibernateImpl;

import org.flive.data_access.ContextException;
import org.flive.data_access.TransactionAdapter;
import org.hibernate.Transaction;

public class HibernateTransactionProvider
	implements TransactionAdapter
{

	private Transaction transaction;

	public HibernateTransactionProvider(Transaction ht)
	{
		transaction = ht;
	}

	public void commit()
		throws ContextException
	{
		transaction.commit();
	}

	public void rollback()
		throws ContextException
	{
		transaction.rollback();
	}

	public boolean wasCommited()
		throws ContextException
	{
		return transaction.wasCommitted();
	}

	public boolean wasRolledBack()
		throws ContextException
	{
		return transaction.wasRolledBack();
	}
}
