// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ContextAdapter.java

package org.flive.data_access;

import java.io.Serializable;
import java.util.List;

// Referenced classes of package org.flive.data_access:
//			ContextException, TransactionAdapter

public interface ContextAdapter
{

	public abstract void createQuery(String s);

	public abstract void setParameter(String s, Object obj);

	public abstract Object getParameter(String s);

	public abstract List list();

	public abstract Object uniqueResult();

	public abstract void setFirstResult(int i);

	public abstract void setMaxResults(int i);

	public abstract TransactionAdapter beginTransaction()
		throws ContextException;

	public abstract Object call(Object aobj[]);

	public abstract Object get(Class class1, Serializable serializable);

	public abstract void delete(Object obj)
		throws ContextException;

	public abstract void save(Object obj)
		throws ContextException;

	public abstract void update(Object obj)
		throws ContextException;

	public abstract void initialize(Object obj)
		throws ContextException;

	public abstract void saveOrUpdate(Object obj)
		throws ContextException;

	public abstract void load(Object obj, Serializable serializable);

	public abstract void close();
}
