// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FunctionJob.java

package org.flive.scheduler;

import org.flive.configuration.Function;
import org.flive.control_logic.listener.ListenerCallbackImpl;
import org.flive.control_logic.listener.SchedulerListenerImpl;
import org.flive.control_logic.message.SchedulerMessageImpl;
import org.quartz.*;

public class FunctionJob
	implements Job
{

	private Function function;

	public FunctionJob()
	{
	}

	public void put(Function func)
	{
		function = func;
	}

	public String getDescription()
	{
		return function.getDescription();
	}

	public String getInterval()
	{
		return function.getInterval();
	}

	public int getStartHour()
	{
		String time = function.getStartTime();
		String items[] = time.split(":");
		return Integer.parseInt(items[0]);
	}

	public int getStartMinute()
	{
		String time = function.getStartTime();
		String items[] = time.split(":");
		return Integer.parseInt(items[1]);
	}

	public Function getFunction()
	{
		return function;
	}

	public void execute(JobExecutionContext ctx)
		throws JobExecutionException
	{
		JobDataMap dataMap = ctx.getJobDetail().getJobDataMap();
		function = (Function)dataMap.get("function");
		ListenerCallbackImpl reveiveHandler = new ListenerCallbackImpl();
		reveiveHandler.handle(new SchedulerListenerImpl(), new SchedulerMessageImpl(function));
	}
}
