// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   QuartzDecorator.java

package org.flive.scheduler;

import java.util.Date;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

// Referenced classes of package org.flive.scheduler:
//			FunctionJob

public class QuartzDecorator
{

	private static QuartzDecorator quartz;
	private Scheduler sched;

	protected QuartzDecorator()
	{
	}

	public static QuartzDecorator getInstance()
	{
		if (quartz != null)
		{
			return quartz;
		} else
		{
			quartz = new QuartzDecorator();
			return quartz;
		}
	}

	public void start()
	{
		SchedulerFactory schedFact = new StdSchedulerFactory();
		try
		{
			sched = schedFact.getScheduler();
			sched.start();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void addScheduler(FunctionJob job)
	{
		try
		{
			JobDetail jobDetail = new JobDetail(job.getDescription(), null, job.getClass());
			jobDetail.getJobDataMap().put("function", job.getFunction());
			Trigger trigger = TriggerUtils.makeDailyTrigger(job.getStartHour(), job.getStartMinute());
			trigger.setStartTime(TriggerUtils.getEvenMinuteDate(new Date()));
			trigger.setName("simpleTrigger");
			sched.scheduleJob(jobDetail, trigger);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
