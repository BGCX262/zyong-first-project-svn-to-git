// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SchedulerBuilder.java

package org.flive.scheduler;

import java.util.Iterator;
import org.flive.configuration.*;

// Referenced classes of package org.flive.scheduler:
//			QuartzDecorator, FunctionJob

public class SchedulerBuilder
{

	public SchedulerBuilder()
	{
	}

	public static void buildFunctionScheduler()
	{
		try
		{
			QuartzDecorator quartz = QuartzDecorator.getInstance();
			quartz.start();
			Configuration config = ConfigurationFactory.getInstance().get();
			for (Iterator iterator = config.iterateFunctions(); iterator.hasNext();)
			{
				Function func = (Function)iterator.next();
				if (func.getInterval() != null)
				{
					FunctionJob job = new FunctionJob();
					job.put(func);
					QuartzDecorator.getInstance().addScheduler(job);
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
