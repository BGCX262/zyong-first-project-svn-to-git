// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BasePrincipal.java

package org.flive.jaas_module;

import java.security.Principal;
import org.flive.jaas_module.user_management.UserAdapter;

public class BasePrincipal
	implements Principal
{

	private String name;
	private UserAdapter user;

	public BasePrincipal()
	{
		name = "";
		user = null;
	}

	public BasePrincipal(String name)
	{
		this.name = name;
	}

	public BasePrincipal(String name, UserAdapter user)
	{
		this.user = user;
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public UserAdapter getUser()
	{
		return user;
	}

	public int hashCode()
	{
		return name.hashCode();
	}

	public boolean equals(Object o)
	{
		if (!(o instanceof BasePrincipal))
			return false;
		else
			return user.equals(((BasePrincipal)o).user);
	}

	public String toString()
	{
		return name;
	}
}
