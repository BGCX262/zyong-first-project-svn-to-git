// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CanNotLoadUserException.java

package org.flive.jaas_module.user_management;


public class CanNotLoadUserException extends Exception
{

	private static final long serialVersionUID = 1L;

	public CanNotLoadUserException(String user_name)
	{
		super("Can not load special user that's user name is : " + user_name + "\r\n");
	}
}
