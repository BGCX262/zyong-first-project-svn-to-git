// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UserAdapter.java

package org.flive.jaas_module.user_management;

import java.util.Iterator;

// Referenced classes of package org.flive.jaas_module.user_management:
//			CanNotLoadUserException

public interface UserAdapter
{

	public abstract Object load(String s)
		throws CanNotLoadUserException;

	public abstract String getName();

	public abstract String getCredentials();

	public abstract Iterator iterateRole();
}
