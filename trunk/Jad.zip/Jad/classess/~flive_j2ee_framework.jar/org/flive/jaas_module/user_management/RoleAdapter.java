// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RoleAdapter.java

package org.flive.jaas_module.user_management;

import java.util.Iterator;

public interface RoleAdapter
{

	public abstract boolean hasPrivilege(String s, Object obj);

	public abstract Iterator iterateDeny(String s);

	public abstract boolean hasDeny(String s, Object obj);

	public abstract Iterator iteratePrivilege(String s);

	public abstract String[] getResourceTypes();
}
