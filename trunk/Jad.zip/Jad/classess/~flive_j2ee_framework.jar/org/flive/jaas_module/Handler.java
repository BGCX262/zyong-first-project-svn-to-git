// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Handler.java

package org.flive.jaas_module;

import java.io.IOException;
import javax.security.auth.callback.*;

public class Handler
	implements CallbackHandler
{

	private String username;
	private char credentials[];

	public Handler(String username, char credentials[])
	{
		this.username = username;
		this.credentials = credentials;
	}

	public void handle(Callback callbacks[])
		throws IOException, UnsupportedCallbackException
	{
		for (int i = 0; i < callbacks.length; i++)
			if (callbacks[i] instanceof NameCallback)
				((NameCallback)callbacks[i]).setName(username);
			else
			if (callbacks[i] instanceof PasswordCallback)
				((PasswordCallback)callbacks[i]).setPassword(credentials);
			else
				throw new UnsupportedCallbackException(callbacks[i]);

	}
}
