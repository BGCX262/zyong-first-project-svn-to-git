// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UserManagementFactory.java

package org.flive.jaas_module;

import org.flive.jaas_module.user_management.UserAdapter;

public class UserManagementFactory
{

	private static UserManagementFactory uf;
	private static Class userProvider = null;

	public UserManagementFactory()
	{
	}

	public static UserManagementFactory getInstance()
	{
		try
		{
			if (uf == null)
			{
				uf = new UserManagementFactory();
				if (userProvider == null)
					userProvider = Class.forName("org.flive.jaas_module.user_management.SimpleUserProvider");
			}
			return uf;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public static void setProvider(String user_provider)
	{
		try
		{
			userProvider = Class.forName(user_provider);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			userProvider = null;
		}
	}

	public UserAdapter getUser()
	{
		try
		{
			return (UserAdapter)userProvider.newInstance();
		}
		catch (InstantiationException e)
		{
			e.printStackTrace();
			return null;
		}
		catch (IllegalAccessException e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
