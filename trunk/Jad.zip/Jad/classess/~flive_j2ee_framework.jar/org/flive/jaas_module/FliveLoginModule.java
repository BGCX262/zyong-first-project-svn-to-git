// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FliveLoginModule.java

package org.flive.jaas_module;

import java.util.*;
import javax.security.auth.Subject;
import javax.security.auth.callback.*;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;
import org.flive.jaas_module.user_management.UserAdapter;
import org.flive.util.security.Digest;

// Referenced classes of package org.flive.jaas_module:
//			BasePrincipal, UserManagementFactory

public class FliveLoginModule
	implements LoginModule
{

	CallbackHandler handler;
	Subject subject;
	Map sharedState;
	Map options;
	Digest digest;
	Vector principals;
	boolean success;

	public FliveLoginModule()
	{
		principals = new Vector();
		success = false;
	}

	public void initialize(Subject subject, CallbackHandler handler, Map sharedState, Map options)
	{
		this.handler = handler;
		this.subject = subject;
		this.sharedState = sharedState;
		this.options = options;
		if (options.containsKey("digest"))
			digest = new Digest((String)options.get("digest"));
		else
			digest = new Digest();
	}

	public boolean login()
		throws LoginException
	{
		if (handler == null)
			throw new LoginException("Error: no CallbackHandler available");
		try
		{
			Callback callbacks[] = {
				new NameCallback("User: "), new PasswordCallback("Password: ", false)
			};
			handler.handle(callbacks);
			String username = ((NameCallback)callbacks[0]).getName();
			char password[] = ((PasswordCallback)callbacks[1]).getPassword();
			((PasswordCallback)callbacks[1]).clearPassword();
			success = validate(username, password);
			callbacks[0] = null;
			callbacks[1] = null;
			if (!success)
				throw new LoginException("Authentication failed: Password does not match");
			else
				return true;
		}
		catch (LoginException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			success = false;
			e.printStackTrace();
			throw new LoginException("Authentication failed: Exception has happen");
		}
	}

	public boolean commit()
		throws LoginException
	{
		if (success)
		{
			if (subject.isReadOnly())
				throw new LoginException("Subject is read-only");
			try
			{
				Iterator i = principals.iterator();
				subject.getPrincipals().addAll(principals);
				principals.clear();
				return true;
			}
			catch (Exception e)
			{
				throw new LoginException(e.getMessage());
			}
		} else
		{
			principals.clear();
			return true;
		}
	}

	public boolean abort()
		throws LoginException
	{
		success = false;
		logout();
		return true;
	}

	public boolean logout()
		throws LoginException
	{
		principals.clear();
		BasePrincipal p;
		for (Iterator i = subject.getPrincipals(org.flive.jaas_module.BasePrincipal.class).iterator(); i.hasNext(); subject.getPrincipals().remove(p))
			p = (BasePrincipal)i.next();

		return true;
	}

	private boolean validate(String username, char credentials[])
		throws Exception
	{
		boolean valid = false;
		UserAdapter user = UserManagementFactory.getInstance().getUser();
		user = (UserAdapter)user.load(username);
		if (credentials != null && credentials.length > 0)
			valid = user.getCredentials().equals(digest.digest(new String(credentials)));
		if (valid)
			principals.add(new BasePrincipal(user.getName(), user));
		return valid;
	}
}
