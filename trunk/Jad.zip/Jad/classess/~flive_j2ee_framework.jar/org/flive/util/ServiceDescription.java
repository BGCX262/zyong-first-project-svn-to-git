// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServiceDescription.java

package org.flive.util;

import java.util.*;
import org.flive.configuration.*;

// Referenced classes of package org.flive.util:
//			VariableUtil

public class ServiceDescription
{

	public ServiceDescription()
	{
	}

	public static Map getAllFunctionsParameters()
		throws CanNotFoundConfigurationException
	{
		HashMap map = new HashMap(100);
		Function function;
		for (Iterator it = ConfigurationFactory.getInstance().get().iterateFunctions(); it.hasNext(); map.put(function.getId(), getFunctionParametersDescription(function)))
			function = (Function)it.next();

		return map;
	}

	public static List getFunctionParametersDescription(Function function)
	{
		List list = new ArrayList();
		for (Iterator it = function.getSteps().iterator(); it.hasNext();)
		{
			Step step = (Step)it.next();
			if (step.getArgs() != null)
			{
				for (Iterator args = step.getArgs().iterator(); args.hasNext();)
				{
					Arg arg = (Arg)args.next();
					String name = VariableUtil.isInScope(arg.getValue(), "request_param");
					if (name != null)
						list.add(name);
				}

			}
		}

		if (list.isEmpty())
			return null;
		else
			return list;
	}
}
