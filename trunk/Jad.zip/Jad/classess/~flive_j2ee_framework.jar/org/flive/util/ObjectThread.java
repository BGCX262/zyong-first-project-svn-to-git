// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ObjectThread.java

package org.flive.util;

import java.util.Hashtable;
import java.util.Map;

public class ObjectThread
{

	public static final String PRI_STRING = "pri_string";
	public static final String PRI_MAP = "pri_map";
	public static final String DataAccessFactory = "data_access_factory";
	private static ObjectThread objectThread = null;
	private ThreadLocal threadLocal;

	private ObjectThread()
	{
		threadLocal = new ThreadLocal();
	}

	public static synchronized ObjectThread getInstance()
	{
		if (objectThread == null)
			objectThread = new ObjectThread();
		return objectThread;
	}

	public void put(String key, Object object)
	{
		Map map = (Map)threadLocal.get();
		if (map == null)
		{
			threadLocal.set(new Hashtable());
			map = (Map)threadLocal.get();
		}
		map.put(key, object);
		threadLocal.set(map);
	}

	public Object get(String key)
	{
		Map map = (Map)threadLocal.get();
		if (map == null)
			return null;
		else
			return map.get(key);
	}

}
