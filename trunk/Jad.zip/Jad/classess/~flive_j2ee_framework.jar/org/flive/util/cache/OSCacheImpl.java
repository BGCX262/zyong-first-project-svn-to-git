// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   OSCacheImpl.java

package org.flive.util.cache;

import com.opensymphony.oscache.base.NeedsRefreshException;
import com.opensymphony.oscache.general.GeneralCacheAdministrator;

// Referenced classes of package org.flive.util.cache:
//			CacheAdapter

public class OSCacheImpl
	implements CacheAdapter
{

	private GeneralCacheAdministrator admin;

	public OSCacheImpl()
	{
		admin = new GeneralCacheAdministrator();
	}

	public void putToCache(String key, Object obj)
	{
		admin.putInCache(key, obj);
	}

	public Object getFormCache(String key, int expired)
	{
		try
		{
			return admin.getFromCache(key, expired);
		}
		catch (NeedsRefreshException e)
		{
			admin.cancelUpdate(key);
		}
		return null;
	}

	public void erase(String key)
	{
		admin.flushEntry(key);
	}
}
