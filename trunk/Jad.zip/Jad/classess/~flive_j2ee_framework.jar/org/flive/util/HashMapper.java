// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HashMapper.java

package org.flive.util;

import java.util.*;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class HashMapper
	implements IMarshaller, IUnmarshaller, IAliasable
{

	private static final int DEFAULT_SIZE = 10;
	private String m_uri;
	private int m_index;
	private String m_name;

	public HashMapper()
	{
		m_uri = null;
		m_index = 0;
		m_name = "hashmap";
	}

	public HashMapper(String uri, int index, String name)
	{
		m_uri = uri;
		m_index = index;
		m_name = name;
	}

	protected String getSizeAttributeName()
	{
		return "size";
	}

	protected String getEntryElementName()
	{
		return "adapter";
	}

	protected String getKeyAttributeName()
	{
		return "id";
	}

	public boolean isExtension(int index)
	{
		return false;
	}

	public void marshal(Object obj, IMarshallingContext ictx)
		throws JiBXException
	{
		if (!(obj instanceof Map))
			throw new JiBXException("Invalid object type for marshaller");
		if (!(ictx instanceof MarshallingContext))
			throw new JiBXException("Invalid object type for marshaller");
		MarshallingContext ctx = (MarshallingContext)ictx;
		Map map = (Map)obj;
		ctx.startTagAttributes(m_index, m_name).attribute(m_index, getSizeAttributeName(), map.size()).closeStartContent();
		for (Iterator iter = map.entrySet().iterator(); iter.hasNext();)
		{
			java.util.Map.Entry entry = (java.util.Map.Entry)iter.next();
			ctx.startTagAttributes(m_index, getEntryElementName());
			ctx.attribute(m_index, getKeyAttributeName(), entry.getKey().toString());
			ctx.closeStartContent();
			if (entry.getValue() instanceof IMarshallable)
			{
				((IMarshallable)entry.getValue()).marshal(ctx);
				ctx.endTag(m_index, getEntryElementName());
			} else
			{
				throw new JiBXException("Mapped value is not marshallable");
			}
		}

		ctx.endTag(m_index, m_name);
	}

	public boolean isPresent(IUnmarshallingContext ctx)
		throws JiBXException
	{
		return ctx.isAt(m_uri, m_name);
	}

	public Object unmarshal(Object obj, IUnmarshallingContext ictx)
		throws JiBXException
	{
		UnmarshallingContext ctx = (UnmarshallingContext)ictx;
		if (!ctx.isAt(m_uri, m_name))
			ctx.throwStartTagNameError(m_uri, m_name);
		int size = ctx.attributeInt(m_uri, getSizeAttributeName(), 10);
		Map map = (Map)obj;
		if (map == null)
			map = new HashMap(size);
		ctx.parsePastStartTag(m_uri, m_name);
		ctx.next();
		Object key;
		Object value;
		for (String entry = ctx.getElementName(); ctx.isAt(m_uri, entry); map.put(key, value))
		{
			key = ctx.attributeText(m_uri, getKeyAttributeName(), null);
			value = ctx.unmarshalElement();
		}

		ctx.parsePastEndTag(m_uri, m_name);
		return map;
	}
}
