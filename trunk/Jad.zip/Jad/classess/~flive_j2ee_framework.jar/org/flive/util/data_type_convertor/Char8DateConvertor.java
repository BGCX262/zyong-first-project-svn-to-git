// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Char8DateConvertor.java

package org.flive.util.data_type_convertor;

import java.util.Date;
import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.Converter;

public class Char8DateConvertor
	implements Converter
{

	public Char8DateConvertor()
	{
	}

	public Object convert(Class type, Object value)
		throws ConversionException
	{
		if (!type.equals(java.util.Date.class))
			throw new ConversionException("can NOT deal with this type: " + type.getName());
		String char8 = (String)value;
		if (char8.length() != 8)
		{
			throw new ConversionException("the lenght of value is not completable. expectability length is 8.");
		} else
		{
			int year = Integer.parseInt(char8.substring(0, 4)) - 1900;
			int month = Integer.parseInt(char8.substring(4, 6)) - 1;
			int date = Integer.parseInt(char8.substring(6, 8));
			return new Date(year, month, date);
		}
	}
}
