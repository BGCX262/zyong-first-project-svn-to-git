// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Digest.java

package org.flive.util.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.flive.util.HexDump;

public class Digest
{

	private MessageDigest algorithm;
	private String method;

	public Digest()
	{
		this("PLAIN");
	}

	public Digest(String digest)
	{
		algorithm = null;
		method = null;
		method = digest;
		try
		{
			algorithm = MessageDigest.getInstance(digest);
		}
		catch (NoSuchAlgorithmException e)
		{
			try
			{
				algorithm = MessageDigest.getInstance("MD5");
			}
			catch (NoSuchAlgorithmException nosuchalgorithmexception) { }
		}
	}

	public String digest(String credentials)
	{
		if (method.equals("XOR"))
		{
			byte bc[] = credentials.getBytes();
			for (int i = 0; i < bc.length; i++)
				bc[i] = (byte)(bc[i] ^ 0x61);

			return new String(bc);
		}
		if (method.equals("PLAIN"))
			return credentials;
		if (algorithm == null)
			return credentials;
		Digest digest1 = this;
		JVM INSTR monitorenter ;
		algorithm.reset();
		algorithm.update(credentials.getBytes());
		return HexDump.toHexString(algorithm.digest());
		Exception e;
		e;
		credentials;
		digest1;
		JVM INSTR monitorexit ;
		return;
		digest1;
		JVM INSTR monitorexit ;
		throw ;
	}
}
