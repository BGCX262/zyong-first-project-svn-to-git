// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Register.java

package org.flive.util.data_type_convertor;

import org.apache.commons.beanutils.ConvertUtils;

// Referenced classes of package org.flive.util.data_type_convertor:
//			Char8DateConvertor, Date2Char8Convertor

public class Register
{

	public Register()
	{
	}

	public static void register()
	{
		org.apache.commons.beanutils.Converter converter = new Char8DateConvertor();
		ConvertUtils.register(converter, java.util.Date.class);
		converter = new Date2Char8Convertor();
		ConvertUtils.register(converter, java.lang.String.class);
	}
}
