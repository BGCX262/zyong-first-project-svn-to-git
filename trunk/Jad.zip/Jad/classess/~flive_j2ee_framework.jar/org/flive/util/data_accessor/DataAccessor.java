// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataAccessor.java

package org.flive.util.data_accessor;

import java.util.*;
import org.flive.data_access.ContextAdapter;
import org.flive.util.ObjectThread;

// Referenced classes of package org.flive.util.data_accessor:
//			Row

public class DataAccessor
{

	private ContextAdapter context;

	public DataAccessor()
	{
	}

	public void setContext(ContextAdapter con)
	{
		context = con;
	}

	private Row putPrivilege(Row row)
	{
		ObjectThread objThd = ObjectThread.getInstance();
		Map map = (Map)objThd.get("pri_map");
		if (map == null || map.isEmpty())
			return row;
		Object key;
		for (Iterator it = map.keySet().iterator(); it.hasNext(); row.add(row.in(key.toString(), map.get(key).toString())))
			key = it.next();

		return row;
	}

	public List query(String object, Row selectionRow, String sorts[], String groups[])
	{
		selectionRow = putPrivilege(selectionRow);
		StringBuffer buf = new StringBuffer();
		buf.append("from ").append(object).append(" ");
		if (selectionRow != null)
			buf.append(" where ").append(selectionRow.toString());
		if (sorts != null)
		{
			buf.append(" order by ").append(sorts[0]);
			for (int i = 1; i < sorts.length; i++)
				buf.append(",").append(sorts[i]);

		}
		if (groups != null)
		{
			buf.append(" group by ").append(groups[0]);
			for (int i = 0; i < groups.length; i++)
				buf.append(",").append(groups[i]);

		}
		context.createQuery(buf.toString());
		if (selectionRow == null)
			return context.list();
		Map values = selectionRow.getValues();
		if (!values.isEmpty())
		{
			String key;
			Object value;
			for (Iterator it = values.keySet().iterator(); it.hasNext(); context.setParameter(key, value))
			{
				key = (String)it.next();
				value = values.get(key);
			}

		}
		return context.list();
	}
}
