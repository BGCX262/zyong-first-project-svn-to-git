// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExpressionUtil.java

package org.flive.util;

import java.util.ArrayList;
import java.util.Stack;

public class ExpressionUtil
{

	static final int NO = 1;
	static final String NOstr = "!";

	public ExpressionUtil()
	{
	}

	public static boolean calculate(String e)
	{
		String expression = null;
		expression = e;
		int off = 0;
		String temp = null;
		Stack stack = new Stack();
		for (int i = 0; i < expression.length(); i++)
		{
			char ex = expression.charAt(i);
			switch (expression.charAt(i))
			{
			default:
				break;

			case 40: // '('
			case 91: // '['
				off = i + 1;
				break;

			case 41: // ')'
				temp = expression.substring(off, i);
				String arg = temp + "(";
				ArrayList t_list = new ArrayList();
				int param_count = 2;
				if (temp.equals("!"))
					param_count = 1;
				for (int j = 0; j < param_count; j++)
					t_list.add(stack.pop());

				for (int j = 0; j < param_count; j++)
					if (j == param_count - 1)
						arg = arg + (String)t_list.get(0);
					else
						arg = arg + (String)t_list.get(param_count - j - 1) + ',';

				arg = arg + ")";
				int index = arg.indexOf("(");
				Object objFirst = null;
				Object objEnd = null;
				if (!temp.equals("!"))
				{
					int firstNum = index;
					index = arg.indexOf(",");
					String firstStr = arg.substring(firstNum + 1, index);
					String endStr = arg.substring(index + 1, arg.length() - 1);
					objFirst = firstStr;
					objEnd = endStr;
				}
				if (temp.equals("!"))
				{
					if (arg.substring(2, arg.length() - 1).equals("true"))
						arg = "false";
					else
						arg = "true";
				} else
				if (temp.equals("=="))
				{
					if (objEnd.equals(objFirst))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("^^"))
				{
					if (objFirst.toString().equals("true") && objEnd.toString().equals("true"))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("||"))
				{
					if (objFirst.toString().equals("false") && objEnd.toString().equals("false"))
						arg = "false";
					else
						arg = "true";
				} else
				if (temp.equals("!="))
				{
					if (!objEnd.equals(objFirst))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("more"))
				{
					if (Double.parseDouble(objFirst.toString()) > Double.parseDouble(objEnd.toString()))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("moreandequal"))
				{
					if (Double.parseDouble(objFirst.toString()) >= Double.parseDouble(objEnd.toString()))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("less"))
				{
					if (Double.parseDouble(objFirst.toString()) < Double.parseDouble(objEnd.toString()))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("lessandequal"))
				{
					if (Double.parseDouble(objFirst.toString()) <= Double.parseDouble(objEnd.toString()))
						arg = "true";
					else
						arg = "false";
				} else
				if (temp.equals("add"))
				{
					double argDouble = Double.parseDouble(objFirst.toString()) + Double.parseDouble(objEnd.toString());
					arg = String.valueOf(argDouble);
				} else
				if (temp.equals("minus"))
				{
					double argDouble = Double.parseDouble(objFirst.toString()) - Double.parseDouble(objEnd.toString());
					arg = String.valueOf(argDouble);
				} else
				if (temp.equals("multiply"))
				{
					double argDouble = Double.parseDouble(objFirst.toString()) * Double.parseDouble(objEnd.toString());
					arg = String.valueOf(argDouble);
				} else
				if (temp.equals("divide"))
				{
					double argDouble = Double.parseDouble(objFirst.toString()) / Double.parseDouble(objEnd.toString());
					arg = String.valueOf(argDouble);
				}
				stack.push(arg);
				break;

			case 93: // ']'
				temp = expression.substring(off, i);
				stack.push(temp);
				break;
			}
		}

		Object o = stack.pop();
		return o.toString().equals("true");
	}
}
