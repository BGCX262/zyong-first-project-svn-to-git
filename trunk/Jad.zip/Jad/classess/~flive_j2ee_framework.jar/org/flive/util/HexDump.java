// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HexDump.java

package org.flive.util;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Random;
import sun.misc.HexDumpEncoder;

public class HexDump
{

	private static final char HEX_DIGITS[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
		'A', 'B', 'C', 'D', 'E', 'F'
	};
	private static char BIT_DIGIT[] = {
		'0', '1'
	};
	private static final byte COMPARE_BITS[] = {
		-128, 64, 32, 16, 8, 4, 2, 1
	};
	private static char BYTE_SEPARATOR = ' ';
	private static boolean WITH_BYTE_SEPARATOR = true;

	public HexDump()
	{
	}

	public static String prettyPrintHex(byte baToConvert[])
	{
		HexDumpEncoder hde = new HexDumpEncoder();
		return hde.encodeBuffer(baToConvert);
	}

	public static String prettyPrintHex(String sToConvert)
	{
		return prettyPrintHex(sToConvert.getBytes());
	}

	public static void setWithByteSeparator(boolean bs)
	{
		WITH_BYTE_SEPARATOR = bs;
	}

	public static void setByteSeparator(char bs)
	{
		BYTE_SEPARATOR = bs;
	}

	public static void setBitDigits(char bd[])
		throws Exception
	{
		if (bd.length != 2)
		{
			throw new Exception("wrong number of characters!");
		} else
		{
			BIT_DIGIT = bd;
			return;
		}
	}

	public static void setBitDigits(char zeroBit, char oneBit)
	{
		BIT_DIGIT[0] = zeroBit;
		BIT_DIGIT[1] = oneBit;
	}

	public static String byteArrayToBinaryString(byte block[])
	{
		StringBuffer strBuf = new StringBuffer();
		int iLen = block.length;
		for (int i = 0; i < iLen; i++)
		{
			byte2bin(block[i], strBuf);
			if ((i < iLen - 1) & WITH_BYTE_SEPARATOR)
				strBuf.append(BYTE_SEPARATOR);
		}

		return strBuf.toString();
	}

	public static String toBinaryString(byte ba[])
	{
		return byteArrayToBinaryString(ba);
	}

	public static String toBinaryString(byte b)
	{
		byte ba[] = new byte[1];
		ba[0] = b;
		return byteArrayToBinaryString(ba);
	}

	public static String toBinaryString(short s)
	{
		return toBinaryString(toByteArray(s));
	}

	public static String toBinaryString(int i)
	{
		return toBinaryString(toByteArray(i));
	}

	public static String toBinaryString(long l)
	{
		return toBinaryString(toByteArray(l));
	}

	public static final byte[] toByteArray(short s)
	{
		byte baTemp[] = new byte[2];
		baTemp[1] = (byte)s;
		baTemp[0] = (byte)(s >> 8);
		return baTemp;
	}

	public static final byte[] toByteArray(int i)
	{
		byte baTemp[] = new byte[4];
		baTemp[3] = (byte)i;
		baTemp[2] = (byte)(i >> 8);
		baTemp[1] = (byte)(i >> 16);
		baTemp[0] = (byte)(i >> 24);
		return baTemp;
	}

	public static final byte[] toByteArray(long l)
	{
		byte baTemp[] = new byte[8];
		baTemp[7] = (byte)(int)l;
		baTemp[6] = (byte)(int)(l >> 8);
		baTemp[5] = (byte)(int)(l >> 16);
		baTemp[4] = (byte)(int)(l >> 24);
		baTemp[3] = (byte)(int)(l >> 32);
		baTemp[2] = (byte)(int)(l >> 40);
		baTemp[1] = (byte)(int)(l >> 48);
		baTemp[0] = (byte)(int)(l >> 56);
		return baTemp;
	}

	public static String byteArrayToHexString(byte block[])
	{
		StringBuffer buf = new StringBuffer();
		int len = block.length;
		for (int i = 0; i < len; i++)
		{
			byte2hex(block[i], buf);
			if ((i < len - 1) & WITH_BYTE_SEPARATOR)
				buf.append(BYTE_SEPARATOR);
		}

		return buf.toString();
	}

	public static String stringToHexString(String in)
	{
		byte ba[] = in.getBytes();
		return toHexString(ba);
	}

	public static String byteArrayToHexString(byte block[], int offset, int length)
	{
		StringBuffer buf = new StringBuffer();
		int len = block.length;
		length += offset;
		if (len < length)
			length = len;
		for (int i = 0 + offset; i < length; i++)
		{
			byte2hex(block[i], buf);
			if (i < length - 1)
				buf.append(":");
		}

		return buf.toString();
	}

	public static String toHexString(byte ba[])
	{
		return toHexString(ba, 0, ba.length);
	}

	public static String toHexString(byte b)
	{
		byte ba[] = new byte[1];
		ba[0] = b;
		return toHexString(ba, 0, ba.length);
	}

	public static String toHexString(short s)
	{
		return toHexString(toByteArray(s));
	}

	public static String toHexString(int i)
	{
		return toHexString(toByteArray(i));
	}

	public static String toHexString(long l)
	{
		return toHexString(toByteArray(l));
	}

	public static String toString(byte ba[])
	{
		return (new String(ba)).toString();
	}

	public static String toString(byte b)
	{
		byte ba[] = new byte[1];
		ba[0] = b;
		return (new String(ba)).toString();
	}

	public static String toHexString(byte ba[], int offset, int length)
	{
		char buf[];
		if (WITH_BYTE_SEPARATOR)
			buf = new char[length * 3];
		else
			buf = new char[length * 2];
		int i = offset;
		int j = 0;
		while (i < offset + length) 
		{
			int k = ba[i++];
			buf[j++] = HEX_DIGITS[k >>> 4 & 0xf];
			buf[j++] = HEX_DIGITS[k & 0xf];
			if (WITH_BYTE_SEPARATOR)
				buf[j++] = BYTE_SEPARATOR;
		}
		return new String(buf);
	}

	public static byte[] hexStringToByteArray(String strA)
	{
		ByteArrayOutputStream result = new ByteArrayOutputStream();
		byte sum = 0;
		boolean nextCharIsUpper = true;
		for (int i = 0; i < strA.length(); i++)
		{
			char c = strA.charAt(i);
			switch (Character.toUpperCase(c))
			{
			case 58: // ':'
			case 59: // ';'
			case 60: // '<'
			case 61: // '='
			case 62: // '>'
			case 63: // '?'
			case 64: // '@'
			default:
				break;

			case 48: // '0'
				if (nextCharIsUpper)
				{
					sum = 0;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 49: // '1'
				if (nextCharIsUpper)
				{
					sum = 16;
					nextCharIsUpper = false;
				} else
				{
					sum |= 1;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 50: // '2'
				if (nextCharIsUpper)
				{
					sum = 32;
					nextCharIsUpper = false;
				} else
				{
					sum |= 2;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 51: // '3'
				if (nextCharIsUpper)
				{
					sum = 48;
					nextCharIsUpper = false;
				} else
				{
					sum |= 3;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 52: // '4'
				if (nextCharIsUpper)
				{
					sum = 64;
					nextCharIsUpper = false;
				} else
				{
					sum |= 4;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 53: // '5'
				if (nextCharIsUpper)
				{
					sum = 80;
					nextCharIsUpper = false;
				} else
				{
					sum |= 5;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 54: // '6'
				if (nextCharIsUpper)
				{
					sum = 96;
					nextCharIsUpper = false;
				} else
				{
					sum |= 6;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 55: // '7'
				if (nextCharIsUpper)
				{
					sum = 112;
					nextCharIsUpper = false;
				} else
				{
					sum |= 7;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 56: // '8'
				if (nextCharIsUpper)
				{
					sum = -128;
					nextCharIsUpper = false;
				} else
				{
					sum |= 8;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 57: // '9'
				if (nextCharIsUpper)
				{
					sum = -112;
					nextCharIsUpper = false;
				} else
				{
					sum |= 9;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 65: // 'A'
				if (nextCharIsUpper)
				{
					sum = -96;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0xa;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 66: // 'B'
				if (nextCharIsUpper)
				{
					sum = -80;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0xb;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 67: // 'C'
				if (nextCharIsUpper)
				{
					sum = -64;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0xc;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 68: // 'D'
				if (nextCharIsUpper)
				{
					sum = -48;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0xd;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 69: // 'E'
				if (nextCharIsUpper)
				{
					sum = -32;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0xe;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;

			case 70: // 'F'
				if (nextCharIsUpper)
				{
					sum = -16;
					nextCharIsUpper = false;
				} else
				{
					sum |= 0xf;
					result.write(sum);
					nextCharIsUpper = true;
				}
				break;
			}
		}

		if (!nextCharIsUpper)
			throw new RuntimeException("The String did not contain an equal number of hex digits");
		else
			return result.toByteArray();
	}

	private static void byte2hex(byte b, StringBuffer buf)
	{
		char hexChars[] = {
			'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
			'A', 'B', 'C', 'D', 'E', 'F'
		};
		int high = (b & 0xf0) >> 4;
		int low = b & 0xf;
		buf.append(hexChars[high]);
		buf.append(hexChars[low]);
	}

	private static void byte2bin(byte b, StringBuffer buf)
	{
		for (int i = 0; i < 8; i++)
			if ((b & COMPARE_BITS[i]) != 0)
				buf.append(BIT_DIGIT[1]);
			else
				buf.append(BIT_DIGIT[0]);

	}

	private static String intToHexString(int n)
	{
		char buf[] = new char[8];
		for (int i = 7; i >= 0; i--)
		{
			buf[i] = HEX_DIGITS[n & 0xf];
			n >>>= 4;
		}

		return new String(buf);
	}

	public static void main(String args[])
	{
		System.out.println("-test and demo of the converter ");
		String str = new String("Niko");
		byte ba[] = str.getBytes();
		System.out.println("to convert: " + str);
		System.out.println("converted1: " + byteArrayToHexString(ba));
		System.out.println("converted1: " + byteArrayToHexString(ba, 0, ba.length));
		System.out.println("converted3: " + stringToHexString(str));
		System.out.println("----Convert integer to hexString...");
		int i = -2;
		System.out.println("to convert: " + i + " -> " + intToHexString(i));
		System.out.println("----Convert byte[] to binary String...");
		byte baToConvert[] = {
			-1, 0, 51, 17, -1, 95, 95, 79, 31, -1
		};
		System.out.println("to convert: " + toHexString(baToConvert) + " -> " + byteArrayToBinaryString(baToConvert));
		setByteSeparator('-');
		System.out.println("to convert: " + toHexString(baToConvert) + " -> " + byteArrayToBinaryString(baToConvert));
		setByteSeparator('*');
		setWithByteSeparator(true);
		System.out.println("to convert: " + toHexString(baToConvert) + " -> " + byteArrayToBinaryString(baToConvert));
		char bd[] = {
			'a', 'b'
		};
		try
		{
			setBitDigits(bd);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println("to convert: " + toHexString(baToConvert) + " -> " + byteArrayToBinaryString(baToConvert));
		setBitDigits('0', '1');
		System.out.println("---- Convert.toByteArray(int) ");
		for (int iToConvert = -10; iToConvert < 10; iToConvert++)
		{
			System.out.println("to convert = " + iToConvert + " = " + toBinaryString(iToConvert));
			byte baConvInt[] = new byte[4];
			baConvInt = toByteArray(iToConvert);
			System.out.println("convertet byteArray = " + toBinaryString(baConvInt));
		}

		System.out.println("---- toHexString(int) ");
		i = -1;
		System.out.println(i + " = 0x" + toHexString(i) + " = " + toBinaryString(i));
		i++;
		System.out.println(i + " = 0x" + toHexString(i) + " = " + toBinaryString(i));
		System.out.println("---- toHexString(long) ");
		long l = 100L;
		System.out.println(l + " = 0x" + toHexString(l) + " = " + toBinaryString(l));
		Random rnd = new Random();
		l = rnd.nextLong();
		System.out.println(l + " = 0x" + toHexString(l) + " = " + toBinaryString(l));
		System.out.println("---- toHexString(short) ");
		short s = 100;
		System.out.println(s + " = 0x" + toHexString(s) + " = " + toBinaryString(s));
		rnd = new Random();
		s = (short)rnd.nextInt();
		System.out.println(s + " = 0x" + toHexString(s) + " = " + toBinaryString(s));
		System.out.println("---- read file in Hex-Format ");
		String strToConvert = "12345654321";
		System.out.println(strToConvert + " = " + stringToHexString(strToConvert));
		System.out.println("Das ist die Hex-Darstellung des obigen Strings");
		System.out.println("ba = " + toHexString(ba));
	}

}
