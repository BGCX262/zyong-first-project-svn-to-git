// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Row.java

package org.flive.util.data_accessor;

import java.util.*;

// Referenced classes of package org.flive.util.data_accessor:
//			Restriction

public class Row
{

	private static final String LIKE = "like";
	private static final String EQ = "=";
	private static final String GE = ">=";
	private static final String LE = "<=";
	private static final String GT = ">";
	private static final String LT = "<";
	private static final String OR = "or";
	private static final String IN = "in";
	private static final String NOT_IN = "not in";
	private static final String BETWEEN = "between";
	private static final String NOT_BETWEEN = "not between";
	private Set contents;
	private Map values;

	public Row()
	{
		contents = new HashSet();
		values = new HashMap();
	}

	private void convertToPrepareMode(Restriction res)
	{
		String formatted_attribute = res.getName().replaceAll("\\.", "__");
		Object realValue = res.getValue();
		res.setValue(":" + formatted_attribute);
		contents.add(res);
		values.put(formatted_attribute, realValue);
	}

	public Row add(Restriction res)
	{
		if (res.isSimple())
			convertToPrepareMode(res);
		else
			contents.add(res);
		return this;
	}

	public Restriction or(Restriction one, Restriction two)
	{
		return new Restriction(one, two, "or");
	}

	public Restriction eq(String attribute, Object value)
	{
		return new Restriction(attribute, "=", value);
	}

	public Restriction like(String attribute, Object value)
	{
		return new Restriction(attribute, "like", value);
	}

	public Restriction ge(String attribute, Object value)
	{
		return new Restriction(attribute, ">=", value);
	}

	public Restriction le(String attribute, Object value)
	{
		return new Restriction(attribute, "<=", value);
	}

	public Restriction gt(String attribute, Object value)
	{
		return new Restriction(attribute, ">", value);
	}

	public Restriction lt(String attribute, Object value)
	{
		return new Restriction(attribute, "<", value);
	}

	public Restriction between(String attribute, Object startValue, Object endValue)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(startValue).append(" and ").append(endValue);
		return new Restriction(attribute, "between", buf.toString());
	}

	public Restriction not_between(String attribute, Object startValue, Object endValue)
	{
		StringBuffer buf = new StringBuffer();
		buf.append(startValue).append(" and ").append(endValue);
		return new Restriction(attribute, "not between", buf.toString());
	}

	public Restriction in(String attribute, String range)
	{
		return new Restriction(attribute, "in", range);
	}

	public Restriction not_in(String attribute, String range)
	{
		return new Restriction(attribute, "not in", range);
	}

	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("(");
		Iterator it = contents.iterator();
		Restriction res = (Restriction)it.next();
		buf.append(res.toString());
		for (; it.hasNext(); buf.append(" and ").append(res.toString()))
			res = (Restriction)it.next();

		buf.append(")");
		return buf.toString();
	}

	public Map getValues()
	{
		return values;
	}
}
