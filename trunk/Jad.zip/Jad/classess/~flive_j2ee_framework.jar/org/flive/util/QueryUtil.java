// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   QueryUtil.java

package org.flive.util;

import java.io.PrintStream;
import java.util.*;
import org.flive.data_access.ContextAdapter;
import org.flive.data_access.DataAccessFactoryAdapter;

// Referenced classes of package org.flive.util:
//			ObjectThread

public class QueryUtil
{

	private static final String CLASS_FOR_SHORT = "c";
	private static final String FILL_STRING = " where 1=1 ";
	private StringBuffer queryStringBuffer;
	public static final String GLOBAL_SYMBOL = "%";
	public static final String CONNECT_AND = " and ";
	public static final String CONNECT_OR = " or ";
	public static final String CONNECT_GROUPBY = " group by ";
	public static final String CONNECT_ORDERBY = " order by ";
	public static final String CONNECT_DESC = " desc ";
	public static final String COMPARE_LESS = " < ";
	public static final String COMPARE_LESS_EQUAL = " <= ";
	public static final String COMPARE_GREAT = " > ";
	public static final String COMPARE_GREAT_EQUAL = " >= ";
	public static final String COMPARE_EQUAL = " = ";
	public static final String COMPARE_NONEQUAL = "<>";
	public static final String COMPARE_IS_NULL = " is null ";
	public static final String COMPARE_IS_NOT_NULL = " is not null ";
	public static final String COMPARE_LIKE = " like ";
	public static final String STAT_FUNC_COUNT = "count";
	public static final String STAT_FUNC_SUM = "sum";
	public static final String STAT_FUNC_MAX = "max";
	public static final String STAT_FUNC_MIN = "min";
	public static final String STAT_FUNC_AVG = "avg";
	public static final String STAT_FUNC_NO = "";
	private ContextAdapter context;

	public QueryUtil()
	{
		queryStringBuffer = new StringBuffer();
		DataAccessFactoryAdapter factory = (DataAccessFactoryAdapter)ObjectThread.getInstance().get("data_access_factory");
		context = factory.createContext();
	}

	public Object call(String query_name, Object params[])
	{
		Object pas[] = new Object[params.length + 1];
		pas[0] = query_name;
		System.arraycopy(((Object) (params)), 0, ((Object) (pas)), 1, params.length);
		return context.call(pas);
	}

	public Object get(String clazz, String id)
		throws ClassNotFoundException
	{
		return context.get(Class.forName(clazz), id);
	}

	private String getDataPrivilegeString()
	{
		ObjectThread objThd = ObjectThread.getInstance();
		HashMap map = (HashMap)objThd.get("pri_map");
		if (map == null || map.size() == 0)
			return " where 1=1 ";
		StringBuffer ret = new StringBuffer();
		Object keys[] = map.keySet().toArray();
		ret.append(" where ").append("c").append(".id ").append(" in (").append(map.get(keys[0])).append(") ");
		for (int i = 1; i < map.size(); i++)
			ret.append(" and ").append(keys[i]).append(" in (").append(map.get(keys[i])).append(") ");

		map.clear();
		return ret.toString();
	}

	public void doReady(String className)
	{
		queryStringBuffer.append("from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
	}

	public void doReady(String className, String statFunc)
	{
		if (statFunc.equals(""))
			queryStringBuffer.append(" from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
		else
		if (statFunc.equals("count"))
			queryStringBuffer.append("select ").append(statFunc).append("(").append("c").append(")").append(" from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
	}

	public void doReady(String className, String fieldName, String statFunc)
	{
		if (statFunc.equals(""))
			queryStringBuffer.append(" from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
		else
		if (statFunc.equals("count"))
			queryStringBuffer.append("select ").append(statFunc).append("(").append("c").append(")").append(" from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
		else
		if (statFunc.equals("sum") || statFunc.equals("max") || statFunc.equals("min") || statFunc.equals("avg"))
			queryStringBuffer.append("select ").append(statFunc).append("(").append("c").append(".").append(fieldName).append(")").append(" from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
	}

	public void doGroupbyReady(String className, String fieldName, String statFunc)
	{
		if (statFunc.equals("count"))
			queryStringBuffer.append("select ").append("c").append(".").append(fieldName).append(",").append(statFunc).append("(").append("c").append(".id)").append(" from ").append(className).append(" as ").append("c").append(getDataPrivilegeString());
	}

	public void doSetQueryNotBetweenCondition(String connect, String classField, String begin, String end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" not between '").append(begin).append("' and '").append(end).append("' ");
	}

	public void doSetQueryInCondition(String connect, String classField, String inStr)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" in ").append(inStr);
	}

	public void doSetQueryBetweenCondition(String connect, String classField, String begin, String end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between '").append(begin).append("' and '").append(end).append("'");
	}

	public void doSetQueryBetweenConditionWithRawString(String connect, String classField, String begin, String end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between ").append(begin).append(" and ").append(end).append("");
	}

	public void doSetQueryBetweenCondition(String connect, String classField, double begin, double end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between ").append(begin).append(" and ").append(end);
	}

	public void doSetQueryBetweenCondition(String connect, String classField, long begin, long end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between ").append(begin).append(" and ").append(end);
	}

	public void doSetQueryBetweenCondition(String connect, String classField, char begin, char end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between '").append(begin).append("' and '").append(end).append("'");
	}

	public void doSetQueryBetweenCondition(String connect, String classField, int begin, int end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between ").append(begin).append(" and ").append(end);
	}

	public void doSetQueryBetweenCondition(String connect, String classField, float begin, float end)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(" between ").append("begin").append(" and ").append(end);
	}

	public void doSetQueryCondition(String connect, String classField, String compared)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(compared).append(":").append(classField.replaceAll("\\.", "_"));
		System.out.println(queryStringBuffer.toString());
	}

	public void doSetQueryTrimCondition(String connect, String classField, String compared)
	{
		queryStringBuffer.append(connect).append(" ltrim(rtrim(").append("c").append(".").append(classField).append(")) ").append(compared).append(":").append(classField.replaceAll("\\.", "_"));
	}

	public void doSetQueryNullCondition(String connect, String classField, String compared)
	{
		queryStringBuffer.append(connect).append("c").append(".").append(classField).append(compared);
	}

	public void doSetQueryGroupByCondition(String classField)
	{
		queryStringBuffer.append(" group by ").append("c").append(".").append(classField);
	}

	public void doSetQueryOrderByCondition(String classField1, String classField2)
	{
		queryStringBuffer.append(" order by ").append("c").append(".").append(classField1).append(',').append("c").append(".").append(classField2);
	}

	public void doSetQueryOrderByCondition(String classField)
	{
		queryStringBuffer.append(" order by ").append("c").append(".").append(classField);
	}

	public void doSetQueryOrderDescByCondition(String classField)
	{
		queryStringBuffer.append(" order by ").append("c").append(".").append(classField).append(" desc ");
	}

	public void doQuery()
	{
		String queryString = queryStringBuffer.toString();
		context.createQuery(queryString);
	}

	public void doQuery(String str)
	{
		context.createQuery(str);
	}

	public void doSetParam(String paramName, int param)
	{
		context.setParameter(paramName, new Integer(param));
	}

	public void doSetParam(String paramName, char param)
	{
		context.setParameter(paramName.replaceAll("\\.", "_"), new Character(param));
	}

	public void doSetParam(String paramName, String param)
	{
		context.setParameter(paramName.replaceAll("\\.", "_"), param);
	}

	public void doSetParam(String paramName, long param)
	{
		context.setParameter(paramName.replaceAll("\\.", "_"), new Long(param));
	}

	public void doSetParam(String paramName, double param)
	{
		context.setParameter(paramName.replaceAll("\\.", "_"), new Double(param));
	}

	public List doGetResult()
	{
		List lst = context.list();
		return lst;
	}

	public Object doGetUniqueResult()
	{
		Object obj = context.uniqueResult();
		return obj;
	}

	public List getAllList(String className)
	{
		doReady(className);
		doQuery();
		return doGetResult();
	}

	public void doReadyByHql(String hql)
	{
		queryStringBuffer = new StringBuffer(hql);
	}

	public void doReadyByHql(StringBuffer hql)
	{
		queryStringBuffer = hql;
	}

	public void doSetReturnLines(int from, int lines)
	{
		context.setFirstResult(from);
		context.setMaxResults(lines);
	}

	public void doSetConditionBegin()
	{
		queryStringBuffer.append("and ( 1=1 ");
	}

	public void doSetConditionEnd()
	{
		queryStringBuffer.append(" )");
	}
}
