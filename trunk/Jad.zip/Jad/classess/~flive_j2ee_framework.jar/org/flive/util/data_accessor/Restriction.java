// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Restriction.java

package org.flive.util.data_accessor;


public class Restriction
{

	private String name;
	private String operator;
	private Object value;
	private boolean isSimple;
	private String nativeString;

	public Restriction(String name, String operator, Object value)
	{
		this.name = name;
		this.operator = operator;
		this.value = value;
		nativeString = null;
		isSimple = true;
	}

	public Restriction(String name, String operator, String value_str)
	{
		this.name = null;
		StringBuffer buf = new StringBuffer();
		buf.append("(").append(name).append(" ").append(operator).append(" ").append(value_str).append(")");
		nativeString = buf.toString();
		isSimple = false;
	}

	public Restriction(Restriction one, Restriction two, String operator)
	{
		name = null;
		StringBuffer buf = new StringBuffer();
		buf.append("( ").append(one.toString()).append(" ").append(operator).append(" ").append(two.toString()).append(")");
		nativeString = buf.toString();
		isSimple = false;
	}

	public String toString()
	{
		if (nativeString != null)
		{
			return nativeString;
		} else
		{
			StringBuffer buf = new StringBuffer();
			buf.append("( ").append(name).append(" ").append(operator).append(" ").append(value).append(")");
			nativeString = buf.toString();
			return nativeString;
		}
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getOperator()
	{
		return operator;
	}

	public void setOperator(String operator)
	{
		this.operator = operator;
	}

	public Object getValue()
	{
		return value;
	}

	public void setValue(Object value)
	{
		this.value = value;
	}

	public String getNativeString()
	{
		return nativeString;
	}

	public boolean isSimple()
	{
		return isSimple;
	}
}
