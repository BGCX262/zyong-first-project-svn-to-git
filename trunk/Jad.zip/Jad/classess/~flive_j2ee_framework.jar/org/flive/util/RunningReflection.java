// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RunningReflection.java

package org.flive.util;


public class RunningReflection
{

	public RunningReflection()
	{
	}

	public static Class String2Class(String str)
	{
		Class ret = null;
		if (str == null || str.equals("null"))
			ret = null;
		else
		if (str.equals("int"))
			ret = Integer.TYPE;
		else
		if (str.equals("long"))
			ret = Long.TYPE;
		else
		if (str.equals("string"))
			ret = java.lang.String.class;
		else
		if (str.equals("boolean"))
			ret = Boolean.TYPE;
		else
		if (str.equals("float"))
			ret = Float.TYPE;
		else
		if (str.equals("byte"))
			ret = Byte.TYPE;
		else
		if (str.equals("short"))
			ret = Short.TYPE;
		else
		if (str.equals("char"))
			ret = Character.TYPE;
		else
		if (str.equals("double"))
			ret = Double.TYPE;
		else
		if (str.equals("long[]"))
		{
			long nothing[] = new long[0];
			ret = nothing.getClass();
		} else
		{
			try
			{
				ret = Class.forName(str);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				ret = null;
			}
		}
		return ret;
	}
}
