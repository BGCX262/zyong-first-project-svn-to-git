// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   VariableUtil.java

package org.flive.util;

import java.lang.reflect.Constructor;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.flive.control_logic.namespace.NameSpaceFactory;
import org.flive.control_logic.namespace.ScopeAdapter;

// Referenced classes of package org.flive.util:
//			VariableNotFoundException

public class VariableUtil
{

	public static final String FIRST_LETTER = "\\$";
	public static final String REGEX_PREFIX = "\\{";
	public static final int REGEX_PREFIX_REAL_LEN = 2;
	public static final String REGEX_VARIABLE = "([a-zA-Z\\.\\-\\_0-9]*)";
	public static final String REGEX_POSTFIX = "\\}";
	public static final int REGEX_POSTFIX_REAL_LEN = 1;
	private static final String ENHANCER_FLAG = "$$EnhancerByCGLIB$$";
	private static final String NAME_SPACE = "name_space";

	public VariableUtil()
	{
	}

	public static String getDecliaredName(Class cls)
	{
		String realClassName = cls.getName();
		int index = realClassName.indexOf("$$EnhancerByCGLIB$$");
		if (index < 0)
			return realClassName;
		else
			return realClassName.substring(0, index);
	}

	public static String getClassName(String refContent)
	{
		int index = refContent.lastIndexOf(".");
		String a = refContent.substring(0, index);
		return a;
	}

	public static List findVariable(String st, String first_letter)
	{
		Pattern pattern = null;
		Matcher matcher = null;
		String variable = null;
		ArrayList result = null;
		int i = 0;
		pattern = Pattern.compile(first_letter + "\\{" + "([a-zA-Z\\.\\-\\_0-9]*)" + "\\}");
		matcher = pattern.matcher(st);
		if (!matcher.find())
			return result;
		result = new ArrayList();
		String split[] = pattern.split(st);
		do
		{
			variable = st.substring(matcher.start() + 2, matcher.end() - 1);
			result.add(variable);
		} while (matcher.find());
		return result;
	}

	public static List findVariable(String st)
	{
		return findVariable(st, "\\$");
	}

	public static Object getArgValue(Class arg_class, Class arg_item_class, String value_string)
	{
		Object ret = null;
		try
		{
			List ls = findVariable(value_string);
			if (ls != null)
			{
				String variable = (String)findVariable(value_string).get(0);
				ret = getScopeVariable(arg_class, arg_item_class, variable);
				if (!arg_class.isPrimitive())
					return ret;
				if (value_string != null)
					value_string = ((String) (ret != null ? ((String) (ret)) : null));
				if (value_string != null && value_string.equals(""))
					value_string = null;
			}
			if (arg_class == Double.TYPE)
			{
				if (value_string == null)
					ret = new Double((0.0D / 0.0D));
				else
					ret = new Double(value_string);
			} else
			if (arg_class == Integer.TYPE)
			{
				if (value_string == null)
					ret = new Integer(0x80000000);
				else
					ret = new Integer(value_string);
			} else
			if (arg_class == Long.TYPE)
			{
				if (value_string == null)
					ret = new Long(0x8000000000000000L);
				else
					ret = new Long(value_string);
			} else
			if (arg_class == Float.TYPE)
			{
				if (value_string == null)
					ret = new Float((0.0F / 0.0F));
				else
					ret = new Float(value_string);
			} else
			if (arg_class == Character.TYPE)
			{
				if (value_string == null)
					ret = new Character('\0');
				else
					ret = new Character(value_string.charAt(0));
			} else
			if (arg_class == Byte.TYPE)
			{
				if (value_string == null)
					ret = new Byte((byte)-128);
				else
					ret = new Byte(value_string);
			} else
			if (arg_class == Short.TYPE)
			{
				if (value_string == null)
					ret = new Short((short)-32768);
				else
					ret = new Short(value_string);
			} else
			if (arg_class == Boolean.TYPE)
			{
				if (value_string == null)
					ret = new Boolean(false);
				else
					ret = new Boolean(value_string);
			} else
			if (arg_class == java.lang.String.class)
			{
				ret = value_string;
			} else
			{
				if (ret == null)
					return ret;
				if (!ret.getClass().equals(arg_class))
				{
					Class clss[] = {
						ret.getClass()
					};
					Object objs[] = {
						ret
					};
					ret = arg_class.getConstructor(clss).newInstance(objs);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	public static Object getScopeVariable(String var_string)
	{
		return getScopeVariable(null, null, var_string);
	}

	public static Object getScopeVariable(Class cls, Class arg_item_class, String var_string)
	{
		NameSpaceFactory namespace = NameSpaceFactory.getInstance();
		try
		{
			Object ret = null;
			if ("name_space".equals(var_string))
				return namespace;
			if (namespace.hasScope(var_string))
				return namespace.getScope(var_string);
			int index = var_string.indexOf(".");
			if (index < 0)
				throw new VariableNotFoundException(var_string);
			String scopeName = var_string.substring(0, index);
			String name = var_string.substring(index + 1, var_string.length());
			ret = namespace.getScope(scopeName).getValue(name);
			if (arg_item_class != null)
			{
				if (!java.util.Collection.class.isAssignableFrom(cls))
					throw new Exception("class is not a collection type");
				if (cls.equals(java.util.List.class))
					cls = java.util.ArrayList.class;
				else
				if (cls.equals(java.util.Set.class))
					cls = java.util.HashSet.class;
				Collection collection = (Collection)cls.newInstance();
				Object objss[] = (Object[])ret;
				Class clss[] = {
					objss[0].getClass()
				};
				for (int i = 0; i < objss.length; i++)
				{
					Object objs[] = {
						objss[i]
					};
					ret = arg_item_class.getConstructor(clss).newInstance(objs);
					collection.add(ret);
				}

				return collection;
			} else
			{
				return ret;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public static String replaceVariable(String e)
	{
		String expression = e;
		String regx = "\\$\\{([a-zA-Z\\.\\-\\_0-9]*)\\}";
		try
		{
			List list = findVariable(e);
			if (list == null)
				return e;
			for (int i = 0; i < list.size(); i++)
			{
				String var = (String)list.get(i);
				expression = expression.replaceFirst("\\$\\{([a-zA-Z\\.\\-\\_0-9]*)\\}", getScopeVariable(null, null, var).toString());
			}

			return expression;
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		return expression;
	}

	public static String isInScope(String var, String scope_name)
	{
		String regx = "\\$\\{" + scope_name + "([a-zA-Z\\.\\-\\_0-9]*)" + "\\}";
		if (!var.matches(regx))
			return null;
		int index = var.indexOf(".");
		if (index == -1)
		{
			return null;
		} else
		{
			String name = var.substring(index + 1, var.length() - 1);
			return name;
		}
	}
}
