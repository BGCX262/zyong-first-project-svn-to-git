// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Date2Char8Convertor.java

package org.flive.util.data_type_convertor;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.Converter;

public class Date2Char8Convertor
	implements Converter
{

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

	public Date2Char8Convertor()
	{
	}

	public Object convert(Class type, Object value)
		throws ConversionException
	{
		if (!type.equals(java.lang.String.class))
			throw new ConversionException("can NOT deal with this type: " + type.getName());
		if (value instanceof String)
			return value;
		if (value instanceof Date)
		{
			Date date = (Date)value;
			return dateFormat.format(date);
		} else
		{
			return value.toString();
		}
	}

}
