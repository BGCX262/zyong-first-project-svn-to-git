// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ConfigUtil.java

package org.flive.util;

import java.util.Iterator;
import java.util.Set;
import org.apache.commons.beanutils.BeanUtils;
import org.flive.control_logic.namespace.NameSpaceFactory;
import org.flive.control_logic.namespace.ScopeAdapter;

public class ConfigUtil
{

	public ConfigUtil()
	{
	}

	public static Object wrapObject(ScopeAdapter scope, String className)
		throws Exception
	{
		Object ret = Class.forName(className).newInstance();
		Set set = scope.getNames();
		for (Iterator it = set.iterator(); it.hasNext();)
		{
			String name = (String)it.next();
			int index = name.indexOf(className);
			if (index >= 0)
			{
				name = name.substring(index + className.length());
				Object value = scope.getValue(name);
				try
				{
					BeanUtils.setProperty(ret, name, value);
				}
				catch (Exception exception) { }
			}
		}

		return ret;
	}

	public static void putValueToScope(String name, String value, String scope)
		throws Exception
	{
		ScopeAdapter sp = NameSpaceFactory.getInstance().getScope(scope);
		sp.setValue(name, value);
	}

	public static Object getViewBeanDescription(Object obj)
	{
		return obj;
	}
}
