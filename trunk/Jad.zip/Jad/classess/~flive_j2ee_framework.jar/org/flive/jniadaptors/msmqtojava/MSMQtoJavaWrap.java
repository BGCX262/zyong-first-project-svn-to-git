// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MSMQtoJavaWrap.java

package org.flive.jniadaptors.msmqtojava;


public class MSMQtoJavaWrap
{

	int queueHandle;
	String messageString;
	String msmqCorrelationID;

	public native int openQueue(String s, int i);

	public native int peekMessage(String s, int i);

	public native int receiveMessage(String s, int i);

	public native int sendMessage(String s, int i, String s1, String s2);

	public native int closeQueue();

	public String getMessage()
	{
		return messageString;
	}

	public String getCorrelationID()
	{
		return msmqCorrelationID;
	}

	public String retrieveMessage()
	{
		String messageString1 = "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111";
		String messageString2 = "2222222222222222222222222222222222222222222222222222222222222222222222222222222222222222";
		int retcode = receiveMessage(messageString1, 60);
		messageString2 = getMessage();
		return messageString2;
	}

	private void callback()
		throws NullPointerException
	{
		throw new NullPointerException("thrown in CatchThrow.callback");
	}

	public MSMQtoJavaWrap()
	{
		queueHandle = 0;
		messageString = null;
		msmqCorrelationID = null;
		queueHandle = 0;
	}

	static 
	{
		System.loadLibrary("MSMQtoJava");
	}
}
