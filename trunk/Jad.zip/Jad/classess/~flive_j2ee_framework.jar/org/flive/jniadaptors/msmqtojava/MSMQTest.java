// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MSMQTest.java

package org.flive.jniadaptors.msmqtojava;

import java.io.PrintStream;
import junit.framework.TestCase;

// Referenced classes of package org.flive.jniadaptors.msmqtojava:
//			MSMQtoJavaWrap

public class MSMQTest extends TestCase
{

	public MSMQTest()
	{
	}

	public void testMSMQtoJavaWrap()
	{
		MSMQtoJavaWrap msmq = new MSMQtoJavaWrap();
		String msg = new String(new byte[1024]);
		msmq.openQueue(".\\private$\\javaqueue", 1);
		System.out.println("MSG: " + msmq.peekMessage(msg, msg.length()));
		msmq.receiveMessage(msg, msg.length());
		String line = msmq.getMessage();
		System.out.println("getMessage line = " + line);
		msmq.closeQueue();
	}
}
