// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AutoLoadServlet.java

package org.flive;

import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import org.flive.configuration.ClassAttributeMapping;
import org.flive.configuration.Configuration;
import org.flive.configuration.ConfigurationFactory;
import org.flive.configuration.DataAccessor;
import org.flive.configuration.MessageCodeMapping;
import org.flive.data_access.DataAccessFactoryFactory;
import org.flive.jaas_module.UserManagementFactory;

// Referenced classes of package org.flive:
//			NotInitializeException

public class AutoLoadServlet extends HttpServlet
{

	private static final long serialVersionUID = 1L;
	private static final String DISPATCH_CONFIG = "dispatch-config";
	private static final String CODE_MAPPING_FILE = "code-mapping";
	private static final String ATTRIBUTE_MAPPING_FILE = "attribute-mapping";
	private static String rootPath;

	public AutoLoadServlet()
	{
	}

	public static String getApplicationRootPath()
		throws NotInitializeException
	{
		if (rootPath == null)
			throw new NotInitializeException();
		else
			return rootPath;
	}

	public static void setJAASModule(String login_module, String user_provider)
	{
		System.setProperty("java.security.auth.login.config", login_module);
		UserManagementFactory.setProvider(user_provider);
	}

	public void init()
	{
		try
		{
			String config = System.getProperty("dispatch-config");
			if (config == null)
				config = getInitParameter("dispatch-config");
			ConfigurationFactory cf = ConfigurationFactory.getInstance();
			cf.load(getServletContext().getRealPath("/") + config);
			Collection dac = cf.get().getDataAccessorContainer().values();
			DataAccessor da;
			for (Iterator it = dac.iterator(); it.hasNext(); DataAccessFactoryFactory.getInstance().putDataAccessFactory(da.getId(), da.getClazz(), da.getUrl()))
				da = (DataAccessor)it.next();

			String codemapping = System.getProperty("code-mapping");
			if (codemapping == null)
				codemapping = getInitParameter("code-mapping");
			MessageCodeMapping.getMapping(getServletContext().getRealPath("/") + codemapping);
			String attributemapping = System.getProperty("attribute-mapping");
			if (attributemapping == null)
				attributemapping = getInitParameter("attribute-mapping");
			ClassAttributeMapping.getMapping(getServletContext().getRealPath("/") + attributemapping);
			rootPath = getServletContext().getRealPath("/");
			destroy();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
