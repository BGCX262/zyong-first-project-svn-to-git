// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletRequestParamScope.java

package org.flive.control_logic.namespace;

import java.net.URLDecoder;
import java.util.*;
import javax.servlet.http.HttpServletRequest;

// Referenced classes of package org.flive.control_logic.namespace:
//			ScopeAdapter

public class ServletRequestParamScope
	implements ScopeAdapter
{

	protected HttpServletRequest request;

	public ServletRequestParamScope(HttpServletRequest req)
	{
		request = null;
		request = req;
	}

	public Object getValue(String name)
	{
		try
		{
			String ret[] = request.getParameterValues(name);
			if (ret == null)
				return null;
			for (int i = 0; i < ret.length; i++)
				ret[i] = URLDecoder.decode(ret[i], "UTF-8");

			if (ret.length == 1)
				return ret[0];
			else
				return ret;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public void setValue(String s, Object obj1)
	{
	}

	public void removeValue(String s)
	{
	}

	public Set getNames()
	{
		Set set = new HashSet();
		for (Enumeration enumer = request.getParameterNames(); enumer.hasMoreElements();)
			try
			{
				String name = URLDecoder.decode(enumer.nextElement().toString(), "UTF-8");
				if (!name.equals("func_id") && !name.equals("style_type"))
					set.add(name);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}

		return set;
	}

	public String getScopeName()
	{
		return "request_param";
	}

	public String toString()
	{
		Set names = getNames();
		StringBuffer ret = new StringBuffer();
		ret.append("Scope ").append(getScopeName()).append(": ");
		String name;
		for (Iterator it = names.iterator(); it.hasNext(); ret.append(name).append("=").append(request.getParameter(name)).append(", "))
			name = (String)it.next();

		return ret.toString();
	}
}
