// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HasNotPrivilegException.java

package org.flive.control_logic.listener;


public class HasNotPrivilegException extends Exception
{

	private static final long serialVersionUID = 1L;

	public HasNotPrivilegException(String user_id)
	{
		super("Current user has not any privilege : " + user_id);
	}
}
