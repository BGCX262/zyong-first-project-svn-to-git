// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SchedulerListenerImpl.java

package org.flive.control_logic.listener;


// Referenced classes of package org.flive.control_logic.listener:
//			ListenerAdapter, FilterAdapter

public class SchedulerListenerImpl
	implements ListenerAdapter
{

	public SchedulerListenerImpl()
	{
	}

	public void listen()
	{
	}

	public int send(String output)
	{
		return 0;
	}

	public void wrap()
	{
	}

	public void addFilter(FilterAdapter filteradapter)
	{
	}

	public String getProtocol()
	{
		return null;
	}

	public String getServiceName()
	{
		return null;
	}

	public String getServerAddress()
	{
		return null;
	}

	public int getServerPort()
	{
		return 0;
	}
}
