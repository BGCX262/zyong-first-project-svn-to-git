// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ListenerCallbackHandler.java

package org.flive.control_logic.listener;

import org.flive.control_logic.message.MessageAdapter;

// Referenced classes of package org.flive.control_logic.listener:
//			ListenerAdapter

public interface ListenerCallbackHandler
{

	public abstract void handle(ListenerAdapter listeneradapter, MessageAdapter messageadapter);
}
