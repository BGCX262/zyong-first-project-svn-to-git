// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletAppScope.java

package org.flive.control_logic.namespace;

import java.util.*;
import javax.servlet.ServletContext;

// Referenced classes of package org.flive.control_logic.namespace:
//			ScopeAdapter

public class ServletAppScope
	implements ScopeAdapter
{

	protected ServletContext app;

	public ServletAppScope(ServletContext app)
	{
		this.app = null;
		this.app = app;
	}

	public Object getValue(String name)
	{
		return app.getAttribute(name);
	}

	public void setValue(String name, Object obj)
	{
		app.setAttribute(name, obj);
	}

	public void removeValue(String name)
	{
		app.removeAttribute(name);
	}

	public Set getNames()
	{
		Set set = new HashSet();
		for (Enumeration enumer = app.getAttributeNames(); enumer.hasMoreElements(); set.add(enumer.nextElement().toString()));
		return set;
	}

	public String getScopeName()
	{
		return "application";
	}

	public String toString()
	{
		Set names = getNames();
		StringBuffer ret = new StringBuffer();
		ret.append("Scope ").append(getScopeName()).append(": ");
		String name;
		for (Iterator it = names.iterator(); it.hasNext(); ret.append(name).append("=").append(app.getAttribute(name)).append(", "))
			name = (String)it.next();

		return ret.toString();
	}
}
