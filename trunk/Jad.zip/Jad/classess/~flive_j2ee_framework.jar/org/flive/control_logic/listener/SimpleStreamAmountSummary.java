// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SimpleStreamAmountSummary.java

package org.flive.control_logic.listener;

import java.util.Date;
import org.apache.log4j.Logger;
import org.flive.configuration.*;
import org.flive.control_logic.namespace.NameSpaceFactory;
import org.flive.control_logic.namespace.ScopeAdapter;

// Referenced classes of package org.flive.control_logic.listener:
//			StreamAmountSummary

public class SimpleStreamAmountSummary
	implements StreamAmountSummary
{

	private NameSpaceFactory namespace;
	private Configuration config;
	private int amount;
	static Logger log;

	public SimpleStreamAmountSummary()
	{
		try
		{
			namespace = NameSpaceFactory.getInstance();
			config = ConfigurationFactory.getInstance().get();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public String getUser()
	{
		try
		{
			return namespace.getScope("session").getValue("user").toString();
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public String getFunctionDescription()
	{
		try
		{
			String func_id = (String)namespace.getScope("request_param").getValue("func_id");
			return config.getFunction(func_id).getDescription();
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public String getStyleDescription()
	{
		try
		{
			String style_type = (String)namespace.getScope("request_param").getValue("style_type");
			return style_type;
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public String getTimestamp()
	{
		try
		{
			Date date = new Date();
			return date.toString();
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public int getAmount()
	{
		return amount;
	}

	public void record(int size)
	{
		amount = size;
		log.info(this);
	}

	public String toString()
	{
		return getTimestamp() + " : " + getUser() + ":" + getFunctionDescription() + ":" + getStyleDescription() + ":" + getAmount();
	}

	static 
	{
		log = Logger.getLogger(org.flive.control_logic.listener.SimpleStreamAmountSummary.class.getName());
	}
}
