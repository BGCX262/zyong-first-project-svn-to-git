// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletListenerImpl.java

package org.flive.control_logic.listener;

import java.io.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import org.flive.configuration.*;
import org.flive.control_logic.message.InitMessage;
import org.flive.control_logic.message.ServletMessageImpl;
import org.flive.control_logic.namespace.*;
import org.flive.util.VariableUtil;
import org.flive.util.cache.CacheAdapter;
import org.flive.util.security.Digest;
import org.flive.wrapper.style_wrap.WrapperAdapter;
import org.flive.wrapper.style_wrap.XMLError;

// Referenced classes of package org.flive.control_logic.listener:
//			ListenerAdapter, ListenerCallbackImpl, FilterAdapter, StyleNameNotExistException, 
//			FunctionIdNotExistExceptoin, StreamAmountSummary

public class ServletListenerImpl extends HttpServlet
	implements ListenerAdapter
{

	private static final long serialVersionUID = 1L;
	private ArrayList filters;
	private boolean isInit;
	private static final String FUNC_ID = "func_id";
	private static final String STYLE_TYPE = "style_type";
	private static final String FILTER_NAME = "filter-provider";
	private static NameSpaceFactory namespace = null;
	private static StreamAmountSummary summary = null;
	private static CacheAdapter cache = null;
	private static Configuration config = null;
	static Logger log;
	private String serviceName;
	private String serverAddress;
	private String protocol;
	private int port;

	public ServletListenerImpl()
	{
		isInit = false;
	}

	public void listen()
	{
	}

	private ScopeAdapter getScope(String scope_name)
	{
		try
		{
			return namespace.getScope(scope_name);
		}
		catch (ScopeNotFoundException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public void init()
	{
		try
		{
			if (config == null)
				config = ConfigurationFactory.getInstance().get();
			if (cache == null)
				cache = (CacheAdapter)Class.forName(config.getCacheProvider()).newInstance();
			namespace = NameSpaceFactory.getInstance();
			ScopeAdapter scope = new ServletAppScope(getServletContext());
			namespace.register(scope.getScopeName(), scope);
			InitMessage msg = new InitMessage();
			isInit = true;
			ListenerCallbackImpl handler = new ListenerCallbackImpl();
			handler.handle(this, msg);
			isInit = false;
			filters = new ArrayList();
			String filter = System.getProperty("filter-provider");
			if (filter == null)
				filter = getInitParameter("filter-provider");
			if (filter == null)
				return;
			addFilter((FilterAdapter)Class.forName(filter).newInstance());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public int send(String output)
	{
		return 0;
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException
	{
		process(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException
	{
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException
	{
		String style_class_name = null;
		WrapperAdapter wrapper = null;
		Style style = null;
		XMLError error = null;
		ServletMessageImpl msg = new ServletMessageImpl(request, response);
		ScopeAdapter scope = new ServletRequestScope(request);
		namespace.register(scope.getScopeName(), scope);
		scope = new ServletRequestParamScope(request);
		namespace.register(scope.getScopeName(), scope);
		scope = new WrapperScope(request);
		namespace.register(scope.getScopeName(), scope);
		scope = new ServletSessionScope(request.getSession());
		namespace.register(scope.getScopeName(), scope);
		String style_name = msg.getValue("style_type");
		String func_id = msg.getValue("func_id");
		Function function = null;
		try
		{
			if (style_name == null)
				throw new StyleNameNotExistException();
			if (func_id == null)
				throw new FunctionIdNotExistExceptoin();
			style = config.getStyle(style_name);
			function = config.getFunction(func_id);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			printError(e, response);
			return;
		}
		try
		{
			wrapper = (WrapperAdapter)style.getStyleClass().newInstance();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			printError(e, response);
			return;
		}
		getScope("request").setValue("__wrapper", wrapper);
		ListenerCallbackImpl reveiveHandler = new ListenerCallbackImpl();
		try
		{
			String encoding = style.getEncoding();
			String content_type = style.getContentType();
			response.setContentType(content_type + "; charset=" + encoding);
			if (function.isImmediately())
			{
				response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
				response.setHeader("Pragma", "no-cache");
				response.setHeader("Expires", "Thu, 01 Dec 1994 00:00:00 GMT");
			}
			DataOutputStream data = new DataOutputStream(response.getOutputStream());
			namespace.getScope("request").setValue("__byteamount_outputstream", data);
			wrapper.setOutput(data);
			if (getRequestResultFromCache(function, style_name))
			{
				wrapper.wrap(style, getScope("wrapper"));
				return;
			}
			if (error == null)
			{
				reveiveHandler.handle(this, msg);
			} else
			{
				getScope("wrapper").setValue("error", error);
				wrap();
			}
		}
		catch (Exception e)
		{
			printError(e, response);
			e.printStackTrace();
		}
	}

	public void wrap()
	{
		try
		{
			if (isInit)
				return;
			if (getScope("wrapper").getNames().isEmpty())
			{
				XMLError error = new XMLError("-100", "processor unknown error");
				namespace.getScope("wrapper").setValue("error", error);
			}
			WrapperAdapter wrapper = (WrapperAdapter)getScope("request").getValue("__wrapper");
			String style_type = (String)getScope("request_param").getValue("style_type");
			Configuration config = ConfigurationFactory.getInstance().get();
			log.debug("begin wrap the display data. style type is : " + style_type + ". the contents in wrapper scope are : " + namespace.getScope("wrapper"));
			wrapper.wrap(config.getStyle(style_type), getScope("wrapper"));
			DataOutputStream data = (DataOutputStream)namespace.getScope("request").getValue("__byteamount_outputstream");
			int amount = data.size();
			if (summary == null)
				summary = (StreamAmountSummary)Class.forName(config.getAmountSummary()).newInstance();
			summary.record(amount);
			putResponseToCache();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private String replaceValue(String variable)
	{
		List list = VariableUtil.findVariable(variable);
		if (list == null)
		{
			return variable;
		} else
		{
			String var = (String)list.get(0);
			Object ret = VariableUtil.getScopeVariable(var);
			return ret.toString();
		}
	}

	public void addFilter(FilterAdapter filter)
	{
		filters.add(filter);
	}

	public void destory()
	{
		super.destroy();
	}

	private static void printError(Exception e, HttpServletResponse response)
	{
		response.setContentType("text/xml;charset=GBK");
		try
		{
			XMLError error = new XMLError(e.getClass().getName(), e.getMessage());
			if (response == null)
				throw e;
			response.getWriter().write(error.toXML());
		}
		catch (Exception e1)
		{
			e1.printStackTrace();
		}
	}

	public String getProtocol()
	{
		return protocol;
	}

	public String getServiceName()
	{
		return serviceName;
	}

	public String getServerAddress()
	{
		return serverAddress;
	}

	public int getServerPort()
	{
		return port;
	}

	private boolean getRequestResultFromCache(Function function, String style_name)
	{
		int expired = function.getExpired();
		if (function.getExpired() <= -1)
			return false;
		String key = null;
		String whole_query = (String)getScope("request").getValue("__query_string");
		if (whole_query == null)
			return false;
		String style_str = "style_type=" + style_name;
		whole_query = whole_query.replaceFirst(style_str, "");
		whole_query = whole_query + "&user=" + getScope("session").getValue("user").toString();
		Digest digest = new Digest("MD5");
		key = digest.digest(whole_query);
		Object obj = cache.getFormCache(key, expired);
		if (obj == null)
		{
			cache.erase(key);
			getScope("request").setValue("__cache_key", key);
			return false;
		} else
		{
			WrapperScope wrapper = (WrapperScope)getScope("wrapper");
			wrapper.restore(obj);
			return true;
		}
	}

	private void putResponseToCache()
	{
		String key = (String)getScope("request").getValue("__cache_key");
		if (key == null)
		{
			return;
		} else
		{
			WrapperScope wrapper = (WrapperScope)getScope("wrapper");
			cache.putToCache(key, wrapper.dump());
			return;
		}
	}

	static 
	{
		log = Logger.getLogger(org.flive.control_logic.listener.ListenerCallbackImpl.class.getName());
	}
}
