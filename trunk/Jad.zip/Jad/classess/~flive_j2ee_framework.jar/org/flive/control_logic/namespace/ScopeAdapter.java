// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ScopeAdapter.java

package org.flive.control_logic.namespace;

import java.util.Set;

public interface ScopeAdapter
{

	public abstract Object getValue(String s);

	public abstract void setValue(String s, Object obj);

	public abstract void removeValue(String s);

	public abstract Set getNames();

	public abstract String getScopeName();
}
