// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ListenerAdapter.java

package org.flive.control_logic.listener;


// Referenced classes of package org.flive.control_logic.listener:
//			FilterAdapter

public interface ListenerAdapter
{

	public abstract void listen();

	public abstract int send(String s);

	public abstract void wrap();

	public abstract void addFilter(FilterAdapter filteradapter);

	public abstract String getProtocol();

	public abstract String getServiceName();

	public abstract String getServerAddress();

	public abstract int getServerPort();
}
