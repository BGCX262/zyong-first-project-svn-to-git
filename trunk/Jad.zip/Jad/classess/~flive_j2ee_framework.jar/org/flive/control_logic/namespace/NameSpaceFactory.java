// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NameSpaceFactory.java

package org.flive.control_logic.namespace;

import java.util.HashMap;
import java.util.Map;
import org.flive.util.ObjectThread;

// Referenced classes of package org.flive.control_logic.namespace:
//			ScopeNotFoundException, ScopeAdapter

public class NameSpaceFactory
{

	public static final String RESPONSE = "response";
	public static final String WRAPPER = "wrapper";
	public static final String APPLICATION = "application";
	public static final String SESSION = "session";
	public static final String REQUEST = "request";
	public static final String REQUEST_PARAM = "request_param";
	protected static NameSpaceFactory namespace = null;

	protected NameSpaceFactory()
	{
	}

	public static NameSpaceFactory getInstance()
	{
		if (namespace == null)
			namespace = new NameSpaceFactory();
		return namespace;
	}

	public void register(String scope_name, ScopeAdapter obj)
	{
		Map container = (Map)ObjectThread.getInstance().get("__namespace");
		if (container == null)
		{
			container = new HashMap();
			ObjectThread.getInstance().put("__namespace", container);
		}
		container.put(scope_name, obj);
	}

	public ScopeAdapter getScope(String scope_name)
		throws ScopeNotFoundException
	{
		Map container = (Map)ObjectThread.getInstance().get("__namespace");
		Object scope = container.get(scope_name);
		if (scope == null)
			throw new ScopeNotFoundException(scope_name);
		else
			return (ScopeAdapter)scope;
	}

	public boolean hasScope(String scope_name)
	{
		Map container = (Map)ObjectThread.getInstance().get("__namespace");
		return container.containsKey(scope_name);
	}

}
