// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WrapperScope.java

package org.flive.control_logic.namespace;

import java.util.*;
import javax.servlet.http.HttpServletRequest;

// Referenced classes of package org.flive.control_logic.namespace:
//			ScopeAdapter

public class WrapperScope
	implements ScopeAdapter
{

	protected static final String Wrapper = "__wrapper_map";
	protected HttpServletRequest request;

	public WrapperScope(HttpServletRequest request)
	{
		this.request = null;
		Map wrapper = new HashMap();
		this.request = request;
		request.setAttribute("__wrapper_map", wrapper);
	}

	public Object getValue(String name)
	{
		Map wrapper = (Map)request.getAttribute("__wrapper_map");
		return wrapper.get(name);
	}

	public void setValue(String name, Object obj)
	{
		Map wrapper = (Map)request.getAttribute("__wrapper_map");
		wrapper.put(name, obj);
	}

	public void removeValue(String name)
	{
		Map wrapper = (Map)request.getAttribute("__wrapper_map");
		wrapper.remove(name);
	}

	public Set getNames()
	{
		Map wrapper = (Map)request.getAttribute("__wrapper_map");
		return wrapper.keySet();
	}

	public String getScopeName()
	{
		return "wrapper";
	}

	public String toString()
	{
		Map wrapper = (Map)request.getAttribute("__wrapper_map");
		return "Scope " + getScopeName() + ": " + wrapper.toString();
	}

	public Object dump()
	{
		return request.getAttribute("__wrapper_map");
	}

	public void restore(Object obj)
	{
		request.setAttribute("__wrapper_map", obj);
	}
}
