// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletMessageImpl.java

package org.flive.control_logic.message;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Referenced classes of package org.flive.control_logic.message:
//			MessageAdapter

public class ServletMessageImpl
	implements MessageAdapter
{

	private HttpServletRequest request;
	private HttpServletResponse response;

	public ServletMessageImpl(HttpServletRequest req, HttpServletResponse resp)
	{
		request = req;
		response = resp;
	}

	public String getValue(String name)
	{
		return request.getParameter(name);
	}
}
