// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletSessionScope.java

package org.flive.control_logic.namespace;

import java.util.*;
import javax.servlet.http.HttpSession;

// Referenced classes of package org.flive.control_logic.namespace:
//			ScopeAdapter

public class ServletSessionScope
	implements ScopeAdapter
{

	protected HttpSession session;

	public ServletSessionScope(HttpSession ses)
	{
		session = null;
		session = ses;
		session.setAttribute("__session_id", session.getId());
		session.setAttribute("__last_accessed_time", new Long(session.getLastAccessedTime()));
		session.setAttribute("__creation_time", new Long(session.getCreationTime()));
		session.setAttribute("__max_inactive_interval", new Integer(session.getMaxInactiveInterval()));
	}

	public Object getValue(String name)
	{
		return session.getAttribute(name);
	}

	public void setValue(String name, Object obj)
	{
		session.setAttribute(name, obj);
	}

	public void removeValue(String name)
	{
		session.removeAttribute(name);
	}

	public Set getNames()
	{
		Set set = new HashSet();
		for (Enumeration enumer = session.getAttributeNames(); enumer.hasMoreElements(); set.add(enumer.nextElement().toString()));
		return set;
	}

	public String getScopeName()
	{
		return "session";
	}

	public String toString()
	{
		Set names = getNames();
		StringBuffer ret = new StringBuffer();
		ret.append("Scope ").append(getScopeName()).append(": ");
		String name;
		for (Iterator it = names.iterator(); it.hasNext(); ret.append(name).append("=").append(session.getAttribute(name)).append(", "))
			name = (String)it.next();

		return ret.toString();
	}
}
