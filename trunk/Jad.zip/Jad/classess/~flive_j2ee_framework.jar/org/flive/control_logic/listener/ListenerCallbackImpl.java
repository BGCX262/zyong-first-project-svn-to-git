// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ListenerCallbackImpl.java

package org.flive.control_logic.listener;

import java.io.PrintStream;
import java.io.Serializable;
import java.lang.reflect.*;
import java.util.*;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import net.sf.cglib.reflect.FastClass;
import net.sf.cglib.reflect.FastMethod;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.flive.configuration.*;
import org.flive.control_logic.message.MessageAdapter;
import org.flive.control_logic.namespace.NameSpaceFactory;
import org.flive.control_logic.namespace.ScopeAdapter;
import org.flive.data_access.*;
import org.flive.jaas_module.BasePrincipal;
import org.flive.jaas_module.Handler;
import org.flive.jaas_module.user_management.RoleAdapter;
import org.flive.jaas_module.user_management.UserAdapter;
import org.flive.util.*;
import org.flive.wrapper.style_wrap.XMLError;

// Referenced classes of package org.flive.control_logic.listener:
//			ListenerCallbackHandler, UserNotFoundInSessoinException, HasNotPrivilegException, CanNotAccessSpecialFunction, 
//			ListenerAdapter

public class ListenerCallbackImpl
	implements Serializable, ListenerCallbackHandler
{

	private static final long serialVersionUID = 1L;
	private NameSpaceFactory namespace;
	static final String FUNC_ID = "func_id";
	private static final String SESSION_USER = "user";
	private static final String USER_NAME = "user_name";
	private static final int NO_USER_RIGHT = -401;
	private static final String JAAS_LOGIN_FUNCTION_ID = "jaas_login";
	private static final String JAAS_LOGOUT_FUNCTION_ID = "jaas_logout";
	private static final String JAAS_LOGIN_MODULE_NAME = "FliveJAAS";
	static Logger log;

	public ListenerCallbackImpl()
	{
	}

	public void handle(ListenerAdapter listener, MessageAdapter msg)
	{
		XMLError error;
		String currentFunc;
		ContextAdapter context;
		TransactionAdapter t;
		Function f;
		Step step;
		error = null;
		if (namespace == null)
			namespace = NameSpaceFactory.getInstance();
		currentFunc = msg.getValue("func_id");
		DataAccessFactoryAdapter factory = null;
		context = null;
		t = null;
		f = null;
		step = null;
		ObjectThread objectThread;
		UserAdapter user;
		List steps;
		int step_index;
		Configuration config = ConfigurationFactory.getInstance().get();
		objectThread = ObjectThread.getInstance();
		f = config.getFunction(currentFunc);
		DataAccessFactoryAdapter factory = DataAccessFactoryFactory.getInstance().getDataAccessFactory(f.getDataAccessor());
		context = factory.createContext();
		objectThread.put("data_access_factory", factory);
		user = null;
		if (f.isSecurity())
		{
			user = (UserAdapter)namespace.getScope("session").getValue("user");
			if (user == null)
				throw new UserNotFoundInSessoinException();
			boolean hasPrivilege = false;
			Iterator it = user.iterateRole();
			if (it == null)
				throw new HasNotPrivilegException(user.getName());
			while (it.hasNext()) 
			{
				RoleAdapter role = (RoleAdapter)it.next();
				Object resource = VariableUtil.getScopeVariable(f.getAclKey());
				if (role.hasPrivilege(f.getACLType(), resource))
				{
					hasPrivilege = true;
					break;
				}
			}
			if (!hasPrivilege)
				throw new CanNotAccessSpecialFunction(user.getName() + " | " + f.getId());
		}
		if (f.isTransaction())
			t = context.beginTransaction();
		steps = f.getSteps();
		step_index = 0;
		if (steps.isEmpty())
			step = null;
		else
			step = (Step)steps.get(step_index);
		  goto _L1
_L6:
		Ref stepRef;
		String refType;
		log.debug("invoking function " + f.getId() + " : " + f.getDescription() + " step " + step.getId() + " , description :" + step.getDescription());
		List logs = step.getLogs();
		if (logs != null && !logs.isEmpty())
			executeLog(namespace, logs);
		String expression = step.getCondition();
		if (expression != null)
		{
			expression = VariableUtil.replaceVariable(expression);
			if (!ExpressionUtil.calculate(expression))
			{
				if (steps.size() > step_index + 1)
					step = (Step)steps.get(++step_index);
				else
					step = null;
				continue; /* Loop/switch isn't completed */
			}
		}
		String filters[] = step.getDataFilters();
		if (filters != null && filters.length != 0)
		{
			Iterator it = user.iterateRole();
			if (it != null)
			{
				HashMap map = new HashMap();
				while (it.hasNext()) 
				{
					RoleAdapter role = (RoleAdapter)it.next();
					for (int ii = 0; ii < filters.length; ii++)
					{
						Iterator itt = role.iteratePrivilege(filters[ii]);
						if (itt != null)
							for (; itt.hasNext(); map.put(filters[ii], itt.next()));
					}

				}
				if (!map.isEmpty())
					objectThread.put("pri_map", map);
			}
		}
		stepRef = step.getRef();
		refType = stepRef.getType();
		if (!refType.equals(Ref.JAVA_TYPE)) goto _L3; else goto _L2
_L2:
		String refScope;
		String beanClassName;
		Object bean;
		Object returnObject;
		Object obj[];
		Class argClass[];
		String javabeanMethod;
		String name;
		refScope = stepRef.getScope();
		String refContent = stepRef.getContent();
		String refName = stepRef.getName();
		beanClassName = null;
		bean = null;
		FastClass beanClass = null;
		returnObject = null;
		int index = refContent.lastIndexOf(".");
		List args = step.getArgs();
		obj = (Object[])null;
		int argsSize = 0;
		Class argItemClass[];
		if (args != null)
		{
			argsSize = args.size();
			obj = new Object[argsSize];
			argClass = new Class[argsSize];
			argItemClass = new Class[argsSize];
		} else
		{
			argClass = new Class[0];
			argItemClass = new Class[0];
		}
		String argValue = null;
		for (int j = 0; j < argsSize; j++)
		{
			Arg arg = (Arg)args.get(j);
			Class arg_type = arg.getRealType();
			Class arg_item_type = arg.getRealItemType();
			argClass[j] = arg_type;
			argItemClass[j] = arg_item_type;
			argValue = arg.getValue();
			obj[j] = VariableUtil.getArgValue(argClass[j], argItemClass[j], argValue);
		}

		javabeanMethod = refContent.substring(index + 1, refContent.length());
		name = refName;
		beanClassName = VariableUtil.getClassName(refContent);
		FastMethod method1 = null;
		FastClass beanClass = FastClass.create(Class.forName(beanClassName));
		FastMethod method1 = beanClass.getMethod(javabeanMethod, argClass);
		if (Modifier.isStatic(method1.getModifiers()))
		{
			returnObject = method1.invoke(null, obj);
		} else
		{
			if (refScope != null)
				bean = namespace.getScope(refScope).getValue(name);
			if (bean == null)
				bean = Class.forName(beanClassName).newInstance();
			returnObject = method1.invoke(bean, obj);
		}
		  goto _L4
		Error ce;
		ce;
		error = errorInStep(ce, f, step);
		ce.printStackTrace();
		try
		{
			if (error != null)
				if (org.flive.control_logic.message.InitMessage.class.isInstance(msg))
					log.error("The ERROR is happen in system initializtion. " + error.toXML());
				else
					namespace.getScope("wrapper").setValue("error", error);
			listener.wrap();
		}
		catch (Exception he)
		{
			he.printStackTrace();
		}
		if (context != null)
		{
			context.close();
			context = null;
		}
		return;
		Exception ee;
		ee;
		error = errorInStep(ee, f, step);
		ee.printStackTrace();
		try
		{
			if (error != null)
				if (org.flive.control_logic.message.InitMessage.class.isInstance(msg))
					log.error("The ERROR is happen in system initializtion. " + error.toXML());
				else
					namespace.getScope("wrapper").setValue("error", error);
			listener.wrap();
		}
		catch (Exception he)
		{
			he.printStackTrace();
		}
		if (context != null)
		{
			context.close();
			context = null;
		}
		return;
_L4:
		ReturnValue rv = step.getReturnValue();
		if (rv != null)
		{
			String returnScope = rv.getScope();
			String returnName = rv.getName();
			String rss[] = returnScope.split(",");
			String rns[] = returnName.split(",");
			for (int i = 0; i < rss.length; i++)
				namespace.getScope(rss[i]).setValue(rns[i], returnObject);

		}
_L3:
		Monitor monitor = step.getMonitor();
		if (monitor != null)
			executeMonitor(monitor);
		Redirect red = step.getRedirect();
		if (red == null)
		{
			if (steps.size() > step_index + 1)
				step = (Step)steps.get(++step_index);
			else
				step = null;
		} else
		{
			ArrayList tos = red.getTos();
			int i;
			for (i = 0; i < tos.size(); i++)
			{
				To to = (To)tos.get(i);
				String express = to.getCondition();
				express = VariableUtil.replaceVariable(express);
				if (!ExpressionUtil.calculate(express))
					continue;
				int m = to.getTarget();
				step = f.getStepById(m);
				step_index = f.getCurrentStepIndex();
				break;
			}

			if (i >= tos.size())
				if (steps.size() > step_index + 1)
					step = (Step)steps.get(++step_index);
				else
					step = null;
		}
_L1:
		if (step != null) goto _L6; else goto _L5
_L5:
		try
		{
			if (f.isTransaction())
			{
				Set set = namespace.getScope("wrapper").getNames();
				Iterator it = set.iterator();
				Object ret = null;
				if (it.hasNext())
					ret = it.next();
				if (!(ret instanceof Number))
				{
					if (!t.wasCommited())
						t.commit();
				} else
				{
					double ret_value = ((Number)ret).doubleValue();
					if (ret_value >= 0.0D && !t.wasCommited())
						t.commit();
				}
			}
			break MISSING_BLOCK_LABEL_2081;
		}
		catch (Exception he)
		{
			he.printStackTrace();
			log.error("The Exception is happen in the transactional function, the transaction is roolbacked by controller : " + f.getId());
			error = errorInStep(he, f, step);
			t.rollback();
		}
		try
		{
			if (error != null)
				if (org.flive.control_logic.message.InitMessage.class.isInstance(msg))
					log.error("The ERROR is happen in system initializtion. " + error.toXML());
				else
					namespace.getScope("wrapper").setValue("error", error);
			listener.wrap();
		}
		catch (Exception he)
		{
			he.printStackTrace();
		}
		if (context != null)
		{
			context.close();
			context = null;
		}
		return;
		Exception e;
		e;
		e.printStackTrace();
		error = errorInStep(e, f, step);
		try
		{
			if (f.isTransaction())
			{
				log.error("The Exception is happen in the transactional function, the transaction is roolbacked by controller : " + f.getId());
				t.rollback();
			}
		}
		catch (Exception he)
		{
			he.printStackTrace();
		}
		break MISSING_BLOCK_LABEL_2081;
		Exception exception;
		exception;
		try
		{
			if (error != null)
				if (org.flive.control_logic.message.InitMessage.class.isInstance(msg))
					log.error("The ERROR is happen in system initializtion. " + error.toXML());
				else
					namespace.getScope("wrapper").setValue("error", error);
			listener.wrap();
		}
		catch (Exception he)
		{
			he.printStackTrace();
		}
		if (context != null)
		{
			context.close();
			context = null;
		}
		throw exception;
		try
		{
			if (error != null)
				if (org.flive.control_logic.message.InitMessage.class.isInstance(msg))
					log.error("The ERROR is happen in system initializtion. " + error.toXML());
				else
					namespace.getScope("wrapper").setValue("error", error);
			listener.wrap();
		}
		catch (Exception he)
		{
			he.printStackTrace();
		}
		if (context != null)
		{
			context.close();
			context = null;
		}
		return;
	}

	private void executeLog(NameSpaceFactory namespace, List ls)
	{
		String content;
		Level level;
		for (Iterator it = ls.iterator(); it.hasNext(); log.log(level, content))
		{
			Log l = (Log)it.next();
			content = VariableUtil.replaceVariable(l.getContent());
			level = Level.toLevel(l.getLevel());
		}

	}

	private void executeMonitor(Monitor monitor1)
	{
	}

	private static LoginContext _login(String username, char credentials[])
	{
		LoginContext loginContext;
		try
		{
			javax.security.auth.callback.CallbackHandler cb = new Handler(username, credentials);
			loginContext = new LoginContext("FliveJAAS", cb);
		}
		catch (LoginException e)
		{
			e.printStackTrace();
			return null;
		}
		Subject subject = null;
		try
		{
			loginContext.login();
			subject = loginContext.getSubject();
			if (subject == null)
				return null;
		}
		catch (Exception e)
		{
			System.err.print(e.getLocalizedMessage());
			return null;
		}
		return loginContext;
	}

	private static Object objectWrapFromNameSpace(Class cls, NameSpaceFactory name_space, String scope_name)
	{
		Object ret = null;
		try
		{
			ret = cls.newInstance();
			do
			{
				Field flds[] = cls.getDeclaredFields();
				for (int i = 0; i < flds.length; i++)
				{
					String fld_name = flds[i].getName();
					Class attribute_cls = flds[i].getType();
					Class seter_params[] = {
						attribute_cls
					};
					Object param_value[] = new Object[1];
					if (Modifier.isStatic(flds[i].getModifiers()))
						continue;
					String av = (String)name_space.getScope(scope_name).getValue(flds[i].getName());
					if (av == null)
						continue;
					String attribute_value = av;
					String seter_method = "set" + (char)(fld_name.charAt(0) - 32) + fld_name.substring(1);
					if (attribute_value == null)
						continue;
					if (attribute_cls == java.lang.String.class)
					{
						param_value[0] = new String(attribute_value.getBytes("iso8859-1"));
						cls.getMethod(seter_method, seter_params).invoke(ret, param_value);
						continue;
					}
					if (attribute_cls.isArray())
					{
						Class com_cls = attribute_cls.getComponentType();
						String rlt[] = (String[])name_space.getScope(scope_name).getValue(flds[i].getName());
						if (com_cls == java.lang.String.class)
						{
							String lt[] = new String[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = new String(rlt[j].getBytes("iso8859-1"));

							param_value[0] = lt;
						}
						if (!com_cls.isPrimitive())
							continue;
						String cls_type = com_cls.getName();
						if (cls_type.equals("int"))
						{
							int lt[] = new int[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = Integer.parseInt(rlt[j]);

							param_value[0] = lt;
						} else
						if (cls_type.equals("long"))
						{
							long lt[] = new long[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = Long.parseLong(rlt[j]);

							param_value[0] = lt;
						} else
						if (cls_type.equals("short"))
						{
							short lt[] = new short[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = Short.parseShort(rlt[j]);

							param_value[0] = lt;
						} else
						if (cls_type.equals("byte"))
						{
							byte lt[] = new byte[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = Byte.parseByte(rlt[j]);

							param_value[0] = lt;
						} else
						if (cls_type.equals("char"))
						{
							char lt[] = new char[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = rlt[j].charAt(0);

							param_value[0] = lt;
						} else
						if (cls_type.equals("boolean"))
						{
							boolean lt[] = new boolean[rlt.length];
							for (int j = 0; j < rlt.length; j++)
								lt[j] = Boolean.getBoolean(rlt[j]);

							param_value[0] = lt;
						}
						cls.getMethod(seter_method, seter_params).invoke(ret, param_value);
					}
					if (attribute_cls.isPrimitive())
					{
						if (attribute_cls == Double.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Double((0.0D / 0.0D));
							else
								param_value[0] = new Double(attribute_value);
						} else
						if (attribute_cls == Integer.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Integer(0x80000000);
							else
								param_value[0] = new Integer(attribute_value);
						} else
						if (attribute_cls == Long.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Long(0x8000000000000000L);
							else
								param_value[0] = new Long(attribute_value);
						} else
						if (attribute_cls == Float.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Float((0.0F / 0.0F));
							else
								param_value[0] = new Float(attribute_value);
						} else
						if (attribute_cls == Character.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Character('\0');
							else
								param_value[0] = new Character(attribute_value.charAt(0));
						} else
						if (attribute_cls == Byte.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Byte((byte)-128);
							param_value[0] = new Byte(attribute_value);
						} else
						if (attribute_cls == Short.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = new Short((short)-32768);
							param_value[0] = new Short(attribute_value);
						} else
						if (attribute_cls == Boolean.TYPE)
						{
							if (attribute_value == null)
								param_value[0] = Boolean.TYPE;
							param_value[0] = new Boolean(attribute_value);
						}
						cls.getMethod(seter_method, seter_params).invoke(ret, param_value);
					}
				}

				cls = cls.getSuperclass();
			} while (!cls.getName().equals("java.lang.Object"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	public static UserAdapter login(String user_name, String pwd)
	{
		try
		{
			LoginContext loginContext = _login(user_name, pwd.toCharArray());
			if (loginContext == null)
			{
				log.error("The user try to login systerm but failed : " + user_name);
				return null;
			} else
			{
				BasePrincipal pal = (BasePrincipal)loginContext.getSubject().getPrincipals().iterator().next();
				UserAdapter user = pal.getUser();
				loginContext.logout();
				return user;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	private static XMLError errorInStep(Throwable e, Function f, Step step)
	{
		if (e.getMessage() == null)
			if (java.lang.reflect.InvocationTargetException.class.isInstance(e))
				e = ((InvocationTargetException)e).getTargetException();
			else
				e = e.getCause();
		XMLError error = new XMLError(e.getClass().getName(), "Can not invoke special step : function " + f.getId() + " : step " + step.getId() + ". \r\n" + "caused by : " + e.getMessage());
		return error;
	}

	static 
	{
		log = Logger.getLogger(org.flive.control_logic.listener.ListenerCallbackImpl.class.getName());
	}
}
