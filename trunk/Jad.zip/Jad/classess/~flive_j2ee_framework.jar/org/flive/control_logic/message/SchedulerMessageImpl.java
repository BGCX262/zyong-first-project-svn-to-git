// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SchedulerMessageImpl.java

package org.flive.control_logic.message;

import org.flive.configuration.Function;

// Referenced classes of package org.flive.control_logic.message:
//			MessageAdapter

public class SchedulerMessageImpl
	implements MessageAdapter
{

	private Function function;

	public SchedulerMessageImpl(Function func)
	{
		function = func;
	}

	public String getValue(String name)
	{
		if (name.equals("func_id"))
			return function.getId();
		else
			return null;
	}
}
