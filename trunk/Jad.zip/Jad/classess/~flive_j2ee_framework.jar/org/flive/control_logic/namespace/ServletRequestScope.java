// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletRequestScope.java

package org.flive.control_logic.namespace;

import java.util.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

// Referenced classes of package org.flive.control_logic.namespace:
//			ScopeAdapter

public class ServletRequestScope
	implements ScopeAdapter
{

	protected HttpServletRequest request;

	public ServletRequestScope(HttpServletRequest req)
	{
		request = null;
		request = req;
		request.setAttribute("__auth_type", request.getAuthType());
		request.setAttribute("__character_encoding", request.getCharacterEncoding());
		request.setAttribute("__content_type", request.getContentType());
		request.setAttribute("__content_length", new Integer(request.getContentLength()));
		request.setAttribute("__context_path", request.getContextPath());
		request.setAttribute("__method", request.getMethod());
		request.setAttribute("__path_info", request.getPathInfo());
		request.setAttribute("__path_translated", request.getPathTranslated());
		request.setAttribute("__protocol", request.getProtocol());
		request.setAttribute("__query_string", request.getQueryString());
		request.setAttribute("__remote_addr", request.getRemoteAddr());
		request.setAttribute("__remote_host", request.getRemoteHost());
		request.setAttribute("__remote_user", request.getRemoteUser());
		request.setAttribute("__requested_session_id", request.getRequestedSessionId());
		request.setAttribute("__request_uri", request.getRequestURI());
		request.setAttribute("__scheme", request.getScheme());
		request.setAttribute("__server_name", request.getServerName());
		request.setAttribute("__servlet_path", request.getServletPath());
		request.setAttribute("__server_port", new Integer(request.getServerPort()));
		String name;
		for (Enumeration enumer = request.getHeaderNames(); enumer.hasMoreElements(); request.setAttribute("__headers(" + name + ")", request.getHeader(name)))
			name = (String)enumer.nextElement();

		Cookie cookies[] = request.getCookies();
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
				request.setAttribute("__cookies(" + cookies[i].getName() + ")", cookies[i].getValue());

		}
	}

	public Object getValue(String name)
	{
		return request.getAttribute(name);
	}

	public void setValue(String name, Object obj)
	{
		request.setAttribute(name, obj);
	}

	public void removeValue(String name)
	{
		request.removeAttribute(name);
	}

	public Set getNames()
	{
		Set set = new HashSet();
		for (Enumeration enumer = request.getAttributeNames(); enumer.hasMoreElements(); set.add(enumer.nextElement().toString()));
		return set;
	}

	public String getScopeName()
	{
		return "request";
	}

	public HttpServletRequest getHttpServletRequest()
	{
		return request;
	}

	public String toString()
	{
		Set names = getNames();
		StringBuffer ret = new StringBuffer();
		ret.append("Scope ").append(getScopeName()).append(": ");
		String name;
		for (Iterator it = names.iterator(); it.hasNext(); ret.append(name).append("=").append(request.getAttribute(name)).append(", "))
			name = (String)it.next();

		return ret.toString();
	}
}
