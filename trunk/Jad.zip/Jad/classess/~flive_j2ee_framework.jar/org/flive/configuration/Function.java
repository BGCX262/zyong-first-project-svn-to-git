// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Function.java

package org.flive.configuration;

import java.util.ArrayList;
import java.util.List;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			Step, JiBX_MungeAdapter

public class Function
	implements IUnmarshallable, IMarshallable
{

	private String id;
	private String description;
	private boolean isSecurity;
	private boolean isTransaction;
	private String dataAccessor;
	private String aclKey;
	private String aclType;
	private boolean immediately;
	private int expired;
	private String startTime;
	private String interval;
	private ArrayList steps;
	private int index;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public Function()
	{
		index = -1;
	}

	public int getExpired()
	{
		return expired;
	}

	public void setExpired(int expired)
	{
		this.expired = expired;
	}

	public void setImmediately(boolean immediately)
	{
		this.immediately = immediately;
	}

	public String getACLType()
	{
		return aclType;
	}

	public String getDataAccessor()
	{
		return dataAccessor;
	}

	public void setDataAccessor(String dataAccessor)
	{
		this.dataAccessor = dataAccessor;
	}

	public boolean isTransaction()
	{
		return isTransaction;
	}

	public void setTransaction(boolean isTransaction)
	{
		this.isTransaction = isTransaction;
	}

	public String getDescription()
	{
		return description;
	}

	public String getId()
	{
		return id;
	}

	public List getSteps()
	{
		return steps;
	}

	public void setDescription(String string)
	{
		description = string;
	}

	public void setId(String i)
	{
		id = i;
	}

	public void setSteps(ArrayList list)
	{
		steps = list;
	}

	public Step getStepById(int id)
	{
		Step sp = null;
		int i;
		for (i = 0; i < steps.size(); i++)
		{
			sp = (Step)steps.get(i);
			if (sp.getId() == id)
				break;
		}

		if (i < steps.size())
		{
			index = i;
			return sp;
		} else
		{
			return null;
		}
	}

	public int getCurrentStepIndex()
	{
		return index;
	}

	public boolean isSecurity()
	{
		return isSecurity;
	}

	public void setSecurity(boolean b)
	{
		isSecurity = b;
	}

	public String toString()
	{
		return id;
	}

	public String getAclKey()
	{
		return aclKey;
	}

	public void setAclKey(String aclKey)
	{
		this.aclKey = aclKey;
		int index = aclKey.lastIndexOf(".");
		if (index < 0)
			aclType = aclKey;
		else
			aclType = aclKey.substring(0, index);
	}

	public boolean isImmediately()
	{
		return immediately;
	}

	public String getInterval()
	{
		return interval;
	}

	public void setInterval(String interval)
	{
		this.interval = interval;
	}

	public String getStartTime()
	{
		return startTime;
	}

	public void setStartTime(String startTime)
	{
		this.startTime = startTime;
	}

	public static Function JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Function();
	}

	public final Function JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		steps = JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(steps != null ? steps : JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1), arg1);
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(3).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(steps, arg1);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(3, "org.flive.configuration.Function").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 3;
	}

	public final Function JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_1(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		id = arg1.attributeText(null, "id");
		description = arg1.attributeText(null, "description", null);
		isSecurity = arg1.attributeBoolean(null, "security", true);
		aclKey = arg1.attributeText(null, "acl-key", "request.param.function");
		isTransaction = arg1.attributeBoolean(null, "transaction", false);
		dataAccessor = arg1.attributeText(null, "data-accessor", "default");
		immediately = arg1.attributeBoolean(null, "immediately", true);
		expired = arg1.attributeInt(null, "expired", -1);
		interval = arg1.attributeText(null, "interval", null);
		startTime = arg1.attributeText(null, "start-time", null);
		arg1.popObject();
		return this;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_1(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "id", id);
		if (description == null) goto _L2; else goto _L1
_L1:
		0;
		"description";
		description;
		attribute();
_L2:
		0;
		"security";
		isSecurity;
		if (!isSecurity) goto _L4; else goto _L3
_L3:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L5
_L4:
		Utility.serializeBoolean();
		attribute();
_L5:
		if (aclKey == null) goto _L7; else goto _L6
_L6:
		0;
		"acl-key";
		aclKey;
		if (!Utility.isEqual(aclKey, "request.param.function")) goto _L9; else goto _L8
_L8:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L7
_L9:
		attribute();
_L7:
		0;
		"transaction";
		isTransaction;
		if (isTransaction) goto _L11; else goto _L10
_L10:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L12
_L11:
		Utility.serializeBoolean();
		attribute();
_L12:
		if (dataAccessor == null) goto _L14; else goto _L13
_L13:
		0;
		"data-accessor";
		dataAccessor;
		if (!Utility.isEqual(dataAccessor, "default")) goto _L16; else goto _L15
_L15:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L14
_L16:
		attribute();
_L14:
		0;
		"immediately";
		immediately;
		if (!immediately) goto _L18; else goto _L17
_L17:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L19
_L18:
		Utility.serializeBoolean();
		attribute();
_L19:
		0;
		"expired";
		expired;
		if (expired != -1) goto _L21; else goto _L20
_L20:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L22
_L21:
		Utility.serializeInt();
		attribute();
_L22:
		if (interval == null) goto _L24; else goto _L23
_L23:
		0;
		"interval";
		interval;
		attribute();
_L24:
		if (startTime == null) goto _L26; else goto _L25
_L25:
		0;
		"start-time";
		startTime;
		attribute();
_L26:
		arg1.popObject();
		return;
	}
}
