// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageStruct.java

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class MessageStruct
	implements IUnmarshallable, IMarshallable
{

	public int id;
	public String msg_info;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public MessageStruct()
	{
	}

	public int getId()
	{
		return id;
	}

	public String getMsg_info()
	{
		return msg_info;
	}

	public void setId(int i)
	{
		id = i;
	}

	public void setMsg_info(String string)
	{
		msg_info = string;
	}

	public static MessageStruct JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new MessageStruct();
	}

	public final MessageStruct JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		id = arg1.attributeInt(null, "id");
		arg1.popObject();
		return this;
	}

	public final MessageStruct JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		msg_info = arg1.parseContentText();
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(9).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "id", Utility.serializeInt(id));
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.writeContent(msg_info);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(9, "org.flive.configuration.MessageStruct").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 9;
	}
}
