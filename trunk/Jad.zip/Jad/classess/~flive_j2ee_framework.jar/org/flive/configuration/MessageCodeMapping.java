// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageCodeMapping.java

package org.flive.configuration;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			MessageStruct

public class MessageCodeMapping
	implements IUnmarshallable, IMarshallable
{

	private HashMap messages;
	private static MessageCodeMapping codeMapping = null;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public static MessageCodeMapping getMapping(String file)
	{
		if (codeMapping != null)
			return codeMapping;
		try
		{
			IBindingFactory bfact = BindingDirectory.getFactory(org.flive.configuration.MessageCodeMapping.class);
			IUnmarshallingContext uctx = bfact.createUnmarshallingContext();
			codeMapping = (MessageCodeMapping)uctx.unmarshalDocument(new FileInputStream(file), "GBK");
			codeMapping.init();
			return codeMapping;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public MessageCodeMapping()
	{
	}

	public void init()
	{
	}

	public String getMessage(long msg_code)
	{
		MessageStruct ms = (MessageStruct)messages.get(Long.toString(msg_code));
		if (ms == null)
			return Long.toString(msg_code);
		else
			return ms.getMsg_info();
	}

	public Map getMessages()
	{
		return messages;
	}

	public static MessageCodeMapping JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new MessageCodeMapping();
	}

	public final MessageCodeMapping JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		messages = (HashMap)arg1.getUnmarshaller(16).unmarshal(messages, arg1);
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(8).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		arg1.getMarshaller(16, "java.util.HashMap").marshal(messages, arg1);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(8, "org.flive.configuration.MessageCodeMapping").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 8;
	}

}
