// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   

package org.flive.configuration;

import org.flive.util.HashMapper;
import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class JiBX_flive_j2ee_framework_jdk_1HashMapper_15 extends HashMapper
	implements IUnmarshaller, IMarshaller
{

	public JiBX_flive_j2ee_framework_jdk_1HashMapper_15()
	{
		super(null, 0, "service");
	}
}
