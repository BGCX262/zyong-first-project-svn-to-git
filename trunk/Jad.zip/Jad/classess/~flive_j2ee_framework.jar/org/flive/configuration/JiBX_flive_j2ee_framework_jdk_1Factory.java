// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class JiBX_flive_j2ee_framework_jdk_1Factory
	implements IBindingFactory
{

	private static IBindingFactory m_inst;
	private String m_marshallers[] = {
		"org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Configuration_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1DataAccessor_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Style_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Function_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Step_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Arg_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1To_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Log_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1MessageCodeMapping_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1MessageStruct_access", 
		"org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1ClassAttributeMapping_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1ClassItem_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Attribute_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_13", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_14", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_15", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_16", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_17"
	};
	private String m_unmarshallers[] = {
		"org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Configuration_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1DataAccessor_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Style_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Function_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Step_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Arg_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1To_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Log_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1MessageCodeMapping_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1MessageStruct_access", 
		"org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1ClassAttributeMapping_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1ClassItem_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Attribute_access", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_13", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_14", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_15", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_16", "org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1HashMapper_17"
	};
	private String m_classes[] = {
		"org.flive.configuration.Configuration", "org.flive.configuration.DataAccessor", "org.flive.configuration.Style", "org.flive.configuration.Function", "org.flive.configuration.Step", "org.flive.configuration.Arg", "org.flive.configuration.To", "org.flive.configuration.Log", "org.flive.configuration.MessageCodeMapping", "org.flive.configuration.MessageStruct", 
		"org.flive.configuration.ClassAttributeMapping", "org.flive.configuration.ClassItem", "org.flive.configuration.Attribute", "java.util.HashMap", "java.util.HashMap", "java.util.HashMap", "java.util.HashMap", "java.util.HashMap"
	};
	private String m_uris[] = {
		"", "http://www.w3.org/XML/1998/namespace"
	};
	private String m_prefixes[] = {
		""
	};
	private String m_globalNames[] = {
		"configuration", "adapter", "style", "function", "step", "args", "to", "log", "message-mapping", "message", 
		"attribute-mapping", "class", "attribute"
	};
	private String m_globalUris[] = {
		null, null, null, null, null, null, null, null, null, null, 
		null, null, null
	};
	private String m_idNames[];

	private JiBX_flive_j2ee_framework_jdk_1Factory()
	{
		m_idNames = null;
	}

	public IMarshallingContext createMarshallingContext()
	{
		return new MarshallingContext(m_classes, m_marshallers, m_uris, this);
	}

	public IUnmarshallingContext createUnmarshallingContext()
	{
		return new UnmarshallingContext(18, m_unmarshallers, m_globalUris, m_globalNames, m_idNames, this);
	}

	public int getCompilerVersion()
	{
		return 0x10000;
	}

	public String getCompilerDistribution()
	{
		return "jibx_1_0_1";
	}

	public String[] getNamespaces()
	{
		return m_uris;
	}

	public String[] getPrefixes()
	{
		return m_prefixes;
	}

	public String[] getMappedClasses()
	{
		return m_classes;
	}

	public String[] getElementNamespaces()
	{
		return m_globalUris;
	}

	public String[] getElementNames()
	{
		return m_globalNames;
	}

	public int getTypeIndex(String arg1)
	{
		return -1;
	}

	public static IBindingFactory getInstance()
	{
		if (m_inst == null)
			m_inst = new JiBX_flive_j2ee_framework_jdk_1Factory();
		return m_inst;
	}
}
