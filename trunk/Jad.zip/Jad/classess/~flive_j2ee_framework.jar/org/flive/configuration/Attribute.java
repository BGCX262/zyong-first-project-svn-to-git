// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Attribute.java

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class Attribute
	implements IUnmarshallable, IMarshallable
{

	private String name;
	private String validator;
	private String description;
	private String facade;
	private String flag;
	private String type;
	private String extend;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public Attribute()
	{
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getFlag()
	{
		return flag;
	}

	public void setFlag(String flag)
	{
		this.flag = flag;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getExtend()
	{
		return extend;
	}

	public void setExtend(String extend)
	{
		this.extend = extend;
	}

	public String getFacade()
	{
		return facade;
	}

	public void setFacade(String facade)
	{
		this.facade = facade;
	}

	public String getValidator()
	{
		return validator;
	}

	public void setValidator(String validator)
	{
		this.validator = validator;
	}

	public static Attribute JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Attribute();
	}

	public final Attribute JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		name = arg1.attributeText(null, "name");
		flag = arg1.attributeText(null, "flag", "1,grid");
		facade = arg1.attributeText(null, "facade", "textfield");
		type = arg1.attributeText(null, "type", "string");
		extend = arg1.attributeText(null, "extend", "");
		validator = arg1.attributeText(null, "validator", "");
		arg1.popObject();
		return this;
	}

	public final Attribute JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		description = arg1.parseContentText();
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(12).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "name", name);
		if (flag == null) goto _L2; else goto _L1
_L1:
		0;
		"flag";
		flag;
		if (!Utility.isEqual(flag, "1,grid")) goto _L4; else goto _L3
_L3:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L2
_L4:
		attribute();
_L2:
		if (facade == null) goto _L6; else goto _L5
_L5:
		0;
		"facade";
		facade;
		if (!Utility.isEqual(facade, "textfield")) goto _L8; else goto _L7
_L7:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L6
_L8:
		attribute();
_L6:
		if (type == null) goto _L10; else goto _L9
_L9:
		0;
		"type";
		type;
		if (!Utility.isEqual(type, "string")) goto _L12; else goto _L11
_L11:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L10
_L12:
		attribute();
_L10:
		if (extend == null) goto _L14; else goto _L13
_L13:
		0;
		"extend";
		extend;
		if (!Utility.isEqual(extend, "")) goto _L16; else goto _L15
_L15:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L14
_L16:
		attribute();
_L14:
		if (validator == null) goto _L18; else goto _L17
_L17:
		0;
		"validator";
		validator;
		if (!Utility.isEqual(validator, "")) goto _L20; else goto _L19
_L19:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L18
_L20:
		attribute();
_L18:
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.writeContent(description);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(12, "org.flive.configuration.Attribute").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 12;
	}
}
