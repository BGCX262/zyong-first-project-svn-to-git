// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			MessageCodeMapping

public class JiBX_flive_j2ee_framework_jdk_1MessageCodeMapping_access
	implements IUnmarshaller, IMarshaller
{

	public JiBX_flive_j2ee_framework_jdk_1MessageCodeMapping_access()
	{
	}

	public final boolean isPresent(IUnmarshallingContext arg1)
		throws JiBXException
	{
		return arg1.isAt(null, "message-mapping");
	}

	public final Object unmarshal(Object arg1, IUnmarshallingContext arg2)
		throws JiBXException
	{
		MessageCodeMapping messagecodemapping;
		if (arg1 == null)
			arg1 = MessageCodeMapping.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0((UnmarshallingContext)arg2);
		messagecodemapping = (MessageCodeMapping)arg1;
		messagecodemapping;
		((UnmarshallingContext)arg2).parsePastStartTag(null, "message-mapping");
		((UnmarshallingContext)arg2).parsePastCurrentEndTag(null, "message-mapping");
		return messagecodemapping.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0((UnmarshallingContext)arg2);
	}

	public final void marshal(Object arg1, IMarshallingContext arg2)
		throws JiBXException
	{
		((MarshallingContext)arg2).startTag(0, "message-mapping");
		((MessageCodeMapping)arg1).JiBX_flive_j2ee_framework_jdk_1_marshal_1_0((MarshallingContext)arg2);
		((MarshallingContext)arg2).endTag(0, "message-mapping");
	}

	public final boolean isExtension(int arg1)
	{
		if (arg1 - 8 == 0);
		return true;
	}
}
