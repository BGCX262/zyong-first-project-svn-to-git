// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Style.java

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			StyleClassNotFoundException

public class Style
	implements IUnmarshallable, IMarshallable
{

	private String id;
	private String templet;
	private String contentType;
	private String encoding;
	private String className;
	private Class clazz;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public Style()
	{
	}

	public String getContentType()
	{
		return contentType;
	}

	public void setContentType(String contentType)
	{
		this.contentType = contentType;
	}

	public String getEncoding()
	{
		return encoding;
	}

	public void setEncoding(String encoding)
	{
		this.encoding = encoding;
	}

	public String getTemplet()
	{
		return templet;
	}

	public void setTemplet(String templete)
	{
		templet = templete;
	}

	public String getClassName()
	{
		return className;
	}

	public Class getStyleClass()
		throws StyleClassNotFoundException
	{
		try
		{
			clazz = Class.forName(className);
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
			throw new StyleClassNotFoundException(className);
		}
		return clazz;
	}

	public void setClassName(String className)
	{
		this.className = className;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public static Style JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Style();
	}

	public final Style JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		id = arg1.attributeText(null, "id");
		className = arg1.attributeText(null, "class");
		templet = arg1.attributeText(null, "templet", null);
		contentType = arg1.attributeText(null, "content-type", "text/xml");
		encoding = arg1.attributeText(null, "encoding", "GBK");
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(2).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "id", id).attribute(0, "class", className);
		if (templet == null) goto _L2; else goto _L1
_L1:
		0;
		"templet";
		templet;
		attribute();
_L2:
		if (contentType == null) goto _L4; else goto _L3
_L3:
		0;
		"content-type";
		contentType;
		if (!Utility.isEqual(contentType, "text/xml")) goto _L6; else goto _L5
_L5:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L4
_L6:
		attribute();
_L4:
		if (encoding == null) goto _L8; else goto _L7
_L7:
		0;
		"encoding";
		encoding;
		if (!Utility.isEqual(encoding, "GBK")) goto _L10; else goto _L9
_L9:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L8
_L10:
		attribute();
_L8:
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(2, "org.flive.configuration.Style").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 2;
	}
}
