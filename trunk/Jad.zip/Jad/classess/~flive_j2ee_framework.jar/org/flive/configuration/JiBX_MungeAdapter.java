// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   

package org.flive.configuration;

import java.util.ArrayList;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			Step, Arg, To, Log, 
//			Attribute

public abstract class JiBX_MungeAdapter
{

	public JiBX_MungeAdapter()
	{
	}

	public static ArrayList JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new ArrayList();
	}

	public static ArrayList JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(ArrayList arg1, UnmarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushTrackedObject(arg1);
		arg1;
_L1:
		if (!arg2.getUnmarshaller(4).isPresent(arg2))
			break MISSING_BLOCK_LABEL_50;
		(Step)arg2.getUnmarshaller(4).unmarshal(null, arg2);
		arg1;
		JVM INSTR swap ;
		add();
		JVM INSTR pop ;
		  goto _L1
		arg2.popObject();
		return arg1;
	}

	public static void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(ArrayList arg1, MarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushObject(arg1);
		arg2;
		int var0;
		int var1;
		var0 = -1;
		var1 = arg1.size();
_L5:
		if (++var0 - var1 >= 0) goto _L2; else goto _L1
_L1:
		Object obj = arg1.get(var0);
		obj;
		if (!(obj instanceof Step)) goto _L4; else goto _L3
_L3:
		(Step);
		arg2.getMarshaller(4, "org.flive.configuration.Step");
		JVM INSTR swap ;
		arg2;
		marshal();
		  goto _L5
_L4:
		new StringBuffer("Collection item of type ");
		JVM INSTR swap ;
		JVM INSTR dup ;
		JVM INSTR ifnull 80;
		   goto _L6 _L7
_L6:
		getClass();
		getName();
		  goto _L8
_L7:
		JVM INSTR pop ;
		"NULL";
_L8:
		append();
		" has no binding defined";
		append();
		toString();
		JVM INSTR new #23  <Class JiBXException>;
		JVM INSTR dup_x1 ;
		JVM INSTR swap ;
		JiBXException();
		throw ;
_L2:
		arg2.popObject();
		return;
	}

	public static ArrayList JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_1(ArrayList arg1, UnmarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushTrackedObject(arg1);
		arg1;
_L1:
		if (!arg2.getUnmarshaller(5).isPresent(arg2))
			break MISSING_BLOCK_LABEL_50;
		(Arg)arg2.getUnmarshaller(5).unmarshal(null, arg2);
		arg1;
		JVM INSTR swap ;
		add();
		JVM INSTR pop ;
		  goto _L1
		arg2.popObject();
		return arg1;
	}

	public static ArrayList JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_2(ArrayList arg1, UnmarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushTrackedObject(arg1);
		arg1;
_L1:
		if (!arg2.getUnmarshaller(6).isPresent(arg2))
			break MISSING_BLOCK_LABEL_52;
		(To)arg2.getUnmarshaller(6).unmarshal(null, arg2);
		arg1;
		JVM INSTR swap ;
		add();
		JVM INSTR pop ;
		  goto _L1
		arg2.popObject();
		return arg1;
	}

	public static ArrayList JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_3(ArrayList arg1, UnmarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushTrackedObject(arg1);
		arg1;
_L1:
		if (!arg2.getUnmarshaller(7).isPresent(arg2))
			break MISSING_BLOCK_LABEL_52;
		(Log)arg2.getUnmarshaller(7).unmarshal(null, arg2);
		arg1;
		JVM INSTR swap ;
		add();
		JVM INSTR pop ;
		  goto _L1
		arg2.popObject();
		return arg1;
	}

	public static void JiBX_flive_j2ee_framework_jdk_1_marshal_1_3(ArrayList arg1, MarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushObject(arg1);
		arg2;
		int var0;
		int var1;
		var0 = -1;
		var1 = arg1.size();
_L5:
		if (++var0 - var1 >= 0) goto _L2; else goto _L1
_L1:
		Object obj = arg1.get(var0);
		obj;
		if (!(obj instanceof Arg)) goto _L4; else goto _L3
_L3:
		(Arg);
		arg2.getMarshaller(5, "org.flive.configuration.Arg");
		JVM INSTR swap ;
		arg2;
		marshal();
		  goto _L5
_L4:
		new StringBuffer("Collection item of type ");
		JVM INSTR swap ;
		JVM INSTR dup ;
		JVM INSTR ifnull 80;
		   goto _L6 _L7
_L6:
		getClass();
		getName();
		  goto _L8
_L7:
		JVM INSTR pop ;
		"NULL";
_L8:
		append();
		" has no binding defined";
		append();
		toString();
		JVM INSTR new #23  <Class JiBXException>;
		JVM INSTR dup_x1 ;
		JVM INSTR swap ;
		JiBXException();
		throw ;
_L2:
		arg2.popObject();
		return;
	}

	public static void JiBX_flive_j2ee_framework_jdk_1_marshal_1_4(ArrayList arg1, MarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushObject(arg1);
		arg2;
		int var0;
		int var1;
		var0 = -1;
		var1 = arg1.size();
_L5:
		if (++var0 - var1 >= 0) goto _L2; else goto _L1
_L1:
		Object obj = arg1.get(var0);
		obj;
		if (!(obj instanceof To)) goto _L4; else goto _L3
_L3:
		(To);
		arg2.getMarshaller(6, "org.flive.configuration.To");
		JVM INSTR swap ;
		arg2;
		marshal();
		  goto _L5
_L4:
		new StringBuffer("Collection item of type ");
		JVM INSTR swap ;
		JVM INSTR dup ;
		JVM INSTR ifnull 81;
		   goto _L6 _L7
_L6:
		getClass();
		getName();
		  goto _L8
_L7:
		JVM INSTR pop ;
		"NULL";
_L8:
		append();
		" has no binding defined";
		append();
		toString();
		JVM INSTR new #23  <Class JiBXException>;
		JVM INSTR dup_x1 ;
		JVM INSTR swap ;
		JiBXException();
		throw ;
_L2:
		arg2.popObject();
		return;
	}

	public static void JiBX_flive_j2ee_framework_jdk_1_marshal_1_5(ArrayList arg1, MarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushObject(arg1);
		arg2;
		int var0;
		int var1;
		var0 = -1;
		var1 = arg1.size();
_L5:
		if (++var0 - var1 >= 0) goto _L2; else goto _L1
_L1:
		Object obj = arg1.get(var0);
		obj;
		if (!(obj instanceof Log)) goto _L4; else goto _L3
_L3:
		(Log);
		arg2.getMarshaller(7, "org.flive.configuration.Log");
		JVM INSTR swap ;
		arg2;
		marshal();
		  goto _L5
_L4:
		new StringBuffer("Collection item of type ");
		JVM INSTR swap ;
		JVM INSTR dup ;
		JVM INSTR ifnull 81;
		   goto _L6 _L7
_L6:
		getClass();
		getName();
		  goto _L8
_L7:
		JVM INSTR pop ;
		"NULL";
_L8:
		append();
		" has no binding defined";
		append();
		toString();
		JVM INSTR new #23  <Class JiBXException>;
		JVM INSTR dup_x1 ;
		JVM INSTR swap ;
		JiBXException();
		throw ;
_L2:
		arg2.popObject();
		return;
	}

	public static ArrayList JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_5(ArrayList arg1, UnmarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushTrackedObject(arg1);
		arg1;
_L1:
		if (!arg2.getUnmarshaller(12).isPresent(arg2))
			break MISSING_BLOCK_LABEL_52;
		(Attribute)arg2.getUnmarshaller(12).unmarshal(null, arg2);
		arg1;
		JVM INSTR swap ;
		add();
		JVM INSTR pop ;
		  goto _L1
		arg2.popObject();
		return arg1;
	}

	public static void JiBX_flive_j2ee_framework_jdk_1_marshal_1_6(ArrayList arg1, MarshallingContext arg2)
		throws JiBXException
	{
		arg2.pushObject(arg1);
		arg2;
		int var0;
		int var1;
		var0 = -1;
		var1 = arg1.size();
_L5:
		if (++var0 - var1 >= 0) goto _L2; else goto _L1
_L1:
		Object obj = arg1.get(var0);
		obj;
		if (!(obj instanceof Attribute)) goto _L4; else goto _L3
_L3:
		(Attribute);
		arg2.getMarshaller(12, "org.flive.configuration.Attribute");
		JVM INSTR swap ;
		arg2;
		marshal();
		  goto _L5
_L4:
		new StringBuffer("Collection item of type ");
		JVM INSTR swap ;
		JVM INSTR dup ;
		JVM INSTR ifnull 81;
		   goto _L6 _L7
_L6:
		getClass();
		getName();
		  goto _L8
_L7:
		JVM INSTR pop ;
		"NULL";
_L8:
		append();
		" has no binding defined";
		append();
		toString();
		JVM INSTR new #23  <Class JiBXException>;
		JVM INSTR dup_x1 ;
		JVM INSTR swap ;
		JiBXException();
		throw ;
_L2:
		arg2.popObject();
		return;
	}
}
