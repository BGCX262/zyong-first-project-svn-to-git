// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataAccessor.java

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class DataAccessor
	implements IUnmarshallable, IMarshallable
{

	private String id;
	private String clazz;
	private String url;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public DataAccessor()
	{
	}

	public String getUrl()
	{
		return url;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public String getClazz()
	{
		return clazz;
	}

	public void setClazz(String clazz)
	{
		this.clazz = clazz;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public static DataAccessor JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new DataAccessor();
	}

	public final DataAccessor JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		id = arg1.attributeText(null, "id");
		arg1.popObject();
		return this;
	}

	public final DataAccessor JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		clazz = arg1.parseElementText(null, "driver");
		url = arg1.parseElementText(null, "url", null);
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(1).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "id", id);
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.element(0, "driver", clazz);
		if (url == null) goto _L2; else goto _L1
_L1:
		0;
		"url";
		url;
		element();
_L2:
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(1, "org.flive.configuration.DataAccessor").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 1;
	}
}
