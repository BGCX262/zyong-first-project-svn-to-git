// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Step.java

package org.flive.configuration;

import java.util.ArrayList;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			Ref, JiBX_MungeAdapter, ReturnValue, Redirect, 
//			Monitor

public class Step
	implements IUnmarshallable, IMarshallable
{

	private int id;
	private String description;
	private String condition;
	private String express;
	private Ref ref;
	private ArrayList args;
	private ArrayList logs;
	private Monitor monitor;
	private String dataFilter;
	private ReturnValue returnValue;
	private Redirect redirect;
	private String dataFilters[];
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public Step()
	{
	}

	public ArrayList getArgs()
	{
		return args;
	}

	public String getCondition()
	{
		return condition;
	}

	public String getDataFilter()
	{
		return dataFilter;
	}

	public String getDescription()
	{
		return description;
	}

	public String getExpress()
	{
		return express;
	}

	public int getId()
	{
		return id;
	}

	public Monitor getMonitor()
	{
		return monitor;
	}

	public Redirect getRedirect()
	{
		return redirect;
	}

	public Ref getRef()
	{
		return ref;
	}

	public ReturnValue getReturnValue()
	{
		return returnValue;
	}

	public void setArgs(ArrayList list)
	{
		args = list;
	}

	public void setCondition(String string)
	{
		condition = string;
	}

	public void setDataFilter(String string)
	{
		dataFilter = string;
		if (dataFilter == null)
		{
			return;
		} else
		{
			dataFilters = dataFilter.split(",");
			return;
		}
	}

	public void setDescription(String string)
	{
		description = string;
	}

	public void setExpress(String string)
	{
		express = string;
	}

	public void setId(int i)
	{
		id = i;
	}

	public ArrayList getLogs()
	{
		return logs;
	}

	public void setLogs(ArrayList logs)
	{
		this.logs = logs;
	}

	public void setMonitor(Monitor monitor)
	{
		this.monitor = monitor;
	}

	public void setRedirect(Redirect redirect)
	{
		this.redirect = redirect;
	}

	public void setRef(Ref ref)
	{
		this.ref = ref;
	}

	public void setReturnValue(ReturnValue value)
	{
		returnValue = value;
	}

	public String[] getDataFilters()
	{
		return dataFilters;
	}

	public static Step JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Step();
	}

	public final Step JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		id = arg1.attributeInt(null, "id");
		description = arg1.attributeText(null, "description", null);
		arg1.popObject();
		return this;
	}

	public final Step JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		condition = arg1.parseElementText(null, "condition", null);
		arg1.parseToStartTag(null, "ref");
		ref = (ref != null ? ref : Ref.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1)).JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(arg1);
		arg1.parsePastStartTag(null, "ref");
		ref.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(arg1);
		arg1.parsePastCurrentEndTag(null, "ref");
		args = arg1.getUnmarshaller(5).isPresent(arg1) ? JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_1(args != null ? args : JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1), arg1) : null;
		setDataFilter(arg1.parseElementText(null, "data-filter", null));
		if (arg1.isAt(null, "return"))
		{
			arg1.parseToStartTag(null, "return");
			returnValue = (returnValue != null ? returnValue : ReturnValue.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1)).JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(arg1);
			arg1.parsePastStartTag(null, "return");
			arg1.parsePastCurrentEndTag(null, "return");
		}
		if (arg1.isAt(null, "redirect"))
		{
			arg1.parsePastStartTag(null, "redirect");
			redirect = (redirect != null ? redirect : Redirect.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1)).JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(arg1);
			arg1.parsePastCurrentEndTag(null, "redirect");
		}
		logs = arg1.getUnmarshaller(7).isPresent(arg1) ? JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_3(logs != null ? logs : JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1), arg1) : null;
		if (arg1.isAt(null, "monitor"))
		{
			arg1.parseToStartTag(null, "monitor");
			monitor = (monitor != null ? monitor : Monitor.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1)).JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(arg1);
			arg1.parsePastStartTag(null, "monitor");
			arg1.parsePastCurrentEndTag(null, "monitor");
		}
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(4).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "id", Utility.serializeInt(id));
		if (description == null) goto _L2; else goto _L1
_L1:
		0;
		"description";
		description;
		attribute();
_L2:
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		if (condition == null) goto _L2; else goto _L1
_L1:
		0;
		"condition";
		condition;
		element();
_L2:
		JVM INSTR dup ;
		arg1.startTagAttributes(0, "ref");
		ref.JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(arg1);
		arg1.closeStartContent();
		ref.JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(arg1);
		arg1.endTag(0, "ref");
		args;
		if (args != null) goto _L4; else goto _L3
_L3:
		JVM INSTR pop ;
		  goto _L5
_L4:
		arg1;
		JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_marshal_1_3();
_L5:
		if (dataFilter == null) goto _L7; else goto _L6
_L6:
		0;
		"data-filter";
		dataFilter;
		element();
_L7:
		if (returnValue != null)
		{
			arg1.startTagAttributes(0, "return");
			returnValue.JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(arg1);
			arg1.closeStartEmpty();
		}
		if (redirect != null)
		{
			arg1.startTag(0, "redirect");
			redirect.JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(arg1);
			arg1.endTag(0, "redirect");
		}
		logs;
		if (logs != null) goto _L9; else goto _L8
_L8:
		JVM INSTR pop ;
		  goto _L10
_L9:
		arg1;
		JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_marshal_1_5();
_L10:
		if (monitor != null)
		{
			arg1.startTagAttributes(0, "monitor");
			monitor.JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(arg1);
			arg1.closeStartEmpty();
		}
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(4, "org.flive.configuration.Step").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 4;
	}
}
