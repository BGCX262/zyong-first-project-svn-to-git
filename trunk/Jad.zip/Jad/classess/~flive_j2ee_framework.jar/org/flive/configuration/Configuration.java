// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Configuration.java

package org.flive.configuration;

import java.util.*;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			FunctionNotFoundException, Function, StyleNotFoundException, Style

public class Configuration
	implements IUnmarshallable, IMarshallable
{

	private String expression;
	private String profile;
	private String logConfig;
	private String monitorConfig;
	private HashMap functionContainer;
	private HashMap styleWrapperContainer;
	private HashMap dataAccessorContainer;
	private String amountSummary;
	private String cacheProvider;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public String getCacheProvider()
	{
		return cacheProvider;
	}

	public void setCacheProvider(String cacheProvider)
	{
		this.cacheProvider = cacheProvider;
	}

	public Configuration()
	{
	}

	public void init()
	{
	}

	public String getAmountSummary()
	{
		return amountSummary;
	}

	public void setAmountSummary(String amountSummary)
	{
		this.amountSummary = amountSummary;
	}

	public void setStyleWrapperContainer(HashMap styleWrapperContainer)
	{
		this.styleWrapperContainer = styleWrapperContainer;
	}

	public String getExpression()
	{
		return expression;
	}

	public Function getFunction(String func_id)
		throws FunctionNotFoundException
	{
		Object obj = functionContainer.get(func_id);
		if (obj == null)
			throw new FunctionNotFoundException(func_id);
		else
			return (Function)obj;
	}

	public Style getStyle(String style_id)
		throws StyleNotFoundException
	{
		Object style = styleWrapperContainer.get(style_id);
		if (style == null)
			throw new StyleNotFoundException(style_id);
		else
			return (Style)style;
	}

	public String getLogConfig()
	{
		return logConfig;
	}

	public String getMonitorConfig()
	{
		return monitorConfig;
	}

	public String getProfile()
	{
		return profile;
	}

	public void setExpression(String string)
	{
		expression = string;
	}

	public void setFunctionContainer(HashMap list)
	{
		functionContainer = list;
	}

	public void setLogConfig(String string)
	{
		logConfig = string;
	}

	public void setMonitorConfig(String string)
	{
		monitorConfig = string;
	}

	public void setProfile(String string)
	{
		profile = string;
	}

	public Map getDataAccessorContainer()
	{
		return dataAccessorContainer;
	}

	public void setDataAccessorContainer(HashMap dataAccessorContainer)
	{
		this.dataAccessorContainer = dataAccessorContainer;
	}

	public Iterator iterateFunctions()
	{
		return functionContainer.values().iterator();
	}

	public static Configuration JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Configuration();
	}

	public final Configuration JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		expression = arg1.parseElementText(null, "expression", null);
		profile = arg1.parseElementText(null, "profile", null);
		logConfig = arg1.parseElementText(null, "log-config", null);
		monitorConfig = arg1.parseElementText(null, "monitor-config", null);
		amountSummary = arg1.parseElementText(null, "amount-summary", "org.flive.control_logic.listener.SimpleStreamAmountSummary");
		cacheProvider = arg1.parseElementText(null, "cache-provider", "org.flive.util.cache.OSCacheImpl");
		dataAccessorContainer = (HashMap)arg1.getUnmarshaller(13).unmarshal(dataAccessorContainer, arg1);
		styleWrapperContainer = (HashMap)arg1.getUnmarshaller(14).unmarshal(styleWrapperContainer, arg1);
		functionContainer = (HashMap)arg1.getUnmarshaller(15).unmarshal(functionContainer, arg1);
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(0).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		if (expression == null) goto _L2; else goto _L1
_L1:
		0;
		"expression";
		expression;
		element();
_L2:
		if (profile == null) goto _L4; else goto _L3
_L3:
		0;
		"profile";
		profile;
		element();
_L4:
		if (logConfig == null) goto _L6; else goto _L5
_L5:
		0;
		"log-config";
		logConfig;
		element();
_L6:
		if (monitorConfig == null) goto _L8; else goto _L7
_L7:
		0;
		"monitor-config";
		monitorConfig;
		element();
_L8:
		if (amountSummary == null) goto _L10; else goto _L9
_L9:
		0;
		"amount-summary";
		amountSummary;
		if (!Utility.isEqual(amountSummary, "org.flive.control_logic.listener.SimpleStreamAmountSummary")) goto _L12; else goto _L11
_L11:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L10
_L12:
		element();
_L10:
		if (cacheProvider == null) goto _L14; else goto _L13
_L13:
		0;
		"cache-provider";
		cacheProvider;
		if (!Utility.isEqual(cacheProvider, "org.flive.util.cache.OSCacheImpl")) goto _L16; else goto _L15
_L15:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L14
_L16:
		element();
_L14:
		dataAccessorContainer;
		arg1.getMarshaller(13, "java.util.HashMap");
		JVM INSTR swap ;
		arg1;
		marshal();
		arg1.getMarshaller(14, "java.util.HashMap").marshal(styleWrapperContainer, arg1);
		arg1.getMarshaller(15, "java.util.HashMap").marshal(functionContainer, arg1);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(0, "org.flive.configuration.Configuration").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 0;
	}
}
