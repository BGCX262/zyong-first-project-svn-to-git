// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ClassItem.java

package org.flive.configuration;

import java.util.ArrayList;
import java.util.List;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			JiBX_MungeAdapter

public class ClassItem
	implements IUnmarshallable, IMarshallable
{

	private String id;
	private String linkedClassName;
	private String description;
	private String identity;
	private ArrayList attributes;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public ClassItem()
	{
	}

	public void init()
	{
	}

	public List getAttributes()
	{
		return attributes;
	}

	public String getDescription()
	{
		return description;
	}

	public String getId()
	{
		return id;
	}

	public void setAttributes(ArrayList list)
	{
		attributes = list;
	}

	public void setDescription(String string)
	{
		description = string;
	}

	public void setId(String string)
	{
		id = string;
	}

	public String getLinkedClassName()
	{
		return linkedClassName;
	}

	public void setLinkedClassName(String string)
	{
		linkedClassName = string;
	}

	public String getIdentity()
	{
		return identity;
	}

	public void setIdentity(String identity)
	{
		this.identity = identity;
	}

	public static ClassItem JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new ClassItem();
	}

	public final ClassItem JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		id = arg1.attributeText(null, "id");
		linkedClassName = arg1.attributeText(null, "link-to", null);
		description = arg1.attributeText(null, "description", "");
		identity = arg1.attributeText(null, "identity", "id");
		arg1.popObject();
		return this;
	}

	public final ClassItem JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		attributes = arg1.getUnmarshaller(12).isPresent(arg1) ? JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_5(attributes != null ? attributes : JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1), arg1) : null;
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(11).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "id", id);
		if (linkedClassName == null) goto _L2; else goto _L1
_L1:
		0;
		"link-to";
		linkedClassName;
		attribute();
_L2:
		if (description == null) goto _L4; else goto _L3
_L3:
		0;
		"description";
		description;
		if (!Utility.isEqual(description, "")) goto _L6; else goto _L5
_L5:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L4
_L6:
		attribute();
_L4:
		if (identity == null) goto _L8; else goto _L7
_L7:
		0;
		"identity";
		identity;
		if (!Utility.isEqual(identity, "id")) goto _L10; else goto _L9
_L9:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L8
_L10:
		attribute();
_L8:
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		attributes;
		if (attributes != null) goto _L2; else goto _L1
_L1:
		JVM INSTR pop ;
		  goto _L3
_L2:
		arg1;
		JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_marshal_1_6();
_L3:
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(11, "org.flive.configuration.ClassItem").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 11;
	}
}
