// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ReturnValue.java

package org.flive.configuration;

import org.jibx.runtime.JiBXException;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class ReturnValue
{

	private String name;
	private String scope;

	public ReturnValue()
	{
	}

	public String getName()
	{
		return name;
	}

	public String getScope()
	{
		return scope;
	}

	public void setName(String string)
	{
		name = string;
	}

	public void setScope(String string)
	{
		scope = string;
	}

	public static ReturnValue JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new ReturnValue();
	}

	public final ReturnValue JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		name = arg1.attributeText(null, "name");
		scope = arg1.attributeText(null, "scope");
		arg1.popObject();
		return this;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "name", name).attribute(0, "scope", scope);
		arg1.popObject();
		return;
	}
}
