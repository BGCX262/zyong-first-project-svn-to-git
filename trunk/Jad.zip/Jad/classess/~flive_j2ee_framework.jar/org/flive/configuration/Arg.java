// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Arg.java

package org.flive.configuration;

import org.flive.util.RunningReflection;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class Arg
	implements IUnmarshallable, IMarshallable
{

	private String name;
	private String type;
	private String value;
	private String itemType;
	private Class realType;
	private Class realItemType;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public Arg()
	{
	}

	public String getName()
	{
		return name;
	}

	public String getType()
	{
		return type;
	}

	public Class getRealType()
	{
		return realType;
	}

	public Class getRealItemType()
	{
		return realItemType;
	}

	public String getValue()
	{
		return value;
	}

	public void setName(String string)
	{
		name = string;
	}

	public void setType(String string)
	{
		type = string;
		realType = RunningReflection.String2Class(string);
	}

	public void setValue(String string)
	{
		value = string;
	}

	public String getItemType()
	{
		return itemType;
	}

	public void setItemType(String string)
	{
		itemType = string;
		realItemType = RunningReflection.String2Class(string);
	}

	public static Arg JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Arg();
	}

	public final Arg JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		name = arg1.attributeText(null, "name", "");
		setType(arg1.attributeText(null, "type"));
		setItemType(arg1.attributeText(null, "item-type", null));
		arg1.popObject();
		return this;
	}

	public final Arg JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		value = arg1.parseContentText();
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(5).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		if (name == null) goto _L2; else goto _L1
_L1:
		0;
		"name";
		name;
		if (!Utility.isEqual(name, "")) goto _L4; else goto _L3
_L3:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L2
_L4:
		attribute();
_L2:
		0;
		"type";
		type;
		attribute();
		if (itemType == null) goto _L6; else goto _L5
_L5:
		0;
		"item-type";
		itemType;
		attribute();
_L6:
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.writeContent(value);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(5, "org.flive.configuration.Arg").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 5;
	}
}
