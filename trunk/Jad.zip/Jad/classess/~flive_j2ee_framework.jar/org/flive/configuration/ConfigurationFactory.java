// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ConfigurationFactory.java

package org.flive.configuration;

import java.io.FileInputStream;
import org.jibx.runtime.*;

// Referenced classes of package org.flive.configuration:
//			CanNotFoundConfigurationException, Configuration

public class ConfigurationFactory
{

	private static ConfigurationFactory cf = null;
	private static Configuration config;

	public ConfigurationFactory()
	{
	}

	public static ConfigurationFactory getInstance()
	{
		if (cf == null)
		{
			cf = new ConfigurationFactory();
			return cf;
		} else
		{
			return cf;
		}
	}

	public Configuration get()
		throws CanNotFoundConfigurationException
	{
		if (config == null)
			throw new CanNotFoundConfigurationException();
		else
			return config;
	}

	public void load(String cfg_file)
	{
		try
		{
			IBindingFactory bfact = BindingDirectory.getFactory(org.flive.configuration.Configuration.class);
			IUnmarshallingContext uctx = bfact.createUnmarshallingContext();
			config = (Configuration)uctx.unmarshalDocument(new FileInputStream(cfg_file), "GBK");
			config.init();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
