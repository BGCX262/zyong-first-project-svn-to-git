// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   To.java

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class To
	implements IUnmarshallable, IMarshallable
{

	private int target;
	private String condition;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public To()
	{
	}

	public String getCondition()
	{
		return condition;
	}

	public int getTarget()
	{
		return target;
	}

	public void setCondition(String string)
	{
		condition = string;
	}

	public void setTarget(int i)
	{
		target = i;
	}

	public static To JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new To();
	}

	public final To JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		target = arg1.attributeInt(null, "target");
		arg1.popObject();
		return this;
	}

	public final To JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		condition = arg1.parseElementText(null, "condition");
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(6).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.attribute(0, "target", Utility.serializeInt(target));
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.element(0, "condition", condition);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(6, "org.flive.configuration.To").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 6;
	}
}
