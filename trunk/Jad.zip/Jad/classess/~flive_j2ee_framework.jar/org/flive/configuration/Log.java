// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Log.java

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class Log
	implements IUnmarshallable, IMarshallable
{

	public String level;
	public String content;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public Log()
	{
	}

	public String getContent()
	{
		return content;
	}

	public String getLevel()
	{
		return level;
	}

	public void setContent(String string)
	{
		content = string;
	}

	public void setLevel(String i)
	{
		level = i;
	}

	public static Log JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Log();
	}

	public final Log JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		level = arg1.attributeText(null, "level", "DEBUG");
		arg1.popObject();
		return this;
	}

	public final Log JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		content = arg1.parseContentText();
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(7).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		if (level == null) goto _L2; else goto _L1
_L1:
		0;
		"level";
		level;
		if (!Utility.isEqual(level, "DEBUG")) goto _L4; else goto _L3
_L3:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L2
_L4:
		attribute();
_L2:
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.writeContent(content);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(7, "org.flive.configuration.Log").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 7;
	}
}
