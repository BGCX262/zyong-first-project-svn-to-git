// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ClassAttributeMapping.java

package org.flive.configuration;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			CanNotBindingAttributeMappingException, ClassItem

public class ClassAttributeMapping
	implements IUnmarshallable, IMarshallable
{

	private HashMap classes;
	private static ClassAttributeMapping clsAttrMapping = null;
	public static final String JiBX_bindingList = "|org.flive.configuration.JiBX_flive_j2ee_framework_jdk_1Factory|";

	public ClassAttributeMapping()
	{
	}

	public void init()
	{
	}

	public static ClassAttributeMapping getMapping(String file)
		throws CanNotBindingAttributeMappingException
	{
		if (clsAttrMapping != null)
			return clsAttrMapping;
		try
		{
			IBindingFactory bfact = BindingDirectory.getFactory(org.flive.configuration.ClassAttributeMapping.class);
			IUnmarshallingContext uctx = bfact.createUnmarshallingContext();
			clsAttrMapping = (ClassAttributeMapping)uctx.unmarshalDocument(new FileInputStream(file), "GBK");
			clsAttrMapping.init();
			return clsAttrMapping;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		throw new CanNotBindingAttributeMappingException(file);
	}

	public ClassItem getClassByName(String class_name)
	{
		return (ClassItem)classes.get(class_name);
	}

	public Map getClasses()
	{
		return classes;
	}

	public static ClassAttributeMapping JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new ClassAttributeMapping();
	}

	public final ClassAttributeMapping JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		classes = (HashMap)arg1.getUnmarshaller(17).unmarshal(classes, arg1);
		arg1.popObject();
		return this;
	}

	public void unmarshal(IUnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.getUnmarshaller(10).unmarshal(this, arg1);
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		arg1.getMarshaller(17, "java.util.HashMap").marshal(classes, arg1);
		arg1.popObject();
		return;
	}

	public void marshal(IMarshallingContext arg1)
		throws JiBXException
	{
		arg1.getMarshaller(10, "org.flive.configuration.ClassAttributeMapping").marshal(this, arg1);
	}

	public int JiBX_getIndex()
	{
		return 10;
	}

}
