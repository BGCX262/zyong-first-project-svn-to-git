// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Ref.java

package org.flive.configuration;

import org.jibx.runtime.JiBXException;
import org.jibx.runtime.Utility;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

public class Ref
{

	public static String JAVA_TYPE = "java";
	public static String SCRIPT_TYPE = "script";
	private String type;
	private String content;
	private String scope;
	private String name;

	public Ref()
	{
	}

	public String getContent()
	{
		return content;
	}

	public String getType()
	{
		return type;
	}

	public String getScope()
	{
		return scope;
	}

	public String getName()
	{
		return name;
	}

	public void setContent(String string)
	{
		content = string;
	}

	public void setType(String string)
	{
		type = string;
	}

	public void setScope(String string)
	{
		scope = string;
	}

	public void setName(String string)
	{
		name = string;
	}

	public static Ref JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Ref();
	}

	public final Ref JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		name = arg1.attributeText(null, "name", null);
		type = arg1.attributeText(null, "type", "java");
		scope = arg1.attributeText(null, "scope", null);
		arg1.popObject();
		return this;
	}

	public final Ref JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		this;
		content = arg1.parseContentText();
		arg1.popObject();
		return this;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		if (name == null) goto _L2; else goto _L1
_L1:
		0;
		"name";
		name;
		attribute();
_L2:
		if (type == null) goto _L4; else goto _L3
_L3:
		0;
		"type";
		type;
		if (!Utility.isEqual(type, "java")) goto _L6; else goto _L5
_L5:
		JVM INSTR pop ;
		JVM INSTR pop ;
		JVM INSTR pop ;
		  goto _L4
_L6:
		attribute();
_L4:
		if (scope == null) goto _L8; else goto _L7
_L7:
		0;
		"scope";
		scope;
		attribute();
_L8:
		arg1.popObject();
		return;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1.writeContent(content);
		arg1.popObject();
		return;
	}

}
