// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			Step

public class JiBX_flive_j2ee_framework_jdk_1Step_access
	implements IUnmarshaller, IMarshaller
{

	public JiBX_flive_j2ee_framework_jdk_1Step_access()
	{
	}

	public final boolean isPresent(IUnmarshallingContext arg1)
		throws JiBXException
	{
		return arg1.isAt(null, "step");
	}

	public final Object unmarshal(Object arg1, IUnmarshallingContext arg2)
		throws JiBXException
	{
		Step step;
		if (arg1 == null)
			arg1 = Step.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0((UnmarshallingContext)arg2);
		step = (Step)arg1;
		step;
		((UnmarshallingContext)arg2).parseToStartTag(null, "step");
		((UnmarshallingContext)arg2).parsePastStartTag(null, "step");
		((UnmarshallingContext)arg2).parsePastCurrentEndTag(null, "step");
		return step.JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0((UnmarshallingContext)arg2).JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0((UnmarshallingContext)arg2);
	}

	public final void marshal(Object arg1, IMarshallingContext arg2)
		throws JiBXException
	{
		Step step = (Step)arg1;
		((MarshallingContext)arg2).startTagAttributes(0, "step");
		step.JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0((MarshallingContext)arg2);
		((MarshallingContext)arg2).closeStartContent();
		step.JiBX_flive_j2ee_framework_jdk_1_marshal_1_0((MarshallingContext)arg2);
		((MarshallingContext)arg2).endTag(0, "step");
	}

	public final boolean isExtension(int arg1)
	{
		if (arg1 - 4 == 0);
		return true;
	}
}
