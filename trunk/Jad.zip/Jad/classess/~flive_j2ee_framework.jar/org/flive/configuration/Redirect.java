// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Redirect.java

package org.flive.configuration;

import java.util.ArrayList;
import org.jibx.runtime.JiBXException;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			JiBX_MungeAdapter

public class Redirect
{

	ArrayList tos;

	public Redirect()
	{
	}

	public ArrayList getTos()
	{
		return tos;
	}

	public void setTos(ArrayList list)
	{
		tos = list;
	}

	public static Redirect JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		return new Redirect();
	}

	public final Redirect JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0(UnmarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushTrackedObject(this);
		this;
		tos = JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_2(tos != null ? tos : JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0(arg1), arg1);
		arg1.popObject();
		return this;
	}

	public final void JiBX_flive_j2ee_framework_jdk_1_marshal_1_0(MarshallingContext arg1)
		throws JiBXException
	{
		arg1.pushObject(this);
		arg1;
		JiBX_MungeAdapter.JiBX_flive_j2ee_framework_jdk_1_marshal_1_4(tos, arg1);
		arg1.popObject();
		return;
	}
}
