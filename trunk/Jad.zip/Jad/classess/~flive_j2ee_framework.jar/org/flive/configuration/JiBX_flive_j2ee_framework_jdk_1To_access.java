// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   

package org.flive.configuration;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.MarshallingContext;
import org.jibx.runtime.impl.UnmarshallingContext;

// Referenced classes of package org.flive.configuration:
//			To

public class JiBX_flive_j2ee_framework_jdk_1To_access
	implements IUnmarshaller, IMarshaller
{

	public JiBX_flive_j2ee_framework_jdk_1To_access()
	{
	}

	public final boolean isPresent(IUnmarshallingContext arg1)
		throws JiBXException
	{
		return arg1.isAt(null, "to");
	}

	public final Object unmarshal(Object arg1, IUnmarshallingContext arg2)
		throws JiBXException
	{
		To to;
		if (arg1 == null)
			arg1 = To.JiBX_flive_j2ee_framework_jdk_1_newinstance_1_0((UnmarshallingContext)arg2);
		to = (To)arg1;
		to;
		((UnmarshallingContext)arg2).parseToStartTag(null, "to");
		((UnmarshallingContext)arg2).parsePastStartTag(null, "to");
		((UnmarshallingContext)arg2).parsePastCurrentEndTag(null, "to");
		return to.JiBX_flive_j2ee_framework_jdk_1_unmarshalAttr_1_0((UnmarshallingContext)arg2).JiBX_flive_j2ee_framework_jdk_1_unmarshal_1_0((UnmarshallingContext)arg2);
	}

	public final void marshal(Object arg1, IMarshallingContext arg2)
		throws JiBXException
	{
		To to = (To)arg1;
		((MarshallingContext)arg2).startTagAttributes(0, "to");
		to.JiBX_flive_j2ee_framework_jdk_1_marshalAttr_1_0((MarshallingContext)arg2);
		((MarshallingContext)arg2).closeStartContent();
		to.JiBX_flive_j2ee_framework_jdk_1_marshal_1_0((MarshallingContext)arg2);
		((MarshallingContext)arg2).endTag(0, "to");
	}

	public final boolean isExtension(int arg1)
	{
		if (arg1 - 6 == 0);
		return true;
	}
}
