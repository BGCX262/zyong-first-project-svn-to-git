// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   File_AES.java

package com.szkingdom;

import java.io.*;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;

// Referenced classes of package com.szkingdom:
//			XMLUtil, LogUtils, CheckUTF8

public class File_AES
{

	private static Logger logger;
	private static Document luceneConfig;
	private static String wjmfile = null;
	private static String jmfile = null;
	private static String fileencoding = null;
	private static String key = null;
	private static FileOutputStream fos = null;
	private static BufferedWriter br = null;

	public File_AES()
	{
	}

	public static void main(String args[])
	{
		Date start = new Date();
		try
		{
			luceneConfig = XMLUtil.loadFile("FileConfig.xml");
			List nodelist = null;
			Iterator it = null;
			nodelist = luceneConfig.selectNodes("//root/wjmfile");
			for (it = nodelist.iterator(); it.hasNext();)
			{
				Element pathelement = (Element)it.next();
				wjmfile = pathelement.getText();
			}

			nodelist = luceneConfig.selectNodes("//root/jmfile");
			for (it = nodelist.iterator(); it.hasNext();)
			{
				Element driverclasselement = (Element)it.next();
				jmfile = driverclasselement.getText();
			}

			nodelist = luceneConfig.selectNodes("//root/fileencoding");
			for (it = nodelist.iterator(); it.hasNext();)
			{
				Element urlelement = (Element)it.next();
				fileencoding = urlelement.getText();
			}

			nodelist = luceneConfig.selectNodes("//root/key");
			for (it = nodelist.iterator(); it.hasNext();)
			{
				Element urlelement = (Element)it.next();
				key = urlelement.getText();
			}

			logger.debug("----------------------------------�ļ�·��=" + wjmfile + "-------------------------------");
			logger.debug("������������:");
			logger.debug("wjmfile=" + wjmfile);
			logger.debug("jmfile=" + jmfile);
			logger.debug("fileencoding=" + fileencoding);
			logger.debug("key=" + key);
			File file = new File(wjmfile);
			if (file.isDirectory())
			{
				CreateFile(jmfile);
				JMFile(file);
				br.close();
				fos.close();
			} else
			{
				logger.debug("��Ҫ�ļ����ļ���Ŀ¼�����ڣ���˶������ļ���");
			}
		}
		catch (IOException e)
		{
			logger.debug("��ȡ�����ļ�����");
		}
		finally
		{
			Date end = new Date();
			logger.debug("start at " + start.getTime());
			logger.debug("end   at " + end.getTime());
			logger.debug((end.getTime() - start.getTime()) + " total milliseconds");
		}
		return;
	}

	static void JMFile(File file)
	{
		if (file.isDirectory())
		{
			File fileList[] = file.listFiles();
			for (int i = 0; i < fileList.length; i++)
			{
				String filePath = fileList[i].getPath();
				JMFile(new File(filePath));
			}

		}
		if (file.isFile())
		{
			logger.debug("��ǰ�ļ���:" + file.getName());
			if (decisionUTF8(file))
			{
				encrypt(file, key);
				try
				{
					if (fos == null)
					{
						fos = new FileOutputStream(new File("report.txt"));
						br = new BufferedWriter(new OutputStreamWriter(fos));
					}
					br.write(file.getName() + "����ѹ���ɹ�!" + "\n");
				}
				catch (IOException e)
				{
					LogUtils.debugStackTrace(e.getStackTrace());
				}
			} else
			{
				try
				{
					if (fos == null)
					{
						fos = new FileOutputStream(new File("report.txt"));
						br = new BufferedWriter(new OutputStreamWriter(fos));
					}
					br.write(file.getName() + "�ļ����벻��" + fileencoding + ",����ʧ��!" + "\n");
				}
				catch (IOException e)
				{
					LogUtils.debugStackTrace(e.getStackTrace());
				}
			}
		}
	}

	static boolean decisionUTF8(File file)
	{
label0:
		{
			String flag;
			FileInputStream fis;
			byte bts[];
			int count;
			byte bts1[];
			int j;
			try
			{
				FileInputStream ios = new FileInputStream(file);
				byte b[] = new byte[3];
				ios.read(b);
				ios.close();
				if (b[0] != -17 || b[1] != -69 || b[2] != -65)
					break label0;
				System.out.println(file.getName() + "����ΪUTF-8");
			}
			catch (IOException e)
			{
				LogUtils.debugStackTrace(e.getStackTrace());
				logger.debug("�ڼ���" + file.getName() + "�ļ�ʱ,�����ʽ����" + fileencoding + "!");
				return false;
			}
			return true;
		}
		flag = CheckUTF8.isUTF8(file);
		if ("1".equals(flag))
			return true;
		fis = new FileInputStream(file);
		bts = new byte[1000];
		count = 0;
		if ((count = fis.read(bts, 0, 1000)) <= 0)
			break MISSING_BLOCK_LABEL_187;
		if (count < 1000)
		{
			bts1 = new byte[count];
			for (j = 0; j < count; j++)
				bts1[j] = bts[j];

			bts = bts1;
		}
		fis.close();
		return isUTF8(bts);
		return false;
	}

	public static boolean isUTF8(byte rawtext[])
	{
		int score = 0;
		int rawtextlen = 0;
		int goodbytes = 0;
		int asciibytes = 0;
		rawtextlen = rawtext.length;
		for (int i = 0; i < rawtextlen; i++)
			if ((rawtext[i] & 0x7f) == rawtext[i])
				asciibytes++;
			else
			if (-32 <= rawtext[i] && rawtext[i] <= -17 && i + 2 < rawtextlen && -128 <= rawtext[i + 1] && rawtext[i + 1] <= -65 && -128 <= rawtext[i + 2] && rawtext[i + 2] <= -65)
			{
				goodbytes += 3;
				i += 2;
			}

		if (asciibytes == rawtextlen)
			return false;
		score = (100 * goodbytes) / (rawtextlen - asciibytes);
		if (score > 98)
			return true;
		return score > 95 && goodbytes > 30;
	}

	public static void encrypt(File content, String keyWord)
	{
		try
		{
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
			secureRandom.setSeed(keyWord.getBytes());
			kgen.init(128, secureRandom);
			SecretKey secretKey = kgen.generateKey();
			byte enCodeFormat[] = secretKey.getEncoded();
			SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(1, key);
			FileInputStream fis = new FileInputStream(content);
			File jm = new File(jmfile + content.getName().split("\\.")[0] + "_A." + content.getName().split("\\.")[1]);
			FileOutputStream fos = new FileOutputStream(jm);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			byte byteContent[] = new byte[4096];
			int count = 0;
			String s = "";
			while ((count = fis.read(byteContent, 0, 4096)) > 0) 
			{
				if (count < 4096)
				{
					byte content1[] = new byte[count];
					for (int j = 0; j < count; j++)
						content1[j] = byteContent[j];

					byte result[] = cipher.doFinal(content1);
					s = parseByte2HexStr(result);
				} else
				{
					byte result[] = cipher.doFinal(byteContent);
					s = parseByte2HexStr(result);
				}
				bw.write(s + "\n");
			}
			bw.close();
			fos.close();
			fis.close();
			String directory_path = jm.getPath();
			String parent_path = jm.getParentFile().getPath();
			String filenamenotxt = jm.getName().substring(0, jm.getName().length() - 6);
			String line = "";
			String cmdstring[] = {
				"cmd", "/c", "7z_file.bat", directory_path, parent_path, filenamenotxt, "A"
			};
			Process p = Runtime.getRuntime().exec(cmdstring);
			BufferedReader bri = new BufferedReader(new InputStreamReader(p.getInputStream()));
			BufferedReader bre = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			while ((line = bri.readLine()) != null) 
				System.out.println(line);
			bri.close();
			while ((line = bre.readLine()) != null) 
				System.out.println(line);
			bre.close();
			try
			{
				p.waitFor();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
			System.out.println("Done." + p.exitValue());
		}
		catch (FileNotFoundException e)
		{
			logger.debug("�ڱ����ļ�ʱ," + content.getName() + "û���ҵ�!");
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (UnsupportedEncodingException e)
		{
			logger.debug("�ڱ����ļ�ʱ,���ö�ȡ" + content.getName() + "�ļ������ʽΪ" + fileencoding + "�쳣!");
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (IOException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
			logger.debug("�ڱ����ļ�ʱ,��ȡ" + content.getName() + "�ļ�����!");
		}
		catch (NoSuchAlgorithmException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (NoSuchPaddingException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (InvalidKeyException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (IllegalBlockSizeException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (BadPaddingException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (NullPointerException e)
		{
			e.printStackTrace();
			LogUtils.debugStackTrace(e.getStackTrace());
		}
	}

	public static String parseByte2HexStr(byte buf[])
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++)
		{
			String hex = Integer.toHexString(buf[i] & 0xff);
			if (hex.length() == 1)
				hex = '0' + hex;
			sb.append(hex.toUpperCase());
		}

		return sb.toString();
	}

	public static byte[] parseHexStr2Byte(String hexStr)
	{
		if (hexStr.length() < 1)
			return null;
		byte result[] = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++)
		{
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
			result[i] = (byte)(high * 16 + low);
		}

		return result;
	}

	static void CreateFile(String path)
	{
		String s = path;
		String m = "";
		for (int j = path.indexOf("/"); j > 0; j = s.indexOf('/'))
		{
			m = path.substring(0, j + 1);
			File file = new File(m);
			if (file.isDirectory())
			{
				System.out.println("the   dir   is   exits");
			} else
			{
				file.mkdir();
				System.out.println("have   made   a   dir   ��");
			}
			s = s.replaceFirst("/", ".");
		}

	}

	static 
	{
		logger = Logger.getLogger(com.szkingdom.File_AES.class);
	}
}
