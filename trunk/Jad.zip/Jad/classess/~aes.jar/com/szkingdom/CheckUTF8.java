// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CheckUTF8.java

package com.szkingdom;

import java.io.*;
import org.apache.log4j.Logger;
import org.mozilla.intl.chardet.*;

public class CheckUTF8
{

	private static Logger logger;
	public static String flag = "-1";

	public CheckUTF8()
	{
	}

	public static boolean isUTF8(byte rawtext[])
	{
		int score = 0;
		int rawtextlen = 0;
		int goodbytes = 0;
		int asciibytes = 0;
		rawtextlen = rawtext.length;
		for (int i = 0; i < rawtextlen; i++)
			if ((rawtext[i] & 0x7f) == rawtext[i])
				asciibytes++;
			else
			if (-64 <= rawtext[i] && rawtext[i] <= -33 && i + 1 < rawtextlen && -128 <= rawtext[i + 1] && rawtext[i + 1] <= -65)
			{
				goodbytes += 2;
				i++;
			} else
			if (-32 <= rawtext[i] && rawtext[i] <= -17 && i + 2 < rawtextlen && -128 <= rawtext[i + 1] && rawtext[i + 1] <= -65 && -128 <= rawtext[i + 2] && rawtext[i + 2] <= -65)
			{
				goodbytes += 3;
				i += 2;
			}

		if (asciibytes == rawtextlen)
			return false;
		score = (100 * goodbytes) / (rawtextlen - asciibytes);
		if (score > 98)
			return true;
		return score > 95 && goodbytes > 30;
	}

	public static String isUTF8(File file)
	{
		flag = "-1";
		nsICharsetDetectionObserver cdo = new nsICharsetDetectionObserver() {

			public void Notify(String charset)
			{
				HtmlCharsetDetector.found = true;
				CheckUTF8.logger.debug("CHARSET = " + charset);
				CheckUTF8.flag = charset;
			}

		};
		boolean found = false;
		nsDetector det = new nsDetector(6);
		det.Init(cdo);
		BufferedInputStream imp = null;
		boolean done = false;
		boolean isAscii = true;
		try
		{
			imp = new BufferedInputStream(new FileInputStream(file));
			byte buf[] = new byte[1024];
			for (int len = 0; (len = imp.read(buf, 0, buf.length)) != -1;)
			{
				if (isAscii)
					isAscii = det.isAscii(buf, len);
				if (!isAscii && !done)
					done = det.DoIt(buf, len, false);
			}

		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		det.DataEnd();
		logger.debug("��ǰ�ı�־λΪ��" + flag);
		if (!"-1".equals(flag))
			return flag;
		if (isAscii)
		{
			System.out.println("CHARSET = ASCII");
			return "1";
		}
		if (!found)
		{
			String prob[] = det.getProbableCharsets();
			for (int i = 0; i < prob.length; i++)
				logger.debug("Probable Charset = " + prob[i]);

			return "0";
		} else
		{
			return "0";
		}
	}

	static 
	{
		logger = Logger.getLogger(com.szkingdom.CheckUTF8.class);
	}

}
