// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LogUtils.java

package com.szkingdom;

import org.apache.log4j.Logger;

// Referenced classes of package com.szkingdom:
//			GlobalDBErrorMapping

public class LogUtils
{

	private static Logger utilLogger;

	public LogUtils()
	{
	}

	private static Logger getParentLogger()
	{
		StackTraceElement stes[];
		int i;
		try
		{
			throw new Exception();
		}
		catch (Exception e)
		{
			stes = e.getStackTrace();
			i = 0;
		}
		  goto _L1
_L3:
		if (!Class.forName(stes[i].getClassName()).equals(com.szkingdom.LogUtils.class))
			return Logger.getLogger(Class.forName(stes[i].getClassName()));
		continue; /* Loop/switch isn't completed */
		ClassNotFoundException classnotfoundexception;
		classnotfoundexception;
		i++;
_L1:
		if (i < stes.length) goto _L3; else goto _L2
_L2:
		return utilLogger;
	}

	public static void info(Object message)
	{
		getParentLogger().info(message);
	}

	public static void info(Class cla, Object message)
	{
		Logger logger = Logger.getLogger(cla);
		logger.info(message);
	}

	public static void warn(Object message)
	{
		getParentLogger().warn(message);
	}

	public static void warn(Class cla, Object message)
	{
		Logger logger = Logger.getLogger(cla);
		logger.warn(message);
	}

	public static void debug(Object message)
	{
		getParentLogger().debug(message);
	}

	public static void debug(int message)
	{
		getParentLogger().debug(Integer.toString(message));
	}

	public static void debug(Class cla, Object message)
	{
		Logger logger = Logger.getLogger(cla);
		logger.debug(message);
	}

	public static void error(Object message)
	{
		getParentLogger().error(message);
	}

	public static void error(Class cla, Object message)
	{
		Logger logger = Logger.getLogger(cla);
		logger.error(message);
	}

	public static void fatal(Object message)
	{
		getParentLogger().fatal(message);
	}

	public static void fatal(Class cla, Object message)
	{
		Logger logger = Logger.getLogger(cla);
		logger.fatal(message);
	}

	public static void debugStackTrace(Logger logger, StackTraceElement stackTraces[])
	{
		for (int i = 0; i < stackTraces.length; i++)
			logger.error(stackTraces[i].toString());

	}

	public static void debugStackTrace(StackTraceElement stackTraces[])
	{
		for (int i = 0; i < stackTraces.length; i++)
			utilLogger.error(stackTraces[i].toString());

	}

	public static void debugSqlErrorCodeMeaning(int errorCode)
	{
		error(GlobalDBErrorMapping.S_DBERRORMAPPINGINSTANCE.getErrorMeaningByErrorCode(errorCode));
	}

	static 
	{
		utilLogger = Logger.getLogger(com.szkingdom.LogUtils.class);
	}
}
