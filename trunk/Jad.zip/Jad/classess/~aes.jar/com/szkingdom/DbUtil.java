// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DbUtil.java

package com.szkingdom;

import java.sql.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DbUtil
{

	private static final Log log;

	public DbUtil()
	{
	}

	public static void closeResultSet(ResultSet rs)
	{
		if (rs != null)
		{
			try
			{
				rs.close();
			}
			catch (SQLException sqlex)
			{
				log.error("�ر����ݼ�������[������룺" + sqlex.getErrorCode() + "] " + sqlex.getMessage());
			}
			rs = null;
		}
	}

	public static void closeStatement(Statement stmt)
	{
		if (stmt != null)
		{
			try
			{
				stmt.close();
			}
			catch (SQLException sqlex)
			{
				log.error("�ر�Statement������[������룺" + sqlex.getErrorCode() + "] " + sqlex.getMessage());
			}
			stmt = null;
		}
	}

	public static void closeConnection(Connection con)
	{
		if (con != null)
		{
			try
			{
				con.close();
			}
			catch (SQLException sqlex)
			{
				log.error("�ر����ݿ����ӳ�����[������룺" + sqlex.getErrorCode() + "] " + sqlex.getMessage());
			}
			con = null;
		}
	}

	static 
	{
		log = LogFactory.getLog(com.szkingdom.DbUtil.class);
	}
}
