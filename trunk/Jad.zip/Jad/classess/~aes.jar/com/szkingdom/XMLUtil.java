// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   XMLUtil.java

package com.szkingdom;

import java.io.*;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.*;

// Referenced classes of package com.szkingdom:
//			LogUtils

public class XMLUtil
{

	public XMLUtil()
	{
	}

	public static String doc2String(Document document)
	{
		String s = "";
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		OutputFormat format = new OutputFormat("", true, "GB2312");
		try
		{
			XMLWriter writer = new XMLWriter(out, format);
			writer.write(document);
			s = out.toString("GB2312");
		}
		catch (UnsupportedEncodingException e)
		{
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		catch (IOException e)
		{
			LogUtils.debugStackTrace(e.getStackTrace());
		}
		return s;
	}

	public static Document loadFile(String filename)
	{
		Document document = null;
		SAXReader saxReader = new SAXReader();
		document = saxReader.read(filename);
		return document;
		Exception e;
		e;
		LogUtils.debugStackTrace(e.getStackTrace());
		return null;
	}

	public static Document loadStream(InputStream is)
	{
		Document document;
		SAXReader saxReader;
		document = null;
		saxReader = new SAXReader();
		saxReader.setEncoding("utf-8");
		document = saxReader.read(is);
		return document;
		DocumentException e;
		e;
		LogUtils.debugStackTrace(e.getStackTrace());
		return null;
	}

	public static Document loadString(String str)
	{
		Document document;
		SAXReader saxReader;
		document = null;
		saxReader = new SAXReader();
		saxReader.setEncoding("utf-8");
		document = saxReader.read(new ByteArrayInputStream(str.getBytes("utf-8")));
		return document;
		DocumentException e;
		e;
		LogUtils.debugStackTrace(e.getStackTrace());
		break MISSING_BLOCK_LABEL_55;
		e;
		LogUtils.debugStackTrace(e.getStackTrace());
		return null;
	}
}
