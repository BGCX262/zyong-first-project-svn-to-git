package com.sungard.velocity;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

/**
 * @version 1.0
 * @author yong.zhang
 *
 */
public class ExportFirst {

	public static List<User> list = new ArrayList<User>();
	/**
	 * 使用iso-8859-1页面没有乱码，但是从java取得属性值中文是乱码
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		list.add(new User(1,"张三","12345"));
		list.add(new User(2,"里斯","qwer"));
		list.add(new User(3,"毛里求斯","zz1234"));
		//Velocity.init();
			VelocityEngine ve = new VelocityEngine();
		//ve.setProperty(Velocity.INPUT_ENCODING, "utf-8");
		//ve.setProperty(Velocity.OUTPUT_ENCODING, "utf-8");
		VelocityContext vc = new VelocityContext();
		vc.put("name", list);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out,"utf-8"));
		//关键一步   设置模版字符集 设置为UTF-8,如果不设置就会变乱码
		Template tem = ve.getTemplate("src/com/sungard/velocity/first.vm","utf-8");
		tem.merge(vc, bw);
		bw.flush();
		bw.close();
		
		
		/*	-----------------------------*/
	/*	VelocityEngine ve1 = new VelocityEngine();

		Properties prop = new Properties();
		prop.setProperty(Velocity.FILE_RESOURCE_LOADER_PATH, "src/com/sungard/velocity/first.vm");
		//设置velocity的编码 
		prop.setProperty(Velocity.ENCODING_DEFAULT, "UTF-8"); 
		prop.setProperty(Velocity.INPUT_ENCODING, "UTF-8"); 
		prop.setProperty(Velocity.OUTPUT_ENCODING, "UTF-8");		
		ve1.init(prop);
		System.out.println(prop.getProperty(Velocity.FILE_RESOURCE_LOADER_PATH));
		VelocityContext vc1 = new VelocityContext();
		vc1.put("name", list);
		BufferedWriter bw1= new BufferedWriter(new OutputStreamWriter(System.out,"utf-8"));
		Template tem1 =Velocity.getTemplate(prop.getProperty(Velocity.FILE_RESOURCE_LOADER_PATH));
		tem1.merge(vc1, bw1);
		bw1.flush();
		bw1.close();*/
	}

}
