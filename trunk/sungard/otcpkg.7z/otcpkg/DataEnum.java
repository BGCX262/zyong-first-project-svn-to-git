package otcpkg;

import java.util.Iterator;

public enum DataEnum {
	CLEAR_Q("0","求和项:清算数量"),
	CLEAR_M("1","求和项:清算金额"),
	DONE_Q("2","求和项:成交数量"),
	DONE_M("3","求和项:成交金额"),
	BUS_A("4","OTC卖出确认"),
	BUS_B("5","OTC买入份额确认");
	
	public final String code;
	public final String name;
	
	DataEnum(String code,String name){
		this.code = code;
		this.name = name;
	}
	/**通过编码可以获取对应的名称
	 * @param code
	 * @return
	 */
	public static String getNameByCode(String code){
		String dName = null;
		if (code!=null&&!"".equals(code.trim())) {
			for(DataEnum d :values()){
				if (code.equals(d.code)) {
					dName = d.name;
					break;
				}
			}
		}
		return dName;
	}
}
