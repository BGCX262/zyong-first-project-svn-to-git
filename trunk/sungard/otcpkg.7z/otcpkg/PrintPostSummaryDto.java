package otcpkg;

import java.util.Date;

public class PrintPostSummaryDto implements Comparable<PrintPostSummaryDto> {
	// 备付金账号
	private String provision_account;
	
	// 交收状态
	private Long deliver_type;
	// 交收日期
	private Date deliver_date;

	// 产品代码
	private String merchandise_code;

	// 成交时间
	private Date done_date;

	// 业务类型
	private String bussiness_type;

	// 清算数量
	private Double clear_quantity;

	// 清算金额
	private Double clear_amount;

	// 成交金额
	private Double done_amount;
	// 成交数量
	private Double done_quantity;

	// 数据项名称
	private String flag;
	// 汇总金额
	private Double sumMoney;

	public PrintPostSummaryDto() {

	}

	public PrintPostSummaryDto(String provision_account, Long deliver_type,
			Date deliver_date, String merchandise_code, Date done_date,
			String bussiness_type, Double clear_quantity, Double clear_amount,
			Double done_amount, Double done_quantity, String flag,
			Double sumMoney) {
		this.provision_account = provision_account;
		this.deliver_type = deliver_type;
		this.deliver_date = deliver_date;
		this.merchandise_code = merchandise_code;
		this.done_date = done_date;
		this.bussiness_type = bussiness_type;
		this.clear_quantity = clear_quantity;
		this.clear_amount = clear_amount;
		this.done_amount = done_amount;
		this.done_quantity = done_quantity;
		this.flag = flag;
		this.sumMoney = sumMoney;
	}

	public String getProvision_account() {
		return provision_account;
	}

	public void setProvision_account(String provision_account) {
		this.provision_account = provision_account;
	}

	public Long getDeliver_type() {
		return deliver_type;
	}

	public void setDeliver_type(Long deliver_type) {
		this.deliver_type = deliver_type;
	}

	public Date getDeliver_date() {
		return deliver_date;
	}

	public void setDeliver_date(Date deliver_date) {
		this.deliver_date = deliver_date;
	}

	public String getMerchandise_code() {
		return merchandise_code;
	}

	public void setMerchandise_code(String merchandise_code) {
		this.merchandise_code = merchandise_code;
	}

	public Date getDone_date() {
		return done_date;
	}

	public void setDone_date(Date done_date) {
		this.done_date = done_date;
	}

	public String getBussiness_type() {
		return bussiness_type;
	}

	public void setBussiness_type(String bussiness_type) {
		this.bussiness_type = bussiness_type;
	}

	public Double getClear_quantity() {
		return clear_quantity;
	}

	public void setClear_quantity(Double clear_quantity) {
		this.clear_quantity = clear_quantity;
	}

	public Double getClear_amount() {
		return clear_amount;
	}

	public void setClear_amount(Double clear_amount) {
		this.clear_amount = clear_amount;
	}

	public Double getDone_amount() {
		return done_amount;
	}

	public void setDone_amount(Double done_amount) {
		this.done_amount = done_amount;
	}

	public Double getDone_quantity() {
		return done_quantity;
	}

	public void setDone_quantity(Double done_quantity) {
		this.done_quantity = done_quantity;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Double getSumMoney() {
		return sumMoney;
	}

	public void setSumMoney(Double sumMoney) {
		this.sumMoney = sumMoney;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bussiness_type == null) ? 0 : bussiness_type.hashCode());
		result = prime * result
				+ ((deliver_date == null) ? 0 : deliver_date.hashCode());
		result = prime * result
				+ ((deliver_type == null) ? 0 : deliver_type.hashCode());
		result = prime * result
				+ ((done_date == null) ? 0 : done_date.hashCode());
		result = prime
				* result
				+ ((merchandise_code == null) ? 0 : merchandise_code.hashCode());
		result = prime
				* result
				+ ((provision_account == null) ? 0 : provision_account
						.hashCode());
		result = prime * result + ((flag == null) ? 0 : flag.hashCode());
		result = prime * result
				+ ((sumMoney == null) ? 0 : sumMoney.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PrintPostSummaryDto other = (PrintPostSummaryDto) obj;
		if (bussiness_type == null) {
			if (other.bussiness_type != null)
				return false;
		} else if (!bussiness_type.equals(other.bussiness_type))
			return false;
		if (deliver_date == null) {
			if (other.deliver_date != null)
				return false;
		} else if (!deliver_date.equals(other.deliver_date))
			return false;
		if (deliver_type == null) {
			if (other.deliver_type != null)
				return false;
		} else if (!deliver_type.equals(other.deliver_type))
			return false;
		if (done_date == null) {
			if (other.done_date != null)
				return false;
		} else if (!done_date.equals(other.done_date))
			return false;
		if (merchandise_code == null) {
			if (other.merchandise_code != null)
				return false;
		} else if (!merchandise_code.equals(other.merchandise_code))
			return false;
		if (provision_account == null) {
			if (other.provision_account != null)
				return false;
		} else if (!provision_account.equals(other.provision_account))
			return false;
		if (flag == null) {
			if (other.flag != null)
				return false;
		} else if (!flag.equals(other.flag))
			return false;
		if (sumMoney == null) {
			if (other.sumMoney != null)
				return false;
		} else if (!sumMoney.equals(other.sumMoney))
			return false;
		return true;
	}

	@Override
	public int compareTo(PrintPostSummaryDto o) {
		// TODO Auto-generated method stub
		int i = 0;

		if (i == 0) {
			i += this.provision_account == null ? ""
					.compareTo(o.provision_account) : this.provision_account
					.compareTo(o.provision_account);
		}
		if (i == 0) {
			i += this.deliver_date == null ? "".compareTo(o.deliver_date + "")
					: this.deliver_date.compareTo(o.deliver_date);
		}
		if (i == 0) {
			i += this.merchandise_code == null ? ""
					.compareTo(o.merchandise_code) : this.merchandise_code
					.compareTo(o.merchandise_code);
		}
		if (i == 0) {
			i += this.done_date == null ? "".compareTo(o.done_date + "")
					: this.done_date.compareTo(o.done_date);
		}
		if (i == 0) {
			i += this.bussiness_type == null ? "".compareTo(o.bussiness_type)
					: this.bussiness_type.compareTo(o.bussiness_type);
		}
		if (i == 0) {
			i = i + this.flag == null ? "".compareTo(o.flag) : this.flag
					.compareTo(o.flag);
		}
		return i;
	}

}
