package otcpkg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;

/**
 * 2013年3月19日13:20:26
 * 
 * @author yong.zhang
 * @since 0.0.6.4
 * @description 根据集合生成excel
 */
public class PrintExcelUtil {

	public static void main(String[] args) throws FileNotFoundException,
			IOException {

		List<PrintPostSummaryDto> list = new ArrayList<PrintPostSummaryDto>();
		list.add(new PrintPostSummaryDto("1", 2L, new Date(), "OTC001",
				new Date(), "4", 1000.00, 111.00, 222.00, 9999.0, "1", 12222.00));
		list.add(new PrintPostSummaryDto("1", 2L, new Date(), "OTC001",
				new Date(), "5", 1000.00, 111.00, 222.00, 9999.0, "1", 12222.00));
		list.add(new PrintPostSummaryDto("1", 2L, new Date(), "OTC002",
				new Date(), "5", 1000.00, 111.00, 222.00, 9999.0, "1", 12222.00));
		list.add(new PrintPostSummaryDto("2", 3L, new Date(), "OTC002",
				new Date(), "4", 2000.00, 444.00, 333.00, 888.0, "1", 12333.00));
		/*
		 * list.add(new PrintPostSummaryDto("1", 2L, new Date(), "OTC001", new
		 * Date(), "3", 1000.00, 111.00, 222.00, 9999.0, "1", 12444.00));
		 * list.add(new PrintPostSummaryDto("1", 2L, new Date(), "OTC001", new
		 * Date(), "3", 1000.00, 111.00, 222.00, 9999.0, "1", 12555.00));
		 */
		PrintExcelUtil.createPostSummary(null, list);
	}

	public static HSSFWorkbook createPostSummary(HSSFWorkbook workbook,
			List<PrintPostSummaryDto> list) throws FileNotFoundException,
			IOException {
		List<PrintPostSummaryDto> list_bak = null;
		if (list != null && list.size() > 0) {
			list_bak = getDataListFromParams(list);
		}
		File file = new File("c:/postSummary1.xls");
		FileOutputStream os = new FileOutputStream(file);

		workbook = new HSSFWorkbook();

		HSSFSheet hsheet = workbook.createSheet("交收情况查询");

		HSSFCellStyle style = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFFont.COLOR_NORMAL);
		// font.setFontHeight((short)100);
		// font.setFontHeight(HSSFFont.DEFAULT_CHARSET);
		font.setFontHeightInPoints((short) 16);// 设置字体大小
		font.setItalic(false);
		font.setFontName("黑体");
		style.setFont(font);
		style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);// 垂直
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);// 水平
		HSSFCellStyle cellstyle = workbook.createCellStyle();
		cellstyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);// 垂直
		cellstyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);// 水平

		HSSFRow hrow1 = hsheet.createRow(0);
		HSSFRow hrow2 = hsheet.createRow(1);
		HSSFRow hrow3 = hsheet.createRow(2);
		CellRangeAddress cra = new CellRangeAddress(0, 1, 0, 6);
		hsheet.addMergedRegion(cra);

		HSSFCell cell = hrow1.createCell(0);
		// cell.set
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		cell.setCellValue("交收情况查询" + format.format(new Date()));
		cell.setCellStyle(style);
		int num = 0;
		int bus_num = 0;
		int privi_num = 0;
		int deliver_num = 0;
		int merch_num = 0;
		int done_num = 0;

		String[] celltitles = { "备付金账户", "交收日期", "产品代码", "成交日期", "业务类型", "数据",
				"汇总" };
		for (int i = 0; i < celltitles.length; i++) {
			HSSFCell c = hrow3.createCell(i);
			c.setCellValue(celltitles[i]);
		}
		Map<String, Integer> map = new HashMap<String, Integer>();

		if (list_bak != null && list_bak.size() > 0) {
			int j = 3;
			for (PrintPostSummaryDto dto : list_bak) {
				HSSFRow hrow = hsheet.createRow(j);
				for (int i = 0; i < celltitles.length; i++) {
					hsheet.setColumnWidth(i, 3500);// 设置每列的宽度 参考
													// ："2012-08-10"的宽度为2500
					HSSFCell dcell = hrow.createCell(i);
					dcell.setCellStyle(cellstyle);
					switch (i) {
					case 0:
						dcell.setCellValue(dto.getProvision_account());
						break;
					case 1:
						dcell.setCellValue(format.format(dto.getDeliver_date()));
						break;
					case 2:
						dcell.setCellValue(dto.getMerchandise_code());
						break;
					case 3:
						dcell.setCellValue(format.format(dto.getDone_date()));
						break;
					case 4:
						// TODO 需要获取数据字典
						String type = DataEnum.getNameByCode(dto
								.getBussiness_type());
						dcell.setCellValue(type);
						break;
					case 5:
						String sflag = DataEnum.getNameByCode(dto.getFlag());
						dcell.setCellValue(sflag);

						break;
					case 6:
						dcell.setCellValue(dto.getSumMoney());
						break;
					}
					//num++;
				}
				bus_num++;
				CellRangeAddress cra1 = new CellRangeAddress(bus_num,
						bus_num + 4, 5, 5);
				 //hsheet.addMergedRegion(cra1);
				j++;
			}
			CellRangeAddress cra2 = new CellRangeAddress(3, num,
					0, 0);
			//hsheet.getc
			 hsheet.addMergedRegion(cra2);
		}
			
		workbook.write(os);
		os.close();
		return workbook;
	}

	/**
	 * 从cpack列表获取数据重新生成list集合，主要是把根据最后的四个字段分解成四个不同的对象，并进行排序
	 * 
	 * @param list
	 * @return
	 */
	private static List<PrintPostSummaryDto> getDataListFromParams(
			List<PrintPostSummaryDto> list) {
		List<PrintPostSummaryDto> list_bak = new ArrayList<PrintPostSummaryDto>();
		for (PrintPostSummaryDto pdto : list) {
			for (int i = 0; i < 4; i++) {
				PrintPostSummaryDto dto = new PrintPostSummaryDto();
				dto.setBussiness_type(pdto.getBussiness_type());
				dto.setDone_date(pdto.getDone_date());
				dto.setDeliver_date(pdto.getDeliver_date());
				dto.setDeliver_type(pdto.getDeliver_type());
				dto.setMerchandise_code(pdto.getMerchandise_code());
				dto.setProvision_account(pdto.getProvision_account());
				if (0 == i) {
					dto.setFlag("" + i);
					dto.setSumMoney(pdto.getClear_amount());
				} else if (1 == i) {
					dto.setFlag("" + i);
					dto.setSumMoney(pdto.getClear_quantity());
				} else if (2 == i) {
					dto.setFlag("" + i);
					dto.setSumMoney(pdto.getDone_amount());
				} else {
					dto.setFlag("" + i);
					dto.setSumMoney(pdto.getDone_quantity());
				}
				list_bak.add(dto);
			}
		}
		Collections.sort(list_bak);
		return list_bak;

	}
	// 数据字典获取选项
	/*
	 * private Object getDicetLabel(String type, String value) { Object object =
	 * null; List<SelectItem> list = DictRepository.getDictSelectItems(type,
	 * false); if (list != null) { for (SelectItem item : list) { if
	 * (item.getValue().equals(value)) { object = item.getLabel(); } } } return
	 * object; }
	 */
}
