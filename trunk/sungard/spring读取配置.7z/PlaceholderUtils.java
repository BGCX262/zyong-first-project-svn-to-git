package com.zyong.spring;

import java.util.HashSet;  
import java.util.Map;  
import java.util.Set;  
 
import org.springframework.util.StringUtils;  
 
public class PlaceholderUtils {  
 
    /** *//** Default Holder prefix: "${" */ 
    public static final String DEF_HOLDER_PREFIX            = "${";  
 
    public static final int    DEF_HOLDER_PREFIX_LEN        = 2;  
 
    /** *//** Default Holder suffix: "}" */ 
    public static final String DEF_HOLDER_SUFFIX            = "}";  
 
    public static final int    DEF_HOLDER_SUFFIX_LEN        = 1;  
    /** *//** Never check system properties. */ 
    public static final int    SYSTEM_PROPERTIES_MODE_NEVER = 0;  
 
    /** *//**  
     * Check system properties if not resolvable in the specified properties.  
     * This is the default.  
     */ 
    public static final int    SYS_PROPS_MODE_FALLBACK      = 1;  
 
    /** *//**  
     * Check system properties first, before trying the specified properties.  
     * This allows system properties to override any other property source.  
     */ 
    public static final int    SYS_PROPS_MODE_OVERRIDE      = 2;  
 
    /** *//**  
     * Parse the given String value recursively, to be able to resolve  
     * nested Holders (when resolved property values in turn contain  
     * Holders again).  
     *   
     * @param strVal  
     *            the String value to parse  
     * @param props  
     *            the Properties to resolve Holders against  
     * @param visitedHolders  
     *            the Holders that have already been visited  
     *            during the current resolution attempt (used to detect circular references  
     *            between Holders). Only non-null if we're parsing a nested Holder.  
     * @throws Exception  
     * @throws AppException  
     *             if invalid values are encountered  
     * @see #resolveHolder(String, java.util.Properties, int)  
     */ 
    public static String parse(String strVal) throws Exception {  
        Set<String> visitedHolders = new HashSet<String>();  
        return parse(strVal, null, visitedHolders, false);  
    }  
 
    public static String parse(String strVal, Map<Object, Object> props) throws Exception {  
        Set<String> visitedHolders = new HashSet<String>();  
        return parse(strVal, props, visitedHolders, false);  
    }  
 
    public static String parse(String strVal, boolean ignoreBadHolders) throws Exception {  
        Set<String> visitedHolders = new HashSet<String>();  
        return parse(strVal, null, visitedHolders, ignoreBadHolders);  
    }  
 
    private static String parse(String strVal, Map<Object, Object> props,  
        Set<String> visitedHolders, boolean ignoreBadHolders) throws Exception {  
 
        StringBuffer buf = new StringBuffer(strVal);  
        int startIndex = strVal.indexOf(DEF_HOLDER_PREFIX);  
        while (startIndex != -1) {  
        	//System.out.println("start"+startIndex);
            int endIndex = findHolderEndIndex(buf, startIndex);  
            //System.out.println("end"+endIndex);
            if (endIndex != -1) {  
                String holder = buf.substring(startIndex + DEF_HOLDER_PREFIX_LEN, endIndex);  
                String defValue = null;  
                int defIndex = org.apache.commons.lang.StringUtils.lastIndexOf(holder, ":");  
                if (defIndex >= 0) {  
                    defValue = StringUtils.trimWhitespace(holder.substring(defIndex + 1));  
                    holder = StringUtils.trimWhitespace(holder.substring(0, defIndex));  
                }  
 
                if (!visitedHolders.add(holder)) {  
                    throw new Exception("Circular PlaceHolder reference '" + holder  
                        + "' in property definitions");  
                }  
                // Recursive invocation, parsing Holders contained in the Holder key.  
                holder = parse(holder, props, visitedHolders, ignoreBadHolders);  
                // Now obtain the value for the fully resolved key  
                String propVal = resolveHolder(holder, props, SYS_PROPS_MODE_FALLBACK, defValue);  
               // System.out.println(propVal+"---");
                if (propVal != null) {  
                    // Recursive invocation, parsing Holders contained in the  
                    // previously resolved Holder value.  
                    propVal = parse(propVal, props, visitedHolders, ignoreBadHolders);  
                    buf.replace(startIndex, endIndex + DEF_HOLDER_SUFFIX_LEN, propVal);  
                    startIndex = buf.indexOf(DEF_HOLDER_PREFIX, startIndex + propVal.length());  
                } else if (ignoreBadHolders) {  
                    // Proceed with unprocessed value.  
                    startIndex = buf.indexOf(DEF_HOLDER_PREFIX, endIndex + DEF_HOLDER_SUFFIX_LEN);  
                } else {  
                    throw new Exception("Could not resolve Placeholder '" + holder + "'");  
                }  
                visitedHolders.remove(holder);  
            } else {  
                startIndex = -1;  
            }  
        }  
 
        return buf.toString();  
    }  
 
    private static int findHolderEndIndex(CharSequence buf, int startIndex) {  
        int index = startIndex + DEF_HOLDER_PREFIX_LEN;  
        int withinNestedHolder = 0;  
        while (index < buf.length()) {  
            if (StringUtils.substringMatch(buf, index, DEF_HOLDER_SUFFIX)) {  
                if (withinNestedHolder > 0) {  
                    withinNestedHolder--;  
                    index = index + DEF_HOLDER_SUFFIX_LEN;  
                } else {  
                    return index;  
                }  
            } else if (StringUtils.substringMatch(buf, index, DEF_HOLDER_PREFIX)) {  
            	//System.out.println("进来过");
                withinNestedHolder++;  
                index = index + DEF_HOLDER_PREFIX_LEN;  
            } else {  
                index++;  
            }  
        }  
        return -1;  
    }  
 
    /** *//**  
     * Resolve the given Holder using the given properties, performing  
     * a system properties check according to the given mode.  
     * <p>  
     * Default implementation delegates to <code>resolveHolder  
     * (Holder, props)</code> before/after the system properties check.  
     * <p>  
     * Subclasses can override this for custom resolution strategies, including customized points  
     * for the system properties check.  
     *   
     * @param holder  
     *            the Holder to resolve  
     * @param props  
     *            the merged properties of this configurer  
     * @param sysPropsMode  
     *            the system properties mode,  
     *            according to the constants in this class  
     * @return the resolved value, of null if none  
     * @see #setSystemPropertiesMode  
     * @see System#getProperty  
     * @see #resolveHolder(String, java.util.Properties)  
     */ 
    private static String resolveHolder(String holder, Map<Object, Object> props, int sysPropsMode,  
        String defaultValue) {  
        String propVal = null;  
        if (sysPropsMode == SYS_PROPS_MODE_OVERRIDE) {  
            propVal = resolveSystemProperty(holder);  
        }  
        if (propVal == null) {  
            propVal = resolveHolder(holder, props, defaultValue);  
        }  
        if (propVal == null && sysPropsMode == SYS_PROPS_MODE_FALLBACK) {  
            propVal = resolveSystemProperty(holder);  
        }  
        return propVal;  
    }  
 
    /** *//**  
     * Resolve the given Holder using the given properties.  
     * The default implementation simply checks for a corresponding property key.  
     * <p>  
     * Subclasses can override this for customized Holder-to-key mappings or custom resolution  
     * strategies, possibly just using the given properties as fallback.  
     * <p>  
     * Note that system properties will still be checked before respectively after this method is  
     * invoked, according to the system properties mode.  
     *   
     * @param holder  
     *            the Holder to resolve  
     * @param props  
     *            the merged properties of this configurer  
     * @return the resolved value, of <code>null</code> if none  
     * @see #setSystemPropertiesMode  
     */ 
    private static String resolveHolder(String holder, Map<Object, Object> props,  
        String defaultValue) {  
        if (props != null) {  
            Object value = props.get(holder);  
            if (value != null) {  
                return "" + value;  
            } else if (defaultValue != null) {  
                return defaultValue;  
            }  
        }  
 
        return defaultValue;  
    }  
 
    /** *//**  
     * Resolve the given key as JVM system property, and optionally also as  
     * system environment variable if no matching system property has been found.  
     *   
     * @param key  
     *            the Holder to resolve as system property key  
     * @return the system property value, or <code>null</code> if not found  
     * @see #setSearchSystemEnvironment  
     * @see java.lang.System#getProperty(String)  
     * @see java.lang.System#getenv(String)  
     */ 
    private static String resolveSystemProperty(String key) {  
        try {  
            String value = System.getProperty(key);  
            if (value == null) {  
                value = System.getenv(key);  
            }  
            return value;  
        } catch (Throwable ex) {  
            ex.printStackTrace();  
            return null;  
        }  
    }  
} 