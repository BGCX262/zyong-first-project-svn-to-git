package com.zyong.spring;

import java.util.Properties;  

public class PlaceholderStringTest {  
    public static void main(String[] args) throws Exception {  
        Properties props = new Properties();  
        // 在.properties文件中放置key1、key2  
        props.put("key3", "Hello");  
        props.put("index", "3");  
         
        String str = null;  
        // 替换key1、key2  
      /*  str = PlaceholderUtils.parse("Property:${key1}=${key2}", props);  
        System.out.println(str);// Property:Hello=World  
 */
        // 此处要替换的是 key${index:3}，先去看.properties属性中是否有index属性，有则替换其值  
        // 再去看系统属性中是否有index属性，有则替换其值  
        // 由于都没有index属性，所以取值为 3，也就是要替换 xxx${key3:yyy}  
        // 由于key3在.properties文件的属性中、系统属性中均没有此属性，所以返回默认值 yyy  
        //先判断有没有index属性，有的话则去map.get(index) 不取3
        //在判断key+map.get(index)在map有没有这个属性，有的话则不取yyy
        /*str = PlaceholderUtils.parse("xxx${key${index:3}:yyy}", props);  
        System.out.println(str); // xxxyyy  
 
        // 在.properties文件属性中加入index=2  
        props.put("index", "2");  
 
        // 此处的index属性值为2，则替换key2的属性值，默认值yyy被忽略了  
        str = PlaceholderUtils.parse("xxx${key${index:3}:yyy}", props);  
        System.out.println(str); // xxxWorld  
 
        // 系统属性中加入var1  
        System.setProperty("var1", "IamSystem");  
        str = PlaceholderUtils.parse("xxx${var1}");  
        System.out.println(str); // xxxIamSystem  
 
        System.setProperty("var2", "System2");  
        str = PlaceholderUtils.parse("xxx${var1}.${var2}");  
        System.out.println(str);// xxxIamSystem.System2  
 
        str = PlaceholderUtils.parse("xxx${var1}.${var3}", true);  
        System.out.println(str); // xxxIamSystem.${var3}   
        props.clear();  
          
        // 模板  
        String dburlTmp = "jdbc:oracle:thin:@${host}:${port:1521}:${service_name}";  
        Properties dbProps = new Properties();  
        dbProps.put("host", "localhost");  
        dbProps.put("service_name", "root");  
        str = PlaceholderUtils.parse(dburlTmp, dbProps);  
        System.out.println(str); // jdbc:oracle:thin:@localhost:1521:root  
*/ 
        // 系统属性中加入var1  
        System.setProperty("var1", "IamSystem");  
      //
       //str = PlaceholderUtils.parse("xxx${var1}");  
        System.out.println(str); // xxxIamSystem  
 
        System.setProperty("var2", "System2");  
        str = PlaceholderUtils.parse("xxx${var1}.${var2}");  
        System.out.println(str);// xxxIamSystem.System2  
 
        }  
} 
